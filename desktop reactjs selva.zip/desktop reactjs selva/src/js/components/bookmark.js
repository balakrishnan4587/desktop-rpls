import React from 'react';
import DataFormatter from './utilities/dataFormatter'

class Bookmark extends React.Component {
  constructor() {
    super();
    //Bind events for es6 syntax
   this.handlebookmarkClick = this.handlebookmarkClick.bind(this);
   this.handleDelete = this.handleDelete.bind(this);
  }
 /*
  This method is used to render each bookmark item.
  */
  render = function() {
    var bookmark = this.props.bookmark;
    var bookmarkStyle = {
      color: 'black',
      backgroundColor: 'yellow'
    };
    return (
      <div>
      <li  className='bookmarkContainer'>
      <image className = "deleteBookmark" onClick={this.handleDelete.bind(this,bookmark)} src="./assets/images/deleteNote.png" width="20" height="20" align = "right" />
      <a onClick = {this.handlebookmarkClick.bind(this,bookmark)} data-bookmarkId={bookmark.id} data-pageIndex ={bookmark.pageIndex} data-highlightHash ={bookmark.highlightHash} className = 'pageIndex'> Page {bookmark.pageIndex}</a>
      <div className = 'bookmarkCommentContainer' >
      <label className = 'bookmarkComment'>
      {bookmark.note}
      </label>
      </div>
      </li>
      </div>
    );
  }

  handleDelete = function(bookmark) {
    this.props.bookmarkDeleteCallback(bookmark);
  }
  /*
  This method is triggered when a bookmark is clicked. Will trigger a callback.
  */
 handlebookmarkClick = function(bookmark,event) {
    // Stop the propogation of the link is clicked to prevent bubbling
    if(DataFormatter.isFunction(this.props.bookmarkClickedCallback) &&
    (!(event.target.classList.contains('pageIndex')))) {
      this.props.bookmarkClickedCallback(bookmark);
    }
 }
};
export default Bookmark;
