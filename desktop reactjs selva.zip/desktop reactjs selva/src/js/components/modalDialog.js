import React from 'react';
import {Modal} from 'react-bootstrap';
import {Button} from 'react-bootstrap';
import DataFormatter from './utilities/dataFormatter';
import Localization from './localization';


var lang = DataFormatter.getLanguage();

class ModalDialog extends React.Component {

  constructor() {
    super();
    //Bind events for es6 syntax
    this.closeDialog = this.closeDialog.bind(this);
    this.applyModalChanges = this.applyModalChanges.bind(this);
  }

  /*
  Method that is triggered when the component is updated to the DOM.
  */
  componentDidUpdate = function() {
    // Ellipsis functionality.
    DataFormatter.wrapMultipleLines('selectedText');
  }
  state = {
    showModal:false
  };
  /*
  Method that is triggered when the dialog is to be closed.
  */
  closeDialog = function(event) {
    if(DataFormatter.isFunction(this.props.closeCallback))
    {
      this.props.closeCallback(this.props.modalType, event.currentTarget);
    }
  }
  /*
  Method that is triggered when the apply button is clicked in the modal.
  */
  applyModalChanges = function() {
    var modalBodyNode = React.findDOMNode(this.refs.modalChild);
    if(DataFormatter.isFunction(this.props.okCallback))
    {
      this.props.okCallback(modalBodyNode);
    }
  }
  /*
  Method that is triggered when component is rendered.
  */
  render = function() {
    var headerClass = this.props.headerClass && this.props.headerClass!=='' ? this.props.headerClass:'modal-header';
    var bodyClass = this.props.bodyClass && this.props.bodyClass!=='' ? this.props.bodyClass:'modal-body';
    var footerClass = this.props.footerClass && this.props.footerClass!=='' ? this.props.footerClass:'modal-footer';
    return (
      <div>
      <Modal className="modalDialogContainer" bsSize = {this.props.modalSize} show={this.props.showModal} onHide={this.closeDialog}>
      <Modal.Header modalClassName ={headerClass} closeButton>
      <Modal.Title>{this.props.modalTitle}</Modal.Title>
      </Modal.Header>
      <Modal.Body modalClassName ={bodyClass}>
      {
        React.Children.map(this.props.children, (element, idx) => {
          return React.cloneElement(element, { ref: 'modalChild' });
        })
      }
      </Modal.Body>
      <Modal.Footer modalClassName ={footerClass}>
      <Button onClick={this.applyModalChanges}>{this.props.okLabel}</Button>
      <Button onClick={this.closeDialog} className = 'Cancel'>{DataFormatter.getObjectText(Localization, (lang + ".PageText.Cancel"))}</Button>
      </Modal.Footer>
      </Modal>
      </div>
    );
  }
};
export default ModalDialog;
