import React from 'react';
import AppActions from '../actions/app.actions';
import AppStore from '../stores/app.store';
import AppConstants from '../constants/app.constants';
import Bookshelf from './bookshelf';
import DataFormatter from './utilities/dataFormatter'
import Localization from './localization';
import Helmet from 'react-helmet'
import Navbar from './navbar';

var lang = DataFormatter.getLanguage();

class BookshelfContainer extends React.Component {
  state = {
    title: this.props.title
  }

  componentWillMount() {
		AppStore.on(AppConstants.EventTypes.BOOK_CLICKED, this.bookClicked);
  }

  bookClicked = () => {
		var response = AppStore.response;
        //console.log('book response'+response);
        DataFormatter.setObjectInStorage('currentBook',response);
        var type = response.metadata.type;
        if(type == 'pdf'){
          this.context.router.push('/readPDF');
        }else{
          this.context.router.push('/readBook');
        }
	}

  render = function() {
    console.log('BookshelfContainer render called');
    return (
      <div >
        <Helmet title={this.state.title}/>
        <Navbar/>
        <Bookshelf/>
      </div>
    );
  }

  componentWillUnmount() {
		AppStore.removeListener(AppConstants.EventTypes.BOOK_CLICKED, this.bookClicked);    
  }
  }

BookshelfContainer.defaultProps = {
    title: DataFormatter.getObjectText(Localization, (lang + ".PageTitles.Login"))
 }

BookshelfContainer.contextTypes= {
   router: React.PropTypes.object.isRequired
 }
export default BookshelfContainer;
