import React from 'react';
import AppActions from '../actions/app.actions';
import AppStore from '../stores/app.store';
import AppConstants from '../constants/app.constants';
import DataFormatter from './utilities/dataFormatter'
import PDFWrapper from './wrappers/pdfWrapper';
import ModalDialog from './modalDialog';
import LoadingOverlay from './loadingOverlay';
import Footer from './footerbar';
import SlidingMenu from './slidingMenu/slidingMenu';
import PopoverMenu from './popoverMenu/popoverMenu';
import HighlightItem from './pdfHighlightItem';
import Bookmark from './bookmark';
import BookmarkLink from './bookmarkLink';
import ZoomSlider from './zoomSlider';
import Localization from './localization';
import LinkModal from './linksmodal';
import AudioModal from './audiomodal';

var lang = DataFormatter.getLanguage();
var userId = String(DataFormatter.getKeyFromObject("userInformation", "id"));
var bookTitle = "" , bookId = "";
try {
bookTitle = DataFormatter.getObjectInStorage("bookTitle");
bookId = DataFormatter.getObjectInStorage("bookId");
}catch(e)
{

}
let pdfWrapper = {};
let zoomSliderProps, tocMenuProps, highLightPopoverProps, highlightMenuProps,bookmarkLinkProps, bookmarkMenuProps, notesModalProps = {};
class PDFPanel extends React.Component {
  constructor() {
     super();
     //Bind events for es6 syntax
     this.handleBookHeaderAction = this.handleBookHeaderAction.bind(this);
     this.getProductId = this.getProductId.bind(this);
     this.updateBookmarksPanel  = this.updateBookmarksPanel.bind(this);
     this.handleLinkClick = this.handleLinkClick.bind(this);
     this.closePanel = this.closePanel.bind(this);
     this.updateBookmark = this.updateBookmark.bind(this);
     this.handleBookmark = this.handleBookmark.bind(this);
     this.navigateToHighlightLocation = this.navigateToHighlightLocation.bind(this);
     this.showMenu = this.showMenu.bind(this);
     this.restoreHighlights = this.restoreHighlights.bind(this);
     this.saveNote = this.saveNote.bind(this);
     this.closeModal = this.closeModal.bind(this);
     this.handleHighlightClick = this.handleHighlightClick.bind(this);
     this.updateMenuState = this.updateMenuState.bind(this);
     this.updateHighlightsPanel = this.updateHighlightsPanel.bind(this);
     this.manageLoadingOverlay = this.manageLoadingOverlay.bind(this);
     this.audioIconClicked = this.audioIconClicked.bind(this);
     // this.closeAudioPanel = this.closeAudioPanel.bind(this);
  }

  state = {
   zoomLevel:1,
   isTOCMenuVisible: false,
   isBookmarkMenuVisible:false,
   isZoomSliderShown:false,
   isBookmarked: false,
   bookmarks:[],
   currentBookmark : '',
   isNotesModalVisible: false,
   isHighlightsMenuVisible : false,
   isLoading: true,
   isLinkModalShown: false,
   isAudioModalShown: false,
   audioLinkUrl: "",
   linkUrl:"",
   tocContent:"",
   highlights:[],
    isHighlightPopoverVisible: false,
    currentHighlight : {
      highlightedText: '',
      comment:''
    }
  }

  /*
  This method handles the following
  1. Initializing and loading the PDF with content.
  2. Setting up the reader panel component as a whole
  */
  componentDidMount = function() {
    var bookDetails = DataFormatter.getObjectInStorage('currentBook');
    var url = bookDetails.metadata.url;
    var isZip = false;
    if(url.indexOf(".zip") != -1) {
      isZip = true
    }
    var config = {
      host:AppConstants.FoxitServerURL,
      PDFassetURL:url,
      encpwd:bookDetails.metadata.encpwd,
      zip: isZip
    };
    // Initialize the eBook with
    pdfWrapper = new PDFWrapper();
    pdfWrapper.createPDFViewer(config);
    pdfWrapper.registerEvent('onpageChange', this.pdfpageChanged);
    pdfWrapper.registerEvent('textSelected', this.manageHighlightPopover);
    pdfWrapper.registerEvent('blankSelection', this.closePanel);
    pdfWrapper.registerEvent('highlightClicked', this.handleHighlightClick);
    pdfWrapper.registerEvent('linkClicked', this.handleLinkClick);
    document.querySelector('.docViewer').addEventListener('wrdocLoaded', this.setLoadingFalse);
    document.querySelector('.docViewer').addEventListener('pageVisible', this.updateBookmark);
    document.querySelector('.docViewer').addEventListener('wrpageChanged', this.setLoadingTrue);
    document.querySelector('.docViewer').addEventListener('wrpageLoaded', this.restoreHighlights);
      AppStore.on(AppConstants.EventTypes.BOOK_HEADER_ITEM_CLICKED, this.handleBookHeaderAction);
      AppStore.on(AppConstants.EventTypes.BOOK_HIGHLIGHTS_FETCHED, this.updateHighlightsPanel);
      AppStore.on(AppConstants.EventTypes.BOOK_BOOKMARKS_FETCHED, this.updateBookmarksPanel);
    AppActions.getBookHighlights(this.getProductId(bookDetails.id));
    DataFormatter.setObjectInStorage('productId', this.getProductId(bookDetails.id));
    // document.querySelector('.pdf-fwr-pc-main').addEventListener('click', this.closeAudioPanel);
  }
  componentWillUnmount = function() {
    delete WebPDF.ViewerInstance;
    //this.replaceState(this.getInitialState());
    this.setState({
      isTOCMenuVisible: false,
      isNotesModalVisible: false,
      isHighlightsMenuVisible : false,
      isLoading: true,
      tocContent:"",
      highlights:[],
      isHighlightPopoverVisible: false,
      currentHighlight : {
      highlightedText: '',
      comment:''
     }
    });
     document.querySelector('.docViewer').removeEventListener('wrdocLoaded', this.setLoadingFalse);
    document.querySelector('.docViewer').removeEventListener('pageVisible', this.updateBookmark);
    document.querySelector('.docViewer').removeEventListener('wrpageChanged', this.setLoadingTrue);
    document.querySelector('.docViewer').removeEventListener('wrpageLoaded', this.restoreHighlights);

    AppStore.removeListener(AppConstants.EventTypes.BOOK_HEADER_ITEM_CLICKED, this.handleBookHeaderAction);
    AppStore.removeListener(AppConstants.EventTypes.BOOK_HIGHLIGHTS_FETCHED, this.updateHighlightsPanel);
    AppStore.removeListener(AppConstants.EventTypes.BOOK_BOOKMARKS_FETCHED, this.updateBookmarksPanel);

  }

  closePanel = function() {
   if(document.querySelector(".audiojs")) {
      document.querySelector(".audioContainer").style.visibility = "hidden";
      }
   if(DataFormatter.getObjectInStorage("audioLinkClicked")) {
      if(document.querySelector(".audiojs")) {
         if(document.querySelector(".audiojs.playing")) {
        DataFormatter.setObjectInStorage("audioLinkClicked", false);
        }
      document.querySelector(".audioContainer").style.visibility = "visible";
      }
    }


    this.setState({
      isHighlightPopoverVisible: false
    });
  }

  /*
  This method is used to render the bookmarks items one by one based on The
  object retreived from the server.
  */
  renderBookmarks = function()
  {
     var self = this;
     if(!this.state.bookmarks || this.state.bookmarks.length === 0)
     {
         return <div className='noBookmarks'>{DataFormatter.getObjectText(Localization, (lang + ".PageText.NoBookmarks"))}</div>
     } else {
        return this.state.bookmarks.map(function(bookmark,index) {
          return <Bookmark bookmarkDeleteCallback ={self.deleteBookmark.bind(self)} bookmarkClickedCallback ={self.gotoBookmarkPage.bind(self)} key ={index} bookmark={bookmark} />;
        });
     }
  }

  /* Function to get the Product ID for the Book ID
*/
 getProductId = function(bookId) {
  var products = DataFormatter.getObjectInStorage('products');
  var currentProduct = products.filter(function(product) {
    if(product.books[0] != undefined) {
      if(product.books.length > 1) {
       return (product.books[0].id == bookId || product.books[1].id == bookId) ;
       } else {
        return product.books[0].id == bookId
       }
     }
    });
   return currentProduct[0].id;
 }

  /*
  This method is used to render the highlight items one by one based on The
  object retreived from the server.
  */
  renderHighlights = function()
  {
     var self = this;
     if(!this.state.highlights || this.state.highlights.length === 0)
     {
         return <div className='noHighlights'>{DataFormatter.getObjectText(Localization, (lang + ".PageText.NoHighlights"))}</div>
     } else {
        var highlights = this.state.highlights;
        var highlightIds = [], id, uniqueHighlights = [];
        for(var i=0; i<highlights.length; i++) {
          id = highlights[i].id;
          if(highlightIds.indexOf(id) == -1) {
            highlightIds.push(id);
            uniqueHighlights.push(<HighlightItem highlightClickedCallback ={self.showNotesOverlay.bind(self)} key ={i} highlight={highlights[i]} />);
          }
        }
         return uniqueHighlights;
      }
  }

  /*
  This method is used open a popup to display the content of the link on a PopUp Window.
  */
  handleLinkClick = function(element) {
    var url = element.getAttribute('link-uri');
    if(url.indexOf('.mp4') > 0 || url.indexOf('.avi') > 0 || url.indexOf('.wmv') > 0 || url.indexOf('.mpg') > 0 || url.indexOf('.mpeg') > 0 ) {
     this.setState({
      isLinkModalShown:true,
      isAudioModalShown:false,
      audioLinkUrl: "",
      linkUrl:url
    });
    } else {
      DataFormatter.setObjectInStorage("audioLinkClicked", true);
      if(url.indexOf('.wav') > 0 || url.indexOf('.m4a') > 0 || url.indexOf('.mp3') > 0) {
        this.setState({
          isAudioModalShown:true,
          audioLinkUrl:url
        });

      }else {
        this.setState({
          isLinkModalShown:false,
          isAudioModalShown:false,
          audioLinkUrl: ""
        });
        try {
        for(var i=0; i<(Object.keys(audiojs.instances).length -1); i++) {
          audiojs.instances[Object.keys(audiojs.instances)[i]].pause();
          }
        }catch(e){

        }
        window.open(url, "_newtab");
      }
    }
  }

   /*
  This method is used to create a new highlight when the user highlights the Text
  and selects highlight from the context menu.
  */
  createNewHighlight = function(element) {
    this.setState({
      isHighlightPopoverVisible:false
    });
    this.manageLoadingOverlay(false);
    var bookId = DataFormatter.getObjectInStorage('productId');
    var highlight = pdfWrapper.createHighlight();
    this.state.currentHighlight.data = highlight;
    highlight.bookId = bookId;
    highlight.isNewHighlight = true;
    highlight.isPDF = true;
    AppActions.manageHighlight(highlight);
  }

  /*
  This method is used to create a new note associated with a highlight.
  */
  createNewNote = function() {
    this.setState({
      isHighlightPopoverVisible:false
    });
    var bookId = DataFormatter.getObjectInStorage('productId');
    var highlight = pdfWrapper.createHighlight();
    highlight.bookId = bookId;
    highlight.isNewHighlight = true;
    highlight.note = highlight.selection;
    highlight.isPDF = true;
    var currentHighlight = this.state.currentHighlight;
    currentHighlight.data = highlight;
    this.setState({
      currentHighlight:currentHighlight
    })
    // this.state.currentHighlight.data = highlight;
    this.showNotesOverlay(highlight,true);
  }

  /*
  This method is used to refresh the highlights panel with the latest Content
  It is called in the following cases.
  1. First time load of the book.
  2. After any highlights are added/modified/deleted.
  */
  updateHighlightsPanel() {
    var highlightsList= AppStore.response;
    this.setState({
      highlights: highlightsList.sortedHighlights
    });
    this.restoreHighlights();
    var level = pdfWrapper.getCurrentZoomLevel();
    this.setState({
      zoomLevel : level
    });
    this.manageLoadingOverlay(false);
  }
    /*
      This method is used to restore highlights for that page when it is loaded.
      */

    handleHighlightClick = function(id) {
      var highlight = this.state.highlights.filter(function (highlight) {
      var hash = id;
      return hash === highlight.id;
    });
    if(highlight !== null  && highlight.length >0) {
      this.showNotesOverlay(highlight[0],false);
    }
  }

  /*
  This method is used to restore highlights for that page when it is loaded.
  */
  restoreHighlights = function() {
   this.setLoadingFalse();
    var currentHighlights = this.state.highlights.filter(function (highlight) {
         return highlight.highlightHash !== undefined;
      });
    var highlightHashes = currentHighlights.map(function(highlight){
       var preHash = highlight.highlightHash;
       var hId = highlight.id;
       var page = highlight.pageIndex;
       if(preHash.indexOf("$") == -1) {
       preHash = preHash + "@" + hId + "$" + page + "$";
        }
       if(preHash && preHash != "undefined")
       return preHash;
     });
    var highlights = highlightHashes;
    pdfWrapper.restoreHighlights(currentHighlights);
    var bookDetails = DataFormatter.getObjectInStorage('productId');
     this.setLoadingFalse();
    AppActions.getBookBookmarks(bookDetails);
  }


 /*
 This method is used to initialize the props to be passed to each
 component on render.
 */
 initializeComponentProps = function() {
   tocMenuProps = {
     alignment: "left pdf",
     menuType: AppConstants.SlidingMenuTypes.TOC,
     isMenuVisible: this.state.isTOCMenuVisible,
     menuClosed:this.updateMenuState
   };
   zoomSliderProps = {
      zoomSliderID:"zoomSliderID",
      min:1,
      max:2,
      menuType: AppConstants.SlidingMenuTypes.ZOOM,
      zoomSliderValue:this.state.zoomLevel,
      isPercentageSlider:false,
      zoomStep:.25,
      isZoomSliderShown: this.state.isZoomSliderShown,
      valueChangedCallback: this.changeZoomLevel
   };
   highLightPopoverProps = {
      isHeaderVisible: false,
      isMenuVisible: this.state.isHighlightPopoverVisible,
      placement: {
        isCustomPlacement:false
     }
   };
    bookmarkLinkProps = {
      isBookmarked: this.state.isBookmarked
    };
   highlightMenuProps = {
      alignment: "left",
      menuType: AppConstants.SlidingMenuTypes.HIGHLIGHTS,
      menuItemClicked: this.navigateToHighlightLocation,
      isMenuVisible: this.state.isHighlightsMenuVisible,
      menuClosed:this.updateMenuState
    };
    bookmarkMenuProps = {
      alignment: "left",
      menuType: AppConstants.SlidingMenuTypes.BOOKMARK,
      menuItemClicked: this.navigateToBookmarkLocation,
      isMenuVisible: this.state.isBookmarkMenuVisible,
      menuClosed:this.updateMenuState
    };
   notesModalProps = {
      modalType: AppConstants.ModalTypes.NOTES,
      modalSize:"small",
      showModal: this.state.isNotesModalVisible,
      modalTitle: DataFormatter.getObjectText(Localization, (lang + ".PageText.TakeNote")),
      closeCallback:this.closeModal,
      okCallback:this.applyModalChanges,
      okLabel: DataFormatter.getObjectText(Localization, (lang + ".PageText.Save")),
      headerClass:"modalHeader notesModalHeader",
      bodyClass:"modalBody",
      footerClass:"modalFooter"
    };
 }

 /*
closePopoutMenu
 */
 closePopoutMenu = function() {
  this.setState({
    isLinkModalShown: false,
    linkUrl: ""
  });
 }

 showNotesOverlay = function(highlight,isNewHighlight) {
    this.setState({
      isNotesModalVisible: true,
      currentHighlight :{
        data: highlight,
        highlightedText: highlight.note,
        comment: highlight.comment ? highlight.comment : ' ',
        isNewHighlight: isNewHighlight
      }
    });
  }
  /*
  This method is used to render the PDF book panel
  */
  render = function() {
    this.initializeComponentProps();
    return (
      <div id="mainContainer" className="pdf-fwr-pc-main">
         <ZoomSlider {...zoomSliderProps} />
      <div className = 'bookmarkbutton' onClick={this.handleBookmark.bind(this)}>
         <BookmarkLink {...bookmarkLinkProps}>
         </BookmarkLink>
      </div>
        <SlidingMenu  {...tocMenuProps}>
          <div id="tocContainer">
          </div>
        </SlidingMenu>
        <SlidingMenu  {...highlightMenuProps}>
          {this.renderHighlights()}
        </SlidingMenu>
        <SlidingMenu  {...bookmarkMenuProps}>
          {this.renderBookmarks()}
        </SlidingMenu>
        <LinkModal isLinkModalShown={this.state.isLinkModalShown} linkUrl={this.state.linkUrl} linkCloseCallback = {this.closePopoutMenu.bind(this)}/>
        <AudioModal isAudioModalShown={this.state.isAudioModalShown} audioLinkUrl={this.state.audioLinkUrl} audioLinkCloseCallback = {this.closeAudioPopoutMenu.bind(this)}/>
        <LoadingOverlay isLoading={ this.state.isLoading}/>
        <div id="right" className="pdf-fwr-pc-right">
         <div id="toolbar" className="pdf-fwr-toolbar"></div>
          <div id="frame">
            <div id="docViewer" className="docViewer">
            <ModalDialog {...notesModalProps}>
          <div className='notesContainer'>
            <div className='highlightedTextContainer'>
              <label title={this.state.currentHighlight.highlightedText }
              className='selectedText ellipsis multiline'>
              {this.state.currentHighlight.highlightedText}</label>
            </div>
            <div id='currentNoteContainer' className='currentNoteContainer'>
              <textarea id='currentNote' className='currentNote' >{this.state.currentHighlight.comment.trim()}</textarea>
            </div>
          </div>
        </ModalDialog>
             <PopoverMenu {...highLightPopoverProps}>
              <div className='highlightPopoverContainer'>
               <div className='highlightText'><a onClick={this.createNewHighlight.bind(this)}>{DataFormatter.getObjectText(Localization, (lang + ".PageText.Highlight"))}</a></div>
                <div className = 'takeNotes'><a onClick={this.createNewNote.bind(this)}>{DataFormatter.getObjectText(Localization, (lang + ".PageText.Note"))}</a></div>
                <div className = 'cancelSelection'><a onClick={this.cancelUserSelection.bind(this)}>{DataFormatter.getObjectText(Localization, (lang + ".PageText.Cancel"))}</a></div>
              </div>
            </PopoverMenu>
            </div>
          </div>
        </div>
      </div>
    );
  }

/*
 This method manages the state of the loading overlay
 */
 showMenu = function(menuType) {
   switch(menuType) {
     case AppConstants.SlidingMenuTypes.TOC:
     pdfWrapper.createTOCContent();
     this.hideAudioPanel();
     this.setState({
       isTOCMenuVisible: true
     });
     break;
     case AppConstants.SlidingMenuTypes.HIGHLIGHTS:
     var productId = DataFormatter.getObjectInStorage("productId");
     AppActions.getBookHighlights(productId);
     this.hideAudioPanel();
      this.setState({
        isHighlightsMenuVisible: true
      });
      break;
      case AppConstants.SlidingMenuTypes.BOOKMARK:
      this.hideAudioPanel();
      var productId = DataFormatter.getObjectInStorage("productId");
      AppActions.getBookHighlights(productId);
      this.setState({
        isBookmarkMenuVisible: true
      });
      break;
      case AppConstants.SlidingMenuTypes.ZOOM100:
      this.hideAudioPanel();
           this.changeZoomLevel(1);
      break;
      case AppConstants.SlidingMenuTypes.ZOOM125:
      this.hideAudioPanel();
          this.changeZoomLevel(1.25);
      break;
      case AppConstants.SlidingMenuTypes.ZOOM150:
      this.hideAudioPanel();
         this.changeZoomLevel(1.5);
      break;
      case AppConstants.SlidingMenuTypes.ZOOM175:
      this.hideAudioPanel();
          this.changeZoomLevel(1.75);
      break;
      case AppConstants.SlidingMenuTypes.ZOOM200:
      this.hideAudioPanel();
         this.changeZoomLevel(2);
      break;
   }
 }

 /*
  Saves a note to the server along with the highlight if new.
  */
  saveNote = function(comment) {
    var bookId = DataFormatter.getObjectInStorage('productId');
    var highlight = this.state.currentHighlight.data;
    highlight.comment = comment;
    if(this.state.currentHighlight.isNewHighlight) {
      highlight.isNewHighlight = true;
    }
    else {
      highlight.isNewHighlight = false;
      highlight.pageInformation = {
        pageId: highlight.pageId,
        pageNumber: highlight.pageIndex
      };
    }
    AppActions.manageHighlight(highlight);
  }

 /*
  This callback is fired on clicking ok of the modal dialog
  As of now this is used for chapter navigation in the book panel.
  */
  applyModalChanges = (data) => {
    this.manageLoadingOverlay(true);
    this.setState({
        isNotesModalVisible:false
      });
      var currentHighlight = this.state.currentHighlight;
      this.setState({
        currentHighlight: currentHighlight
      });
      var comment = DataFormatter.readNodeValue(data.children['currentNoteContainer'].children['currentNote']);
      this.saveNote(comment);
  }


closeAudioPopoutMenu = function() {
  this.setState({
    isAudioModalShown: false,
    audioLinkUrl:""
  })
}
  /*
  This method is used to change the current Zoom Level. This Function is triggered on :
  1. Document Load
  2. Zoom Slider Change
  */
  changeZoomLevel = (newValue) => {
      try{
       document.querySelector('.dropdown-toggle').click(); 
     }catch(e){}       
       var newZoomLevel = parseFloat(newValue);
       pdfWrapper.setCurrentZoomLevel(newZoomLevel);
       var elementToChange = "zoom_" + String(newValue * 100);
       var zoomElement = document.querySelectorAll('.zoom_element');
       for(var i =0 ; i<zoomElement.length; i++) {
        zoomElement[i].style.backgroundColor = "#2E3336";
       }
       document.getElementById(elementToChange).style.backgroundColor = "#1f65e7";
       this.restoreHighlights();
      }

/*
  This callback is fired for closing the modal dialog.
  */
  closeModal = (modalType, element) => {
    // Hide loading overlay
    this.manageLoadingOverlay(false);
    switch(modalType) {
      case AppConstants.ModalTypes.CHAPTER:
      this.setState({
        isChapterModalShown:false
      });
      break;
      case AppConstants.ModalTypes.NOTES:
      this.setState({
        isNotesModalVisible:false
      });

      var currentHighlight = this.state.currentHighlight;
      if(element.classList.contains('Cancel')) {
      if(this.state.currentHighlight.isNewHighlight) {
           var highlight = currentHighlight.data;
           var bookId = DataFormatter.getObjectInStorage('productId');
        highlight.bookId = bookId;
        highlight.isNewHighlight = true;
        AppActions.manageHighlight(highlight);
      }
     }
      if(element.classList.contains('close')) {
        currentHighlight.data.shouldDeleteHighlight = true;
        this.setState({
          currentHighlight: currentHighlight
        });
        this.saveNote(this.state.currentHighlight.data.comment);
      }
    this.manageLoadingOverlay(true);
    setTimeout(this.setLoadingFalse,2000);
    break;
    }

  }

 /*
  This Method takes care of the navigation to the next page in the book
  Hide the menu if the user makes a selection and clicks outside
  Shows the menu if the user makes a selection.
  */
  manageHighlightPopover = (selection) => {
    this.setState({
       isHighlightsMenuVisible: false,
       isTOCMenuVisible: false,
       isBookmarkMenuVisible:false
    });
    if(selection.length > 0)
    {
      this.setState({
       isHighlightPopoverVisible:true
      });
    } else {
      this.setState({
       isHighlightPopoverVisible:false
      });
    }
  }

/*
 Handles the click callback when any item in the header is clicked.
 */
 handleBookHeaderAction = () => {
   var itemClicked = AppStore.response;
   switch(itemClicked)
   {
     case AppConstants.BookHeaderOptions.TOC:
     this.showMenu(itemClicked);
     break;
     case AppConstants.BookHeaderOptions.HIGHLIGHTS:
     this.showMenu(itemClicked);
     break;
     case AppConstants.BookHeaderOptions.BOOKMARK:
     this.showMenu(itemClicked);
     break;
     case AppConstants.BookHeaderOptions.ZOOM100:
     this.showMenu(itemClicked);
     break;
      case AppConstants.BookHeaderOptions.ZOOM125:
     this.showMenu(itemClicked);
     break;
      case AppConstants.BookHeaderOptions.ZOOM150:
     this.showMenu(itemClicked);
     break;
      case AppConstants.BookHeaderOptions.ZOOM175:
     this.showMenu(itemClicked);
     break;
      case AppConstants.BookHeaderOptions.ZOOM200:
     this.showMenu(itemClicked);
     break;
     case AppConstants.BookHeaderOptions.AUDIOICON:
     this.audioIconClicked();
     break;
     default:
     break;
   }
 }


  audioIconClicked = function() {
    if(document.querySelector(".audioContainer")) {
      if(document.querySelector(".audioContainer").style.visibility == "visible" || document.querySelector(".audioContainer").style.visibility == "") {
        document.querySelector(".audioContainer").style.visibility = "hidden";
      }else {
        document.querySelector(".audioContainer").style.visibility = "visible";
      }
      }
    }

    hideAudioPanel = function() {
       if(document.querySelector(".audioContainer")) {
       document.querySelector(".audioContainer").style.visibility = "hidden";
      }
    }

  deleteBookmark = function(bookmarktoDelete) {
   var bookmark = {};
   bookmark.isNewBookmark = false;
   bookmark.shouldDeleteId = bookmarktoDelete.id;
   bookmark.bookId = bookmarktoDelete.sourceId;
   bookmark.title = bookmarktoDelete.comment;
   bookmark.pageNumber = bookmarktoDelete.pageId;
   AppActions.manageBookmark(bookmark);
 }

 updateBookmark = function() {
   var bookmarks = this.state.bookmarks;
   var currentPage = pdfWrapper.getCurrentPage() + 1;
    var currentbookmarksList = bookmarks.filter(function(bookmark){
        return bookmark.pageIndex == currentPage;
    });
    if(currentbookmarksList.length > 0) {
        this.setState({
            currentBookmark: currentbookmarksList[0].id,
            isBookmarked: true
        });
    } else {
        this.setState({
            isBookmarked: false
     });
    }
 }

 handleBookmark = function() {
   var bookmark = {};
   var bookId = DataFormatter.getObjectInStorage('productId');
   var pageNumber = pdfWrapper.getCurrentPage() + 1;
   bookmark.bookmarkHash = "@0.000000";
    var title = "Page " + pageNumber;
    bookmark.bookId = bookId;
    bookmark.pageNumber = pageNumber;
    bookmark.pageIndex = pageNumber - 1;
    bookmark.title = title;
    if(this.state.isBookmarked) {
        bookmark.isNewBookmark = false;
        bookmark.shouldDeleteId = this.state.currentBookmark;
        this.setState({
        isBookmarked: false
      });
    } else {
       bookmark.isNewBookmark = true;
       this.setState({
        isBookmarked: true
      });
    }
   AppActions.manageBookmark(bookmark);
  }

 /*
   This method is used to refresh the bookmarks panel with the latest Content
  It is called in the following cases.
  1. First time load of the book.
  2. After any bookmarks are added/deleted.

  */

  updateBookmarksPanel() {
    this.manageLoadingOverlay(false);
    var bookmarksList= AppStore.bookmarkresponse;
    this.setState({
      bookmarks: bookmarksList.sortedBookmarks
     });
    var currentPage = pdfWrapper.getCurrentPage() + 1;
    var currentbookmarksList = bookmarksList.sortedBookmarks.filter(function(bookmark){
        return bookmark.pageIndex == currentPage;
    });
    if(currentbookmarksList.length > 0) {
        this.setState({
            currentBookmark: currentbookmarksList[0].id,
            isBookmarked: true
        });
    } else {
        this.setState({
            isBookmarked: false
     });
    }
  }

  gotoBookmarkPage = function(bookmark) {
      var curPage = pdfWrapper.getCurrentPage() + 1;
      if(bookmark.pageIndex !== curPage) {
          pdfWrapper.gotoPdfPage(parseInt(bookmark.pageIndex)- 1, 0);
      }
       DataFormatter.createAWSSession();
    DataFormatter.sendAWSEvent("bookmark", { "action": "navigate" , "book_title" : bookTitle , "book_id" : bookId , "selected_bookmark" : bookmark.note , "user_id": userId});
  }

   /*
  This method makes a call to the SDK on click of a highlights item
  Takes - event - Takes the event bubbled from the menu component.
  */
  navigateToHighlightLocation = function(element) {
    this.setState({
       isHighlightsMenuVisible: false,
       isTOCMenuVisible: false
    });
      var top = null;
      var pageNumber = element.getAttribute("data-pageindex");
      var hash = element.getAttribute("data-highlighthash");
      try{
      top = pdfWrapper.getScrollLocation(hash);
      top = parseInt(top);
      }catch(e) {

      }
      pageNumber = parseInt(pageNumber) - 1 ;
      if(top) {
        pdfWrapper.gotoPdfPage(pageNumber, top);
      }
      pdfWrapper.gotoPdfPage(pageNumber, 0);
  }


 /*
 This method is used to handle the state of the highlights and TOC menus.
 */
 updateMenuState = function(menuType) {
   switch(menuType) {
     case AppConstants.SlidingMenuTypes.TOC:
     this.setState({
       isTOCMenuVisible: false
     });
     break;
     case AppConstants.SlidingMenuTypes.HIGHLIGHTS:
      this.setState({
        isHighlightsMenuVisible: false
      });
      break;
      case AppConstants.SlidingMenuTypes.BOOKMARK:
      this.setState({
        isBookmarkMenuVisible: false
      });
      break;
      case AppConstants.SlidingMenuTypes.ZOOM:

      break;
   }
 }

/*
 This method is a event callback triggered from PDFWrapper
 */
 pdfpageChanged = function() {
    this.restoreHighlights();
    updateMenuState("TOC");
    return;
 }

/*
 This method will load overlay
 when page content is loaded
 */
 setLoadingTrue = () => {
  setTimeout(this.setLoadingFalse, 10000);
   this.manageLoadingOverlay(true);
 }

  /*
 This method handles cutting of the loading overlay
 after page content is loaded
 */
 setLoadingFalse = () => {
   this.manageLoadingOverlay(false);
 }

/*
 This method manages the state of the loading overlay
 Takes - isLoading - overlay is shown if true, hidden if false.
 */
 manageLoadingOverlay = function(isLoading) {
   this.setState({
     isLoading: isLoading
   });
 }

 /*
  This method is used to set the current page number to the local storage for
  use when the user refreshes the page in the browser
  */
  cancelUserSelection = function(pageNumber) {
    this.setState({
      isHighlightPopoverVisible: false
    });
  }

};
export default PDFPanel;
