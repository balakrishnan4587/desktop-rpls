import React from 'react';
import AppActions from '../actions/app.actions';
import AppStore from '../stores/app.store';
import AppConstants from '../constants/app.constants';
import DataFormatter from './utilities/dataFormatter'
import EPubWrapper from './wrappers/ePubWrapper';
import ModalDialog from './modalDialog';
import LoadingOverlay from './loadingOverlay';
import Footer from './footerbar';
import SlidingMenu from './slidingMenu/slidingMenu';
import PopoverMenu from './popoverMenu/popoverMenu';
import HighlightItem from './highlightItem';
import Bookmark from './bookmark';
import BookmarkLink from './bookmarkLink';
import Accessibility from './accessibility';
import Localization from './localization';

let ePubWrapper = {};
let footerProps, chapterModalProps, notesModalProps, AccessibilityProps,tocMenuProps,highlightMenuProps,bookmarkLinkProps, bookmarkMenuProps, highLightPopoverProps = {};
let navigationItemClicked = false, isHighlightInCurrentPage = false;
let isRefreshed = false;
var lang = DataFormatter.getLanguage();
var userId = String(DataFormatter.getKeyFromObject("userInformation", "id"));
var bookTitle = "" , bookId = "";
try {
bookTitle = DataFormatter.getObjectInStorage("bookTitle");
bookId = DataFormatter.getObjectInStorage("bookId");
}catch(e)
{

}
if(DataFormatter.getObjectInStorage('curpagepath') !== null){
  isRefreshed = true;
}

class BookPanel extends React.Component {
  constructor() {
    super();
    //Bind events for es6 syntax
    this.handleBookHeaderAction = this.handleBookHeaderAction.bind(this);
    this.isElementInViewport = this.isElementInViewport.bind(this);
    this.getTitle = this.getTitle.bind(this);
    this.getProductId = this.getProductId.bind(this);
    this.updateBookmarksPanel  = this.updateBookmarksPanel.bind(this);
    this.handleBookmark = this.handleBookmark.bind(this);
    this.changeFont = this.changeFont.bind(this);
    this.handleScroll = this.handleScroll.bind(this);
    this.updateBookPanel = this.updateBookPanel.bind(this);
    this.updateHighlightsPanel = this.updateHighlightsPanel.bind(this);
    this.gotoHighlight = this.gotoHighlight.bind(this);
    this.handleScrollTo = this.handleScrollTo.bind(this);
    this.jumpToBookPosition = this.jumpToBookPosition.bind(this);
    this.fixedLayoutScaling = this.fixedLayoutScaling.bind(this);
    this.scaleIframe = this.scaleIframe.bind(this);
    this.showMenu = this.showMenu.bind(this);
    this.handleTOCNavigation = this.handleTOCNavigation.bind(this);
    this.navigateToHighlightLocation = this.navigateToHighlightLocation.bind(this);
    this.manageLoadingOverlay = this.manageLoadingOverlay.bind(this);
    this.updateMenuState = this.updateMenuState.bind(this);
    this.restoreHighlights = this.restoreHighlights.bind(this);
    this.showNotesOverlay = this.showNotesOverlay.bind(this);
    this.saveNote = this.saveNote.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.setCurrentPageInStorage = this.setCurrentPageInStorage.bind(this);
    this.handleHighlightClick = this.handleHighlightClick.bind(this);
    this.cancelUserSelection = this.cancelUserSelection.bind(this);
    this.hideAccessibilityMenu = this.hideAccessibilityMenu.bind(this);
    this.getScrollPercentage = this.getScrollPercentage.bind(this);
    this.getWindowYscroll =  this.getWindowYscroll.bind(this);
    this.getWindowHeight =  this.getWindowHeight.bind(this);
    this.getDocHeight =  this.getDocHeight.bind(this);
  }
  state = {
    isChapterModalShown:false,
    isAccessibilityShown:false,
    isNotesModalVisible: false,
    isSliderShown:false,
    isTOCMenuVisible: false,
    isHighlightsMenuVisible: false,
    isBookmarkMenuVisible:false,
    pagesCount:0,
    isLoading: false,
    currentPage: 1,
    prevFlipperClass:"disableClick",
    nextFlipperClass:"",
    isBookmarked: false,
    tocContent:"",
    bookmarks:[],
    highlights:[],
    isHighlightPopoverVisible: false,
    currentHighlight : {
      highlightedText: '',
      comment:''
    },
    currentBookmark : ''
  };

  /*
  This method manages the state of the loading overlay
  Takes - isLoading - overlay is shown if true, hidden if false.
  */
  manageLoadingOverlay = function(isLoading) {
    console.log('epub manageLoadingOverlay called', isLoading);
    this.setState({
      isLoading: isLoading
    });
  }

  gotoHighlight = function() {
    var element;
      var highlightFlag = DataFormatter.getObjectInStorage('highlightFlag'); 
      var bookmarkjump = DataFormatter.getObjectInStorage('bookmarkjump'); 
      if(highlightFlag ){   
      var targetHighlightHash = DataFormatter.getObjectInStorage('targetHighlightHash');      
      if(targetHighlightHash != null) {
      var scrollPercentage = targetHighlightHash.split('@')[1];
      var targetXPath = targetHighlightHash.split('::')[0];
      var poppedOutXpath = targetXPath.split('/');
      poppedOutXpath.pop();
      targetXPath = "";
      for(var i=1; i < poppedOutXpath.length ; i++) {
        targetXPath = targetXPath + "/" + poppedOutXpath[i];
      }
       var iFrame = document.querySelectorAll('.bookFrame')[0].contentWindow ? document.querySelectorAll('.bookFrame')[0].contentWindow : window;
       var totalScrollHeight = iFrame.document.body.scrollHeight;      
      if(targetXPath.indexOf('/') > -1) {       
      element = this.getNode(iFrame, targetXPath);
      }
     
      if(bookmarkjump) {
      var scrollY = (scrollPercentage * totalScrollHeight) + 100;  
      iFrame.scrollTo(0, scrollY);  
      } else {
        var scrollY = (scrollPercentage * totalScrollHeight) ;
        if(element){
        element.scrollIntoView(true);  
      }else {
        iFrame.scrollTo(0, scrollY); 
      }

     }
      DataFormatter.setObjectInStorage("targetHighlightHash", "00::@0");
      DataFormatter.setObjectInStorage('highlightFlag', false);
      DataFormatter.setObjectInStorage('bookmarkjump', false);
      } 
    } else{
      if(DataFormatter.getObjectInStorage("pagenavigated")){
        var iFrame = document.querySelectorAll('.bookFrame')[0].contentWindow ? document.querySelectorAll('.bookFrame')[0].contentWindow : window;
        iFrame.scrollTo(0, scrollY); 
        DataFormatter.setObjectInStorage('pagenavigated', false);
      }
    } 
  }

  getNode = function(root, XPath) {
    var contentDocument = root.document;
    var contentBody = root.document.body; 
    try{
      var element = contentDocument.evaluate("." + XPath, contentBody, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
    }catch(e){
      return false;
    }
    return element;
  }

/* Hide the Accessibility Menu
*/
  hideAccessibilityMenu = function() {
    console.log('epub hideAccessibilityMenu called');
    try{
       document.querySelector('.accessibilityContainer').style.visibility = "hidden";
    }catch(e) {

    }
  }
  /*
  This method manages the state of the loading overlay
  Takes - isLoading - overlay is shown if true, hidden if false.
  */
  showMenu = function(menuType) {
console.log('epub showMenu called', menuType);
    switch(menuType) {
      case AppConstants.SlidingMenuTypes.TOC:
      this.hideAccessibilityMenu();
      this.setState({
        isTOCMenuVisible: true
      });
      break;
      case AppConstants.SlidingMenuTypes.HIGHLIGHTS:
      this.hideAccessibilityMenu();
      var bookDetails = DataFormatter.getObjectInStorage('productId');
       AppActions.getBookHighlights(bookDetails);
      this.setState({
        isHighlightsMenuVisible: true
      });
      break;
      case AppConstants.SlidingMenuTypes.BOOKMARK:
       this.hideAccessibilityMenu();
       var bookDetails = DataFormatter.getObjectInStorage('productId');
       AppActions.getBookBookmarks(bookDetails);
       this.setState({
        isBookmarkMenuVisible: true
      });
      break;
      case AppConstants.SlidingMenuTypes.ACESSIBILITY:
      this.manageAccessibilityMenu();
      break;
      case AppConstants.SlidingMenuTypes.ZOOM100:
       this.hideAccessibilityMenu();
           this.changeZoomLevel(1);
      break;
      case AppConstants.SlidingMenuTypes.ZOOM125:
       this.hideAccessibilityMenu();
          this.changeZoomLevel(1.25);
      break;
      case AppConstants.SlidingMenuTypes.ZOOM150:
       this.hideAccessibilityMenu();
         this.changeZoomLevel(1.5);
      break;
      case AppConstants.SlidingMenuTypes.ZOOM175:
       this.hideAccessibilityMenu();
          this.changeZoomLevel(1.75);
      break;
      case AppConstants.SlidingMenuTypes.ZOOM200:
       this.hideAccessibilityMenu();
         this.changeZoomLevel(2);
      break;
    }
  }

  /*
  This method is used to change the current Zoom Level. This Function is triggered on :
  1. Document Load
  2. Zoom Level Change
  */
  changeZoomLevel = (newValue, firstLoad) => {
console.log('epub changeZoomLevel called', newValue, firstLoad);
    var isFixedLayout = DataFormatter.getObjectInStorage('isFixedLayout');
    if(document.querySelector('.dropdown-toggle')) {
      try{
       document.querySelector('.dropdown-toggle').click(); 
     }catch(e){}       
       var newZoomLevel = parseFloat(newValue);       
       if(newZoomLevel == 1) {
         if(isFixedLayout) {                  
        document.querySelector('.bookFrame').contentWindow.document.body.style.overflowY = "hidden";
        }
        // document.querySelector('.bookFrame').contentWindow.document.body.scrollX = "no";
        document.querySelector('.bookFrame').contentWindow.document.body.style.overflowX = "hidden";
       } else {
        document.querySelector('.bookFrame').contentWindow.document.body.scroll = "";
        document.querySelector('.bookFrame').contentWindow.document.body.style.overflowY = "scroll";
        document.querySelector('.bookFrame').contentWindow.document.body.style.overflowX = "scroll";
       }
       this.scaleTransform(newZoomLevel);
       var elementToChange = "zoom_" + String(newValue * 100);
       var zoomElement = document.querySelectorAll('.zoom_element');
       for(var i =0 ; i<zoomElement.length; i++) {
        zoomElement[i].style.backgroundColor = "#2E3336";
       }
       document.getElementById(elementToChange).style.backgroundColor = "#1f65e7";
        if(firstLoad) {
         try{
       document.querySelector('.dropdown-toggle').click(); 
     }catch(e){}      
       }
     }
  }

 /*
  This method is used to scale the Iframe :
  1. Document Load
  2. Zoom Level Change
  */
  scaleTransform = (newValue) => {
console.log('epub scaleTransform called', newValue);
    document.querySelector('.bookFrame').contentWindow.document.body.style.transform = "scale(" + newValue + ")";
    document.querySelector('.bookFrame').contentWindow.document.body.style.WebkitTransform = "scale(" + newValue + ")";
    document.querySelector('.bookFrame').contentWindow.document.body.style.MozTransform = "scale(" + newValue + ")";
    document.querySelector('.bookFrame').contentWindow.document.body.style.msTransform = "scale(" + newValue + ")";
    document.querySelector('.bookFrame').contentWindow.document.body.style.transformOrigin = "0 0";
    document.querySelector('.bookFrame').contentWindow.document.body.style.msTransformOrigin = "0 0";
    document.querySelector('.bookFrame').contentWindow.document.body.style.WebkitTransformOrigin = "0 0";
    document.querySelector('.bookFrame').contentWindow.document.body.style.MozTransformOrigin = "0 0";
  }

  /*
  This method makes a call to the SDK on click of a TOC item
  Takes - event - Takes the event bubbled from the menu component.
  */
  handleTOCNavigation = function(element) {
console.log('epub schandleTOCNavigationaleTransform called', element);
    // Call the SDK to navigate to the TOC link.
    var href = element.getAttribute('href');
    var tocscroll = href.split("#")[1];
    if(tocscroll != undefined)
    {
    DataFormatter.setObjectInStorage("tocscroll", tocscroll);
    DataFormatter.setObjectInStorage("tocflag", true);
  } else {
    DataFormatter.setObjectInStorage("tocscroll", false);
    DataFormatter.setObjectInStorage("tocflag", false);
  }
    ePubWrapper.navigateToTOCLink(element);
  }

  /*
  This method makes a call to the SDK on click of a highlights item
  Takes - event - Takes the event bubbled from the menu component.
  */
  navigateToHighlightLocation = function(element) {
    // Show loading overlay
    console.log('epub navigateToHighlightLocation called', element);
    this.manageLoadingOverlay(true);
    this.setState({
       isHighlightsMenuVisible: false,
       isTOCMenuVisible: false
    });
    var targetChapter = element.getAttribute("data-pageindex");
    var currentPage = DataFormatter.getObjectInStorage('curbookpageno');
    var targetHighlightHash = element.getAttribute("data-highlighthash");
    DataFormatter.setObjectInStorage('targetHighlightHash',targetHighlightHash);
    DataFormatter.setObjectInStorage('highlightFlag',true);
    /*
    If the Highlight is in the current page, then do not load the Iframe again, just scroll to the location
    */
    if(targetChapter == currentPage)
    {
      this.gotoHighlight();
      this.manageLoadingOverlay(false);
    } else {
    // Call the SDK to navigate to the highlights location.
      ePubWrapper.displayChapter(targetChapter);
    // Set the current page in local storage.
      this.setCurrentPageInStorage(targetChapter);
    }
  }

  /*
  This method hides or shows the body scroll bar based
  on a condition.
  */
  manageBodyScroll = function(hideScroll)
  {
console.log('epub manageBodyScroll called', hideScroll);
    if(hideScroll) {
      // Hide the body scroll and set the window scroll to the top.
      document.body.style.overflow = 'hidden';
      window.scrollTo(0,0);
    }
    else {
      document.body.style.overflow = 'visible';
    }
  }
  /*
  This method handles the following
  1. Initializing and loading the eBook with content.
  2. Setting up the book panel component as a whole
  */
  componentDidMount = function() {
    console.log('epub componentDidMount called');
    // Hide the scroll bar on body if necessary.
    this.manageBodyScroll(true);
    var bookDetails = DataFormatter.getObjectInStorage('currentBook');

    // setting the request header
    var usertoken = DataFormatter.getKeyFromObject("userInformation","userToken");
    var headerParameters =
    {
      'appId': AppConstants.AppID,
      'token': usertoken
    }
    //Remove this once we get a proper book URL
    var config = {
      /*
        ---to pass the URL---
        bookDataPath: "assets/gls-book-object.json"
      */
      //to pass json data
      bookDataPath: bookDetails,
      targetElement:"bookRenderingArea",
      requestHeaderParam:headerParameters
    };
    console.log('epub ', config);
    // Initialize the eBook with
    ePubWrapper = new EPubWrapper(config);
    ePubWrapper.createEbookInstance();
    // Register to basic epub events.
    ePubWrapper.registerEvent('pageLoaded', this.updateBookPanel);
    ePubWrapper.registerEvent('error', this.handleBookError);
    ePubWrapper.registerEvent('linkClicked',this.handleLinks);
    ePubWrapper.registerEvent('textSelected', this.manageHighlightPopover)
    ePubWrapper.registerEvent('highlightClicked', this.handleHighlightClick);
    ePubWrapper.registerEvent('scrollTo', this.handleScrollTo);
    ePubWrapper.registerEvent('highlightRestored', this.gotoHighlight);
    
    setTimeout(this.gotoHighlight, 500);
    setTimeout(this.gotoHighlight, 1000);
    // Show loading overlay
    this.manageLoadingOverlay(true);
    AppStore.on(AppConstants.EventTypes.BOOK_HEADER_ITEM_CLICKED, this.handleBookHeaderAction);
    AppStore.on(AppConstants.EventTypes.BOOK_HIGHLIGHTS_FETCHED, this.updateHighlightsPanel);
    AppStore.on(AppConstants.EventTypes.BOOK_BOOKMARKS_FETCHED, this.updateBookmarksPanel);
  setTimeout(function(){
AppActions.getBookHighlights(this.getProductId(bookDetails.id));
  }, 1000);
   // Get the user highlights for that book
    AppActions.getBookHighlights(this.getProductId(bookDetails.id));
    DataFormatter.setObjectInStorage('productId', this.getProductId(bookDetails.id));

  }
  /*
  Clean up event handlers and such.
  */
  componentWillUnmount = function() {
    document.querySelector('.bookFrame').contentWindow.window.removeEventListener('scroll', this.handleScroll);
    window.removeEventListener("resize", this.fixedLayoutScaling);
    DataFormatter.setObjectInStorage('ePubunmounted', 'true');
    DataFormatter.setObjectInStorage('isFixedLayout', false);
    // Show the body scroll if valid.
    DataFormatter.setObjectInStorage('currentBook',null);
    navigationItemClicked = false;
    isRefreshed = false;
    this.manageBodyScroll(false);

    AppStore.removeListener(AppConstants.EventTypes.BOOK_HEADER_ITEM_CLICKED, this.handleBookHeaderAction);
    AppStore.removeListener(AppConstants.EventTypes.BOOK_HIGHLIGHTS_FETCHED, this.updateHighlightsPanel);
    AppStore.removeListener(AppConstants.EventTypes.BOOK_BOOKMARKS_FETCHED, this.updateBookmarksPanel);

  }
  /*
  This Method takes care of the navigation to the previous page in the book
  */
  navigateToPreviousPage = (bookDetails) => { 
   console.log('epub navigateToPreviousPage called', bookDetails);
    DataFormatter.setObjectInStorage("pagenavigated", true);
    this.setState({
      isHighlightPopoverVisible: false
    });
    // Show loading overlay
    this.manageLoadingOverlay(true);
    this.hideAccessibilityMenu();
    ePubWrapper.navigateToPreviousPage();
    navigationItemClicked = true;
  }
  /*
  This Method takes care of the navigation to the next page in the book
  */
  navigateToNextPage = (bookDetails) => {
   console.log('epub navigateToNextPage called', bookDetails);  
    DataFormatter.setObjectInStorage("pagenavigated", true);
    this.setState({
      isHighlightPopoverVisible: false
    });

 this.hideAccessibilityMenu();
 // Show loading overlay
 console.log('epub hideAccessibilityMenu called');
    this.manageLoadingOverlay(true);
    ePubWrapper.navigateToNextPage();
    navigationItemClicked = true;
  }

  /*
  This Method takes care of the navigation to the next page in the book
  Hide the menu if the user makes a selection and clicks outside
  Shows the menu if the user makes a selection.
  */
  manageHighlightPopover = (selection) => {
console.log('epub manageHighlightPopover called', selection);
    if(document.querySelector('.accessibilityContainer')) {
    document.querySelector('.accessibilityContainer').style.visibility = "hidden";
    }
    this.setState({
       isHighlightsMenuVisible: false,
       updateBookmarksPanel:false,
       isTOCMenuVisible: false,
       isBookmarkMenuVisible:false
    });

    if(selection.toString().trim() !== '') {
      this.setState({
        isHighlightPopoverVisible:true
      });
    }
    else {
      this.setState({
        isHighlightPopoverVisible:false
      });
    }
  }
    /*
  This method is used to hide the TOC and Highlight Menu on various events.
  */
  disableSliderMenu = () => {
    console.log('epub disableSliderMenu called');
    this.setState({
       isHighlightsMenuVisible: false,
       isTOCMenuVisible: false,
       isHighlightPopoverVisible: false,
       isBookmarkMenuVisible:false

    });
  this.hideAccessibilityMenu();
  }
  /*
  This method is used to initialize the props to be passed to each
  component on render.
  */
  initializeComponentProps = function() {
    console.log('epub initializeComponentProps called');
    footerProps = {
      sliderID:"pageNavigationSlider",
      min:1,
      totalPages:this.state.pagesCount,
      sliderValue:this.state.currentPage,
      isPercentageSlider:false,
      step: 1,
      isSliderShown: this.state.isSliderShown,
      valueChangedCallback: this.jumpToBookPosition
    };
    // Props to pass to the modal including callbacks
    chapterModalProps = {
      modalType: AppConstants.ModalTypes.CHAPTER,
      modalSize:"small",
      showModal: this.state.isChapterModalShown,
      modalTitle:"Enter Chapter",
      closeCallback:this.closeModal,
      okCallback:this.applyModalChanges,
      okLabel: "Go to chapter",
      headerClass:"modalHeader",
      bodyClass:"modalBody",
      footerClass:"modalFooter"
    };
    bookmarkLinkProps = {
      isBookmarked: this.state.isBookmarked
    };
     AccessibilityProps = {
      menuType: AppConstants.SlidingMenuTypes.ACESSIBILITY
   };
    notesModalProps = {
      modalType: AppConstants.ModalTypes.NOTES,
      modalSize:"small",
      showModal: this.state.isNotesModalVisible,
      modalTitle: DataFormatter.getObjectText(Localization, (lang + ".PageText.TakeNote")),
      closeCallback:this.closeModal,
      okCallback:this.applyModalChanges,
      okLabel: DataFormatter.getObjectText(Localization, (lang + ".PageText.Save")),
      headerClass:"modalHeader notesModalHeader",
      bodyClass:"modalBody",
      footerClass:"modalFooter"
    };
    tocMenuProps = {
      alignment: "left",
      menuType: AppConstants.SlidingMenuTypes.TOC,
      menuItemClicked: this.handleTOCNavigation,
      isMenuVisible: this.state.isTOCMenuVisible,
      menuClosed:this.updateMenuState
    };
    highlightMenuProps = {
      alignment: "left",
      menuType: AppConstants.SlidingMenuTypes.HIGHLIGHTS,
      menuItemClicked: this.navigateToHighlightLocation,
      isMenuVisible: this.state.isHighlightsMenuVisible,
      menuClosed:this.updateMenuState
    };
    bookmarkMenuProps = {
      alignment: "left",
      menuType: AppConstants.SlidingMenuTypes.BOOKMARK,
      menuItemClicked: this.navigateToBookmarkLocation,
      isMenuVisible: this.state.isBookmarkMenuVisible,
      menuClosed:this.updateMenuState
    };
    highLightPopoverProps = {
      isHeaderVisible: false,
      isMenuVisible: this.state.isHighlightPopoverVisible,
      placement: {
        isCustomPlacement:false
      }
    }
  }
  showNotesOverlay = function(highlight,isNewHighlight) {
    console.log('epub showNotesOverlay called');
    this.setState({
      isNotesModalVisible: true,
      currentHighlight :{
        data: highlight,
        highlightedText: highlight.note,
        comment: highlight.comment ? highlight.comment : ' ',
        isNewHighlight: isNewHighlight
      }
    });
  }

  /*
  This method is used to render the book items one by one based on The
  object retreived from the server.
  */
  renderBookmarks = function()
  {
    console.log('epub renderBookmarks called');
     var self = this;
     if(!this.state.bookmarks || this.state.bookmarks.length === 0)
     {
         return <div className='noBookmarks'>{DataFormatter.getObjectText(Localization, (lang + ".PageText.NoBookmarks"))}</div>
     } else {
        return this.state.bookmarks.map(function(bookmark,index) {
          return <Bookmark bookmarkDeleteCallback ={self.deleteBookmark.bind(self)} bookmarkClickedCallback ={self.gotoBookmarkPage.bind(self)} key ={index} bookmark={bookmark} />;
        });
     }
  }

  /*
  This method is used to render the highlight items one by one based on The
  object retreived from the server.
  */
  renderHighlights = function()
  {
    console.log('epub renderHighlights called');
    var self = this;
     if(!this.state.highlights || this.state.highlights.length === 0)
     {
         return <div className='noHighlights'>{DataFormatter.getObjectText(Localization, (lang + ".PageText.NoHighlights"))}</div>
     } else {
        return this.state.highlights.map(function(highlight,index) {
          return <HighlightItem highlightClickedCallback ={self.showNotesOverlay.bind(self)} key ={index} highlight={highlight} />;
        });
     }
  }
  /*
  This method is used to create a new highlight when the user highlights the Text
  and selects highlight from the context menu.
  */
  createNewHighlight = function(element) {
console.log('epub createNewHighlight called', element);
    this.setState({
      isHighlightPopoverVisible:false
    });
    this.manageLoadingOverlay(true);
    var bookId = DataFormatter.getObjectInStorage('productId');
    var highlight = ePubWrapper.createHighlight();
    highlight.serializedHighlight = highlight.serializedHighlight + "@" + parseFloat(this.getScrollPercentage()).toFixed(6) ;
    this.state.currentHighlight.data = highlight;
    // console.log("Scroll = " + this.getScrollPercentage());
    highlight.bookId = bookId;
    highlight.isNewHighlight = true;
    AppActions.manageHighlight(highlight);
    DataFormatter.clearSelection(document.querySelector('.bookFrame').contentWindow);
  }

 deleteBookmark = function(bookmarktoDelete) {
console.log('epub deleteBookmark called',bookmarktoDelete);
   var bookmark = {};
   bookmark.isNewBookmark = false;
   bookmark.shouldDeleteId = bookmarktoDelete.id;
   bookmark.bookId = bookmarktoDelete.sourceId;
   bookmark.title = bookmarktoDelete.comment;
   bookmark.pageNumber = bookmarktoDelete.pageId;
   AppActions.manageBookmark(bookmark);
 }


/**
 * Get current browser viewpane heigtht
 */
getWindowHeight = function() {
  var currentDocument = document.querySelector('.bookFrame') ? document.querySelector('.bookFrame').contentWindow.document : document;
  var currentWindow = document.querySelector('.bookFrame') ? document.querySelector('.bookFrame').contentWindow : window;
    return currentWindow.innerHeight || 
           currentDocument.documentElement.clientHeight ||
           currentDocument.body.clientHeight || 0;
}

/**
 * Get current absolute window scroll position
 */
getWindowYscroll = function() {
   var currentDocument = document.querySelector('.bookFrame') ? document.querySelector('.bookFrame').contentWindow.document : document;
   var currentWindow = document.querySelector('.bookFrame') ? document.querySelector('.bookFrame').contentWindow : window;
    return currentWindow.pageYOffset || 
           currentDocument.body.scrollTop ||
           currentDocument.documentElement.scrollTop || 0;
}

/**
 * Get current absolute document height
 */
getDocHeight = function() {
  var currentDocument = document.querySelector('.bookFrame') ? document.querySelector('.bookFrame').contentWindow.document : document
    return Math.max(
        currentDocument.body.scrollHeight || 0, 
        currentDocument.documentElement.scrollHeight || 0,
        currentDocument.body.offsetHeight || 0, 
        currentDocument.documentElement.offsetHeight || 0,
        currentDocument.body.clientHeight || 0, 
        currentDocument.documentElement.clientHeight || 0
    );
}
/**
 * Get current vertical scroll percentage
 */
getScrollPercentage = function() {
    return (
        (this.getWindowYscroll()) / this.getDocHeight()
    );
}

/* Function to get the Product ID for the Book ID 
*/
 getProductId = function(bookId) {
   console.log('epub getProductId called', bookId);
  var products = DataFormatter.getObjectInStorage('products');
  var currentProduct = products.filter(function(product) {
    if(product.books[0] != undefined) {
      if(product.books.length > 1) {
       return (product.books[0].id == bookId || product.books[1].id == bookId) ;
       } else {
        return product.books[0].id == bookId
       }
     }
    });
   return currentProduct[0].id;
 }

 isElementInViewport = function(element) {
console.log('epub isElementInViewport called', element);
  var top = element.offsetTop;
  var left = element.offsetLeft;
  var width = element.offsetWidth;
  var height = element.offsetHeight;
  while(element.offsetParent) {
    element = element.offsetParent;
    top += element.offsetTop;
    left += element.offsetLeft;
   }
   var Iframe = document.querySelector('.bookFrame').contentWindow;
   return ( top < (Iframe.pageYOffset + Iframe.innerHeight) && (top + height) > Iframe.pageYOffset);
 }

 getTitle = function() {
console.log('epub getTitle called');
 var elements = document.querySelector('.bookFrame').contentWindow.document.getElementsByTagName('section');
 var viewingElement = [];
     for(var i=0; i<elements.length; i++) {
      var isvisible = this.isElementInViewport(elements[i]);
      if(isvisible){
        viewingElement.push(elements[i]);
    }
  }
  var sectionLength = viewingElement.length;
  if(sectionLength === 1 && viewingElement[sectionLength - 1].querySelector('.title') !=null) {
  return viewingElement[sectionLength - 1].querySelector('.title').innerText;
   } else { if( sectionLength > 1 && viewingElement[sectionLength - 2].querySelector('.title') !=null) {
    return viewingElement[sectionLength - 2].querySelector('.title').innerText;
     } else {
      return false;
     }
   }
 }

  handleBookmark = function() {
console.log('epub handleBookmark called');
    var sectionTitle = this.getTitle();
    var bookmark = {};
    var title;
    var bookId = DataFormatter.getObjectInStorage('productId');
    var pageNumber = ePubWrapper.getCurrentPage();
    if(sectionTitle) {
     title = sectionTitle;
    } else {
     title = document.querySelector('.bookFrame').contentDocument.title || sectionTitle;
     }
    var totalScrollHeight = document.querySelectorAll('.bookFrame')[0].contentWindow.document.body.scrollHeight;
    var currentScrollHeight = document.querySelectorAll('.bookFrame')[0].contentWindow.window.scrollY || document.querySelectorAll('.bookFrame')[0].contentWindow.window.pageYOffset;
    var bookmarkHash = currentScrollHeight / totalScrollHeight;
    bookmark.pageIndex = ePubWrapper.getCurrentPageName(pageNumber);
    if(bookmark.pageIndex.indexOf("/") > -1) {
      bookmark.pageIndex = bookmark.pageIndex.split("/")[1];
    }
    if(!title)
    title = "Page " + pageNumber;
    bookmark.bookId = bookId;
    bookmark.pageNumber = pageNumber;
    bookmark.title = title;
    //bookmark.bookmarkHash ="(null)@" + bookmarkHash;
    bookmark.bookmarkHash ="(null)@" + parseFloat(this.getScrollPercentage()).toFixed(6) ;
    if(this.state.isBookmarked) {
        bookmark.isNewBookmark = false;
        bookmark.shouldDeleteId = this.state.currentBookmark;
        this.setState({
        isBookmarked: false
      });
    } else {
       bookmark.isNewBookmark = true;
       this.setState({
        isBookmarked: true
      });
    }
   AppActions.manageBookmark(bookmark);
  }
  /*
  This method is used to create a new note associated with a highlight.
  */
  createNewNote = function() {
console.log('epub createNewNote called');
    this.setState({
      isHighlightPopoverVisible:false
    });
    var bookId = DataFormatter.getObjectInStorage('productId');
    var highlight = ePubWrapper.createHighlight();
    highlight.note = highlight.selection;
    this.state.currentHighlight.data = highlight;
    highlight.bookId = bookId;
    this.showNotesOverlay(highlight,true);
    DataFormatter.clearSelection(document.querySelector('.bookFrame').contentWindow);
  }
  /*
  Saves a note to the server along with the highlight if new.
  */
  saveNote = function(comment) {
console.log('epub saveNote called', comment);
    var bookId = DataFormatter.getObjectInStorage('productId');
    var highlight = this.state.currentHighlight.data;
    highlight.comment = comment;
    if(this.state.currentHighlight.isNewHighlight) {
      highlight.isNewHighlight = true;
    }
    else {
      highlight.isNewHighlight = false;
      highlight.pageInformation = {
        pageId: highlight.pageId,
        pageNumber: highlight.pageIndex
      };
    }
    AppActions.manageHighlight(highlight);
  }

 changeFont = function (selectTag) {
console.log('epub changeFont called');
     this.setState({value: selectTag.target.value});
     var body= document.querySelector(".bookFrame").contentWindow.document.getElementsByTagName("body")[0];
     body.setAttribute('style',body.getAttribute('style')+'font-family: "'+selectTag.target.value+'";');

          }

  /*
  This method is used to render the book panel along with the following components
  1. Modal dialog - For chapter select
  2. Loading Overlay - For showing operations
  3. Footer bar slider - for moving through the book
  4. Sliding Menu - For showing the TOC and highlight panels.
  */
  render = function() {
console.log('epub render called');
    this.initializeComponentProps();
    return (
      <div className='bookPanelContainer'>
      <div className = 'bookmarkbutton' onClick={this.handleBookmark.bind(this)}>
         <BookmarkLink {...bookmarkLinkProps}>
         </BookmarkLink>
      </div>
      <Accessibility {...AccessibilityProps}/>
        <SlidingMenu  {...tocMenuProps}>
          <div dangerouslySetInnerHTML= {{__html: this.state.tocContent}}>
          </div>
        </SlidingMenu>
        <SlidingMenu  {...highlightMenuProps}>
          {this.renderHighlights()}
        </SlidingMenu>
        <SlidingMenu  {...bookmarkMenuProps}>
          {this.renderBookmarks()}
        </SlidingMenu>
        <LoadingOverlay isLoading={ this.state.isLoading}/>
        <ModalDialog {...chapterModalProps}>
            <div className='jumpChapterContainer'>
            <label className='jumpChapterLabel' for='jumpToChapter'>Chapter</label>
            <input max={this.state.pagesCount} type='number' id='jumpToChapter'/>
            <label className='totalPageCountText'>{'of ' + this.state.pagesCount}
            </label>
            </div>
        </ModalDialog>
        <ModalDialog {...notesModalProps}>
          <div className='notesContainer'>
            <div className='highlightedTextContainer'>
              <label title={this.state.currentHighlight.highlightedText }
              className='selectedText ellipsis multiline'>
              {this.state.currentHighlight.highlightedText}</label>
            </div>
            <div id='currentNoteContainer' className='currentNoteContainer'>
              <textarea id='currentNote' className='currentNote'>{this.state.currentHighlight.comment.trim()}</textarea>
            </div>
          </div>
        </ModalDialog>
        <div className="readingPanel">
          <div className='pageTurnArea FL'>
            <div className={"prevPage arrow " + this.state.prevFlipperClass} onClick={this.navigateToPreviousPage.bind(this)}>&#60;</div>
          </div>
          <div id='bookRenderingArea' className="bookRenderingArea FL">
            <PopoverMenu {...highLightPopoverProps}>
              <div className='highlightPopoverContainer'>
                <div className='highlightText'><a onClick={this.createNewHighlight.bind(this)}>{DataFormatter.getObjectText(Localization, (lang + ".PageText.Highlight"))}</a></div>
                <div className = 'takeNotes'><a onClick={this.createNewNote.bind(this)}>{DataFormatter.getObjectText(Localization, (lang + ".PageText.Note"))}</a></div>
                <div className = 'cancelSelection'><a onClick={this.cancelUserSelection.bind(this)}>{DataFormatter.getObjectText(Localization, (lang + ".PageText.Cancel"))}</a></div>
              </div>
            </PopoverMenu>
          </div>
          <div className='pageTurnArea'>
            <div className={"nextPage arrow " + this.state.nextFlipperClass} onClick={this.navigateToNextPage.bind(this)}>&#62;</div>
          </div>
        </div>
        <Footer {...footerProps} onClick={this.disableSliderMenu}/>
      </div>
    );
  }
  /*
  Handles the click callback when any item in the header is clicked.
  */
  handleBookHeaderAction = () => {
console.log('epub handleBookHeaderAction called');
    var itemClicked = AppStore.response;
    switch(itemClicked)
    {
      case AppConstants.BookHeaderOptions.COVER:
      // Show loading overlay
      this.manageLoadingOverlay(true);
      ePubWrapper.gotoCoverPage();
      // Set the current page in local storage.
      this.setCurrentPageInStorage(1);
      break;
      case AppConstants.BookHeaderOptions.TOC:
      // Show TOC
      this.showMenu(itemClicked);
      break;
      case AppConstants.BookHeaderOptions.CHAPTER:
      this.setState({
        pagesCount: ePubWrapper.getTotalNumberOfPages(),
        isChapterModalShown:true
      });
      break;
      case AppConstants.BookHeaderOptions.NOTES:
      break;
      case AppConstants.BookHeaderOptions.HIGHLIGHTS:
            this.showMenu(itemClicked);
      break;
      case AppConstants.BookHeaderOptions.BOOKMARK:
           this.showMenu(itemClicked);
      break;
      case AppConstants.BookHeaderOptions.SETTINGS:
      break;
      case AppConstants.BookHeaderOptions.REFRESH:
      break;
      case AppConstants.BookHeaderOptions.ACESSIBILITY:
            this.showMenu(itemClicked);
      break;
      case AppConstants.BookHeaderOptions.ZOOM100:
       this.showMenu(itemClicked);
       break;
        case AppConstants.BookHeaderOptions.ZOOM125:
       this.showMenu(itemClicked);
       break;
        case AppConstants.BookHeaderOptions.ZOOM150:
       this.showMenu(itemClicked);
       break;
        case AppConstants.BookHeaderOptions.ZOOM175:
       this.showMenu(itemClicked);
       break;
        case AppConstants.BookHeaderOptions.ZOOM200:
       this.showMenu(itemClicked);
       break;
      default:
      break;
    }
  }
  /*
  This callback is fired for closing the modal dialog.
  */
  closeModal = (modalType, element) => {
    console.log('epub closeModal called', modalType, element);
    // Hide loading overlay
    this.manageLoadingOverlay(false);
    switch(modalType) {
      case AppConstants.ModalTypes.CHAPTER:
      this.setState({
        isChapterModalShown:false
      });
      break;
      case AppConstants.ModalTypes.NOTES:
      this.setState({
        isNotesModalVisible:false
      });

      //While cancelling the Note we can save the selected text as highlight.
      if(element.classList.contains('Cancel')) {
      if(this.state.currentHighlight.isNewHighlight) {
        var highlight = this.state.currentHighlight.data;
        var bookId = DataFormatter.getObjectInStorage('productId');
        highlight.bookId = bookId;
        highlight.isNewHighlight = true;
        AppActions.manageHighlight(highlight);
      }
    }
      // Delete note button is clicked to close the modal.
      if(element.classList.contains('close')) {
        // Show loading overlay
        this.manageLoadingOverlay(true);
        var currentHighlight = this.state.currentHighlight;
        currentHighlight.data.shouldDeleteHighlight = true;
        this.setState({
          currentHighlight: currentHighlight
        });
        // check & set the flag if the highlight has been present in currentpage.
        var curPage = DataFormatter.getObjectInStorage('curbookpageno');
        if((curPage === parseInt(this.state.currentHighlight.data.pageIndex))) {
          isHighlightInCurrentPage = true;
        } else {
          if(this.state.currentHighlight.data.pageInformation) {
            if((curPage === parseInt(this.state.currentHighlight.data.pageInformation.pageNumber))) {
            isHighlightInCurrentPage = true;
           }
          }
        }
        this.saveNote(this.state.currentHighlight.data.comment);
      }
      break;
    }

  }
  /*
  This callback is fired on clicking ok of the modal dialog
  As of now this is used for chapter navigation in the book panel.
  */
  applyModalChanges = (data) => {
    console.log('epub applyModalChanges called', data);
    // Show loading overlay
    this.manageLoadingOverlay(true);
    var chapterToNavigate = DataFormatter.readNodeValue(data.children['jumpToChapter']);

    // Chapter modal
    if(chapterToNavigate && chapterToNavigate !== '') {
      this.setState({
        isChapterModalShown:false
      });
      ePubWrapper.displayChapter(chapterToNavigate);
      // Set the current page in local storage.
      this.setCurrentPageInStorage(chapterToNavigate);
    }
    // Notes Modal
    else {
      this.setState({
        isNotesModalVisible:false
      });
      var comment = DataFormatter.readNodeValue(data.children['currentNoteContainer'].children['currentNote']);
      this.saveNote(comment);
    }
  }


  // Scaling Transorm function.
  scaleIframe = function(scaleRatio) {
    console.log('epub scaleIframe called', scaleRatio);
    $('.bookFrame').css('-webkit-transform', 'scale(' + scaleRatio + ')');
    $('.bookFrame').css('-ms-transform', 'scale(' + scaleRatio + ')');
    $('.bookFrame').css('transform', 'scale(' + scaleRatio + ')');
  }

 // Scaling Transorm used for handling the Iframe Scaling for the Fixed Layout Books.
  fixedLayoutScaling = function() {
console.log('epub fixedLayoutScaling called');
    var bookParameters = DataFormatter.getObjectInStorage('currentBook');
    if(bookParameters.metadata.custom && bookParameters.metadata.custom.height != 0) {
      var scaleRatio;
      var bookHeight = bookParameters.metadata.custom.height;
      var bookWidth = bookParameters.metadata.custom.width;
      var windowHeight = window.innerHeight * 81 / 100;
      var windowWidth = window.innerWidth * 76 / 100;
      if(parseInt(bookHeight) >  parseInt(bookWidth) ) {
        scaleRatio = windowHeight / bookHeight;
      } else {
        scaleRatio = windowWidth / bookWidth;
      }
      this.scaleIframe(scaleRatio);
    }
  }
  /*
  This method handles cutting of the loading overlay
  when page content is loaded
  */
  updateBookPanel = () => {
console.log('epub updateBookPanel called');
  	if(window.fontSettings){
  	window.fontSettings.apply();
  }
    var bookParameters = DataFormatter.getObjectInStorage('currentBook');
    if(bookParameters.metadata.custom && bookParameters.metadata.custom.height != 0) {
      DataFormatter.setObjectInStorage('isFixedLayout', true);
      $('img').attr('draggable', false);
      var scaleRatio;
      var bookHeight = bookParameters.metadata.custom.height;
      var bookWidth = bookParameters.metadata.custom.width;
      var windowHeight = window.innerHeight * 81 / 100;
      var windowWidth = window.innerWidth * 76 / 100;
      if(parseInt(bookHeight) >  parseInt(bookWidth) ) {
        scaleRatio = windowHeight / bookHeight;
      } else {
        scaleRatio = windowWidth / bookWidth;
      }
      this.scaleIframe(scaleRatio);
      document.querySelector('.bookFrame').contentWindow.document.body.querySelector('img').style.userSelect = "none";
      document.querySelector('.bookFrame').contentWindow.document.body.querySelector('img').style.webkitUserSelect  = "none";
      document.querySelector('.bookFrame').contentWindow.document.body.querySelector('img').style.MozUserSelect  = "none";
      document.querySelector('.bookFrame').contentWindow.document.body.querySelector('img').setAttribute("unselectable", "on");
      document.querySelector('.bookFrame').contentWindow.document.body.style.overflow = 'hidden';  // firefox, chrome
      document.querySelector('.bookFrame').contentWindow.document.body.scroll = "no";
      window.addEventListener("resize", this.fixedLayoutScaling);
    }
    document.querySelector('.bookFrame').contentWindow.window.addEventListener('scroll', this.handleScroll);
    this.manageLoadingOverlay(false);
    var currentPage;
    if(DataFormatter.getObjectInStorage('curbookpageno') !== null && navigationItemClicked == false){
      currentPage = DataFormatter.getObjectInStorage('curbookpageno');
    }
    else {
      currentPage = ePubWrapper.getCurrentPage();
      // Set the current page in local storage.
      this.setCurrentPageInStorage(currentPage);
    }
    // Set the current font  in local storage.
      var currentFont;
    if(DataFormatter.getObjectInStorage('fontfamily') !== null ){
      currentFont = DataFormatter.getObjectInStorage('fontfamily');
      var body= document.querySelector(".bookFrame").contentWindow.document.getElementsByTagName("body")[0];
     body.setAttribute('style',body.getAttribute('style')+'font-family: "'+currentFont+'";');
     var elements= body.getElementsByTagName("h1");
    for (var i = elements.length - 1; i >= 0; i--) {
      elements[i].setAttribute('style',body.getAttribute('style')+'font-family: "'+currentFont+'";');
    }

    }

    // Set the current font contrast in local storage.
    var fonttheme = DataFormatter.getObjectInStorage('fonttheme');
    if(fonttheme == "Default" || !fonttheme) {
    	var body = document.querySelector(".bookFrame").contentWindow.document.getElementsByTagName("body")[0];
    	window.fontSettings.apply();
    	var defaultColor = body.style.color;
    	var defaultBackgroundColor = body.style.backgroundColor;
    	DataFormatter.setObjectInStorage("defaultColor", defaultColor);
    	DataFormatter.setObjectInStorage("defaultBackgroundColor", defaultBackgroundColor);
    }
    var totalPages = ePubWrapper.getTotalNumberOfPages();
    this.handlePageFlipperState(currentPage,totalPages);
    this.setState({
      currentPage:currentPage
    });
    //Restore highlights for that page.
    this.restoreHighlights();  
    // this.changeZoomLevel(1, true);
    // Get TOC.
    var tocContent = ePubWrapper.getTOCContent();
    this.setState({
      tocContent:tocContent.innerHTML
    });

    // Set the pages count and the slider here.
    if(!this.state.isSliderShown) {
      this.setState({
        isSliderShown:true,
        pagesCount:totalPages
      });
    }
    if(DataFormatter.getObjectInStorage('curbookpageno') !== null &&
    (ePubWrapper.getCurrentPage() != DataFormatter.getObjectInStorage('curbookpageno'))){
      ePubWrapper.displayChapter(DataFormatter.getObjectInStorage('curbookpageno'));
    }
    this.setState({
       isHighlightsMenuVisible: false,
       isTOCMenuVisible: false,
       isHighlightPopoverVisible: false,
       isBookmarkMenuVisible: false
    });

    //Restore highlights for that page.
    // this.restoreHighlights();  
    var bookDetails = DataFormatter.getObjectInStorage('productId');
    AppActions.getBookBookmarks(bookDetails);
    var tocflag = DataFormatter.getObjectInStorage('tocflag');
    if(tocflag)
    {
      setTimeout(this.tocScroll, 200);
    }
    var currentPageName = ePubWrapper.getCurrentPageName(currentPage);
    if(currentPageName.indexOf('/') > -1 ) {
      currentPageName = currentPageName.split('/')[1];
    }
    var element = document.querySelector('.toc_link[href*="'+currentPageName+'"]');
    this.restoreTOC(element);
    // setTimeout(this.gotoHighlight, 300);
    setTimeout(this.jumpInPage, 500);
  }

  manageAccessibilityMenu = () => {
console.log('epub manageAccessibilityMenu called');
    var accessibilityFlag = DataFormatter.getObjectInStorage('accessibilityClicked');
    if(accessibilityFlag) {
      if(document.querySelector('.accessibilityContainer')) {
        var visibleOrNot = document.querySelector('.accessibilityContainer').style.visibility;
            if(visibleOrNot == '' || visibleOrNot == "visible") {
              document.querySelector('.accessibilityContainer').style.visibility = "hidden";
             } else {
              document.querySelector('.accessibilityContainer').style.visibility = "visible";
       }
       DataFormatter.setObjectInStorage("accessibilityClicked", false);
    }
  }
  }
  /*
  This Method will set the flag if TOC and any links clicked
  */
  handleLinks = () => {
    console.log('epub handleLinks called');
    navigationItemClicked = true;
    this.manageLoadingOverlay(true);
  }

  /*
  This method handles cutting of the loading overlay
  when page content is loaded
  */
  handleBookError = (error) => {
console.log('epub handleBookError called');
    this.manageLoadingOverlay(false);
    console.log("Error"+error);
  }
  /*
  This method handles cutting of the loading overlay
  when page content is loaded nad jumping to a new chapter as required.
  */
  jumpToBookPosition = (newValue) => {
console.log('epub jumpToBookPosition called', newValue);
    this.setState({
       isHighlightsMenuVisible: false,
       isTOCMenuVisible: false,
       isBookmarkMenuVisible:false,
    });
    this.manageLoadingOverlay(true);
    ePubWrapper.displayChapter(newValue);
    DataFormatter.setObjectInStorage('curbookpageno',newValue);
  }

  /*
  This method takes care of disabling the previous or next page
  flippers based on the current page.
  */
  handlePageFlipperState = function(currentPage,totalPages) {
console.log('epub handlePageFlipperState called', currentPage, totalPages);
    if(currentPage === 1)
    {
      this.setState({
        prevFlipperClass: "disableClick",
        nextFlipperClass: ""
      });
    }
    else if(currentPage === totalPages) {
      this.setState({
        prevFlipperClass: "",
        nextFlipperClass: "disableClick"
      });
    }
    else {
      this.setState({
        prevFlipperClass: "",
        nextFlipperClass: ""
      });
    }
  }
  /*
  This method is used to handle the state of the highlights and TOC menus.
  */
  updateMenuState = function(menuType) {
console.log('epub updateMenuState called', menuType);
    switch(menuType) {
      case AppConstants.SlidingMenuTypes.TOC:
      this.setState({
        isTOCMenuVisible: false
      });
      break;
      case AppConstants.SlidingMenuTypes.HIGHLIGHTS:
      this.setState({
        isHighlightsMenuVisible: false
      });
      break;
      case AppConstants.SlidingMenuTypes.BOOKMARK:
      this.setState({
        isBookmarkMenuVisible: false
      });
      case AppConstants.SlidingMenuTypes.ACESSIBILITY:
      this.setState({

      });
      break;
    }
  }
  restoreTOC = function(element) {
console.log('epub restoreTOC called', element);
     //var element = document.querySelector('.toc_link[href*="'+name+'"]') // selects 1st link if href contains name
    if(element)
      {
     var allLinks = document.querySelectorAll('.toc_link');
     for (var i=0; i<allLinks.length; i++){
          allLinks[i].setAttribute("class","toc_link");
             }
          element.setAttribute("class","toc_link selected");
      }
  }

 handleScroll = function() {
console.log('epub handleScroll called');
  var bookmarksList = this.state.bookmarks;
  var currentPage = ePubWrapper.getCurrentPage();
    var currentbookmarksList = bookmarksList.filter(function(bookmark){
        return bookmark.pageIndex == currentPage;
    });
    var currentScrollY = document.querySelector('.bookFrame').contentWindow.window.scrollY || document.querySelectorAll('.bookFrame')[0].contentWindow.window.pageYOffset;
    var currentDocumentHeight = document.querySelector('.bookFrame').contentWindow.document.body ? document.querySelector('.bookFrame').contentWindow.document.body.scrollHeight : 0;
    var screenHeight = document.querySelector('.bookFrame').contentWindow.innerHeight;
    var bookmarkToCheck, found = 0;
    if(currentbookmarksList.length > 0) {
      for(var i=0; i<currentbookmarksList.length ; i++) {
        if(found == 0) {
        var bookmarkToCheckPercentage = currentbookmarksList[i].highlightHash.split('@',2)[1];
        // if(bookmarkToCheckPercentage > .05) {
        //   // bookmarkToCheckPercentage = bookmarkToCheckPercentage - .05 ;
        // }
        bookmarkToCheck = (bookmarkToCheckPercentage) * this.getDocHeight();
        if((bookmarkToCheck + 480) >= (this.getWindowYscroll() ) && (bookmarkToCheck) <= (this.getWindowYscroll() + 480)) {
        this.setState({
            currentBookmark: currentbookmarksList[i].id,
            isBookmarked: true
         });
         found = 1;
        } else {
        this.setState({
            isBookmarked: false
          });
       }
      }
     }
    } else {
        this.setState({
            isBookmarked: false
     });
    }
  }

  /*
   This method is used to refresh the bookmarks panel with the latest Content
  It is called in the following cases.
  1. First time load of the book.
  2. After any bookmarks are added/deleted.

  */

  updateBookmarksPanel() {
console.log('epub updateBookmarksPanel called');
    var bookmarksList= AppStore.bookmarkresponse;
    this.setState({
      bookmarks: bookmarksList.sortedBookmarks
     });
    var currentPage = ePubWrapper.getCurrentPage();
    var currentbookmarksList = bookmarksList.sortedBookmarks.filter(function(bookmark){
        return bookmark.pageIndex == currentPage;
    });
    if(document.querySelector('.bookFrame')) {
          var currentScrollY = document.querySelector('.bookFrame').contentWindow.window.scrollY || document.querySelectorAll('.bookFrame')[0].contentWindow.window.pageYOffset;
    var currentDocumentHeight = document.querySelector('.bookFrame').contentWindow.document.body ? document.querySelector('.bookFrame').contentWindow.document.body.scrollHeight : 0;
    var screenHeight = document.querySelector('.bookFrame').contentWindow.innerHeight;
    var bookmarkToCheck, found = 0;
    if(currentbookmarksList.length > 0) {
      for(var i=0; i<currentbookmarksList.length ; i++) {
        if(found == 0) {
        var bookmarkToCheckPercentage = currentbookmarksList[i].highlightHash.split('@',2)[1];
        // if(bookmarkToCheckPercentage > .05) {
        //   bookmarkToCheckPercentage = bookmarkToCheckPercentage - .05 ;
        // }
        bookmarkToCheck = (bookmarkToCheckPercentage) * this.getDocHeight();
        if((bookmarkToCheck + 480) >= (this.getWindowYscroll()) && (bookmarkToCheck) <= (this.getWindowYscroll() + 480)) {
        this.setState({
            currentBookmark: currentbookmarksList[i].id,
            isBookmarked: true
         });
         found = 1;
        } else {
        this.setState({
            isBookmarked: false
          });
       }
      }
     }
    } else {
        this.setState({
            isBookmarked: false
     });
    }
    }

  }

  /*
  This method is used to refresh the highlights panel with the latest Content
  It is called in the following cases.
  1. First time load of the book.
  2. After any highlights are added/modified/deleted.
  */
  updateHighlightsPanel() {
console.log('epub updateHighlightsPanel called');
    var highlightsList= AppStore.response;
    this.setState({
      highlights: highlightsList.sortedHighlights
    });
    // var bookId = DataFormatter.getKeyFromObject("currentBook","id");
    // AppActions.getBookHighlights(bookId);

    // Highlight has been deleted from the current page so reload the page to reflect state
    if(highlightsList.shouldReloadPage || isHighlightInCurrentPage) {
        var curPage = DataFormatter.getObjectInStorage('curbookpageno');
        ePubWrapper.displayChapter(curPage);
      }
      //this.restoreHighlights();
    // Cut the loading overlay only on any highlight operations not on first time loading 
    var highlightObj = this.state.currentHighlight.data;
    if(highlightObj != null && highlightObj != undefined) {
      this.manageLoadingOverlay(false);
    }
    isHighlightInCurrentPage =  false;
    var bookDetails = DataFormatter.getObjectInStorage('productId');  
    // this.restoreHighlights(); 
    AppActions.getBookBookmarks(bookDetails);
  }

  gotoBookmarkPage = function(bookmark) {
    console.log('epub gotoBookmarkPage called', bookmark);
      var curPage = DataFormatter.getObjectInStorage('curbookpageno');
      var bookmarkHash = bookmark.highlightHash.split('@', 2)[1];
      if(bookmark.pageIndex != curPage) {
          ePubWrapper.displayChapter(bookmark.pageIndex);
          this.setCurrentPageInStorage(bookmark.pageIndex);
          var jumpHash = "xx$xx$xx$xx$@" + bookmarkHash;
          DataFormatter.setObjectInStorage("targetHighlightHash", jumpHash);
          DataFormatter.setObjectInStorage("highlightFlag", true);
          DataFormatter.setObjectInStorage("bookmarkjump", true);
      } else {
        var iFrame = document.querySelectorAll('.bookFrame')[0].contentWindow;
        var totalScrollHeight = iFrame.document.body.scrollHeight;
        var scrollY = (bookmarkHash * this.getDocHeight());
        console.log(scrollY)
        iFrame.scrollTo(0, scrollY);
      }
      var userId = String(DataFormatter.getKeyFromObject("userInformation", "userId"));
        DataFormatter.createAWSSession();
        DataFormatter.sendAWSEvent("bookmark", { "action": "navigate" , "book_title" : bookTitle , "book_id" : bookId , "selected_bookmark" : bookmark.note , "user_id": userId});
      }

  /*
  This method is used to restore highlights for that page when it is loaded.
  */
  restoreHighlights = function() {
    console.log('epub restoreHighlights called');
    var currentPage = this.state.currentPage.toString();
    var currentHighlights = this.state.highlights.filter(function (highlight) {
      return highlight.pageIndex === currentPage
    });
      var highlightHashes = currentHighlights.map(function(highlight){
      if(highlight.highlightHash.split("::").length > 1)
      {
         var preHash = highlight.highlightHash.split("@")[0];
         var hash = preHash;
    } else {
      var preHash = highlight.highlightHash.split("$", 4);
      var hash = preHash.join("$") + "$";
    }
      return hash;
    });
    var highlights = highlightHashes.join('|');
    this.gotoHighlight();
    //this.gotoHighlight();
    ePubWrapper.restoreHighlights(highlights);
    //this.gotoHighlight();
  }
  /*
  This method is used to set the current page number to the local storage for
  use when the user refreshes the page in the browser
  */
  setCurrentPageInStorage = function(pageNumber) {
    console.log('epub setCurrentPageInStorage called', pageNumber);
    // let it be integer always
    let pageno = parseInt(pageNumber);
    DataFormatter.setObjectInStorage('curbookpageno',pageno);
    this.setState({
      currentPage: pageno
    });
  }

  /*
  Specifies the action to be performed when a highlight is clicked
  Used here to show the notes overlay.
  */
  handleHighlightClick =(highlightData) => {
console.log('epub handleHighlightClick called');
    var highlight = this.state.highlights.filter(function (highlight) {
       if(highlight.highlightHash.split("::").length > 1)
      {
         var preHash = highlight.highlightHash.split("@")[0];
         var hash = preHash;
      } else {
        var preHash = highlight.highlightHash.split("$", 4);
        var hash = preHash.join("$") + "$";
      }
     return hash === highlightData.highlightHash
    });
    if(highlight !== null  && highlight. length >0) {
      this.showNotesOverlay(highlight[0],false);
    }
  }

  /*
  Scroll to the particular content
  */
  handleScrollTo =(scrollhash) => {
      document.querySelector('.bookFrame').contentWindow.location.hash = "xxx";
      document.querySelector('.bookFrame').contentWindow.location.hash = scrollhash;
      DataFormatter.setObjectInStorage('tocflag', false);
      DataFormatter.setObjectInStorage('hrefLocation', false);
  }


  tocScroll = () => {
    console.log('epub tocScroll called');
    this.handleScrollTo(DataFormatter.getObjectInStorage('tocscroll'));
  }

  jumpInPage = () => {
    console.log('epub jumpInPage called');
     var jumpLocation = DataFormatter.getObjectInStorage('hrefLocation');
      if(jumpLocation){
        this.handleScrollTo(jumpLocation);
      }
  }

  /*
  This method is used to set the current page number to the local storage for
  use when the user refreshes the page in the browser
  */
  cancelUserSelection = function(pageNumber) {
console.log('epub cancelUserSelection called', pageNumber);
    this.setState({
      isHighlightPopoverVisible: false
    });
    DataFormatter.clearSelection(document.querySelector('.bookFrame').contentWindow);
  }
};
export default BookPanel;
