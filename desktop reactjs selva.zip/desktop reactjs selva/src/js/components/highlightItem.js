import React from 'react';
import DataFormatter from './utilities/dataFormatter';
import Localization from './localization';

var lang = DataFormatter.getLanguage();

class HighlightItem extends React.Component {
  constructor() {
    super();
    //Bind events for es6 syntax
    this.handleHighlightClick = this.handleHighlightClick.bind(this);
  }

  /*
  This method is used to render each highlight item.
  */
  render = function() {
    var highlight = this.props.highlight;
    var addNote;
    // render the add note button only if note is not added yet.
    if(!highlight.comment || highlight.comment.trim() === '') {
      addNote = <div className='addNote'>+ {DataFormatter.getObjectText(Localization, (lang + ".PageText.AddNote"))}</div>
    }
    var highlightStyle = {
      color: 'black',
      backgroundColor: highlight.colour && highlight.colour !== ''? highlight.colour:'yellow'
    };
    return (
      <li onClick = {this.handleHighlightClick.bind(this,highlight)} className='highlightContainer'>
      <a data-highlighthash={highlight.highlightHash} data-pageindex ={highlight.pageIndex} className = 'pageIndex' href="#">Page {highlight.pageIndex}</a>
      <div className ='highlightsLabelContainer'>
      <label style ={highlightStyle} className = 'highlightedText'>{highlight.note}</label>
      </div>
      <div className = 'notesContainer' >
      <pre className = 'userNote'>
      {highlight.comment}
      </pre>
      </div>
      {addNote}
      </li>
    );
  }
  /*
  This method is triggered when a highlight is clicked. Will trigger a callback.
  */
  handleHighlightClick = function(highlight,event) {
    // Stop the propogation of the link is clicked to prevent bubbling
    if(DataFormatter.isFunction(this.props.highlightClickedCallback) &&
    (!(event.target.classList.contains('pageIndex')) &&
    !(event.target.nodeName.toLowerCase() === 'span' && (event.target.innerText !== 'Add Note' && event.target.innerText !== '+ ')))) {
      this.props.highlightClickedCallback(highlight);
    }
  }
};
export default HighlightItem;
