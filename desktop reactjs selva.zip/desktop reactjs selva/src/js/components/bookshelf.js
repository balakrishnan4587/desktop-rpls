import React from 'react';
import AppActions from '../actions/app.actions';
import AppStore from '../stores/app.store';
import AppConstants from '../constants/app.constants';
import Book from './bookshelfItem';
import DataFormatter from './utilities/dataFormatter'

class Bookshelf extends React.Component {

  constructor() {
    super();
    //Bind events for es6 syntax
    this.bookshelfDataFetched = this.bookshelfDataFetched.bind(this);
  }
  state = {
    books:[]
  };
  /*
  This method hides or shows the body scroll bar based
  on a condition.
  */
  manageBodyScroll = function(hideScroll)
  {
    if(hideScroll) {
      // Hide the body scroll and set the window scroll to the top.
      document.body.style.overflow = 'hidden';
      window.scrollTo(0,0);
    }
    else {
      document.body.style.overflow = 'visible';
    }
  }
  componentDidMount = function() {
    var userId = String(DataFormatter.getKeyFromObject("userInformation", "id"));
    DataFormatter.createAWSSession();
    DataFormatter.sendAWSEvent("screen", { "action": "open" , "name" : "bookshelf" , "user_id": userId});
    this.manageBodyScroll(false);
    AppStore.on(AppConstants.EventTypes.BOOKSHELF_LOAD_COMPLETE, this.bookshelfDataFetched);
    this.resize();
    window.onresize = this.resize;
    AppActions.loadBookshelf();
  }
  componentWillMount = function() {
    if(DataFormatter.getObjectInStorage('currentBook') == null && DataFormatter.getObjectInStorage('curbookpageno') !== null){
      localStorage.removeItem('curbookpageno');
    }
  }
  renderItems = function()
  {
    return this.state.books.map(function(book,index)
    {
      //This should be removed once page implementation is done on the api side.
      //var uniqueID = Math.random().toString(36).substring(7);
      return <Book key ={book.id} book={book} />;
    });
  }
  render = function() {
        console.log('BookShelf render called');
    return (
      <div className ='bookshelfMasterContainer'>
      <div  className ='bookshelfContent'>
        {this.renderItems()}
      </div>
      </div>
    );
  }
  bookshelfDataFetched = (data) => {
    var sortedBooks = DataFormatter.sortList(this.state.books.concat(AppStore.response),AppConstants.SortType.ASC,"title")
    console.log('bookshelf got --> ', AppStore.response);
    console.log('bookshelf sortedBooks --> ', sortedBooks);
    this.setState({books:sortedBooks});
    DataFormatter.setObjectInStorage('products', AppStore.response);
    DataFormatter.wrapMultipleLines('bookName');
  }
  resize = function() {
     var containerHeight = document.querySelector('.container').clientHeight;
     var windowHeight = window.innerHeight;
     if(document.querySelector('.bookshelfMasterContainer')) {
     document.querySelector('.bookshelfMasterContainer').style.height = windowHeight - containerHeight + "px";
   }
  }

componentWillUnmount() {
	AppStore.removeListener(AppConstants.EventTypes.BOOKSHELF_LOAD_COMPLETE, this.bookshelfDataFetched);  
}
};
export default Bookshelf;
