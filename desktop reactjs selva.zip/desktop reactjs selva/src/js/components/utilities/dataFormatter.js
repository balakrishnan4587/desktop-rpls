import AppConstants from '../../constants/app.constants';
import MultiLineEllipsis from './multiLineEllipsis';
import Localization from '../localization';

class DataFormatter
{
static setAWSConfig = function(region, cognitoID) {
  AWS.config.region = region;
  AWS.config.credentials = new AWS.CognitoIdentityCredentials({
        IdentityPoolId: cognitoID   //Required e.g. 'us-east-1:12345678-c1ab-4122-913b-22d16971337b'
    });
}

static getAWSSession = function(AppId) {
  if(navigator.onLine) {
    var options = {
          appId : AppId,    //Required e.g. 'c5d69c75a92646b8953126437d92c007'
          appVersionName: "WebReader 7"
      };
    window.mobileAnalyticsClient = new AMA.Manager(options);
  }
}

static createAWSSession = function() {
  if(navigator.onLine) {
    try{
      DataFormatter.setAWSConfig(AppConstants.AWS_Region, AppConstants.AWS_COGNITO_IDENTITY_POOL_ID);
      if(window.mobileAnalyticsClient) {
       window.mobileAnalyticsClient.stopSession();
       DataFormatter.getAWSSession(AppConstants.AWS_APP_ID);
      } else {
        DataFormatter.getAWSSession(AppConstants.AWS_APP_ID);
      }

      }catch(e){
        return false;
      }
  }

}

static sendAWSEvent = function(eventName, attributeObject) {

  if(navigator.online) {
    window.mobileAnalyticsClient.recordEvent(eventName , attributeObject);
    window.mobileAnalyticsClient.submitEvents();
  }

}

static applyStyleOfParent = function(parent, child) {
  var elements= parent.getElementsByTagName(child);
    for (var i = elements.length - 1; i >= 0; i--) {
      elements[i].style.backgroundColor = parent.style.backgroundColor;
      elements[i].style.color = parent.style.color;
      }
}
static applyStyleOfParentClass = function(selector, color, backgroundColor) {
  $(selector).css('background-color', backgroundColor);
  $(selector).css('color',color);
}

 static changeContrast = function(element ,color, backgroundColor) {
  element.setAttribute("style", "color:" + color + "!important;background-color: " + backgroundColor + " !important");
  backgroundColor = backgroundColor;
  window.fontSettings.apply();
  DataFormatter.applyStyleOfParent(element, "h1");
  window.fontSettings.apply();
}

  static setObjectInStorage = function(key, value) {
    if(window.localStorage) {
      localStorage.setItem(key, JSON.stringify(value));
    }
  }

  static getObjectText = function(obj, str) {
    var stringPart = str.split(".");
    if(stringPart[0] == "") {
      stringPart[0] = stringPart[1];
      stringPart.splice(1,1);
    }
    for(var i=0; i<stringPart.length; i++) {
      obj = obj[stringPart[i]];
    }
    if(obj){
            return obj;
    }  else {
          return false;
    }

  }
  static getLanguage = function() {
    var obj = navigator.language || navigator.userLanguage;
    obj = obj.replace(/[^a-zA-Z0-9]/g, '').toLowerCase()
    var LangAvailable = DataFormatter.getObjectText(Localization, "." + obj);
     if(LangAvailable) {
      return obj;
     } else {
      return 'enus';
    }
  }

  static getObjectInStorage = function(key) {
    if(window.localStorage) {
      var localStorageItem = localStorage.getItem(key);
      if(localStorageItem!==null) {
        return JSON.parse(localStorageItem);
      }
    }
    return null;
  }
  static getKeyFromObject = function(objectKey,propKey) {
    var object = this.getObjectInStorage(objectKey);
    var value=null;
    if(object !== null && object !== undefined) {
      value = object[propKey];
    }
    return value;
  }

  static getCookie = function(cname) {
      var name = cname + "=";
      var ca = document.cookie.split(';');
      for(var i=0; i<ca.length; i++) {
          var c = ca[i];
          while (c.charAt(0)==' ') c = c.substring(1);
          if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
      }
      return null;
  }

  static sortNumbers = function (list,sortOrder,sortKey) {
    list.sort(function(a,b){
      var num1=parseInt(a[sortKey]), num2=parseInt(b[sortKey])
      return num1-num2;
    })
    return list;
  }
  static sortList = function(list,sortOrder,sortKey) {
    // first sort without unicode
    list.sort(function(a,b){
      var firstItem=a[sortKey].replace(/[\u200B-\u200D\uFEFF]/g, '').toLowerCase(), secondItem=b[sortKey].replace(/[\u200B-\u200D\uFEFF]/g, '').toLowerCase();
      if (firstItem < secondItem) //sort string ascending
      return -1;
      if (firstItem > secondItem)
      return 1;
      return 0; //default return value (no sorting)
    })
    // Account for unicode characters next
    list.sort(function(a,b){
      return a[sortKey].replace(/[\u200B-\u200D\uFEFF]/g, '').toLowerCase().localeCompare(b[sortKey].replace(/[\u200B-\u200D\uFEFF]/g, '').toLowerCase());
    })
    //Reverse the list for descending
    if(sortOrder === AppConstants.SortType.DESC) {
      list = list.reverse();
    }
    return list;
  }
  static wrapMultipleLines(elementClass)
  {
    var elements = document.getElementsByClassName(elementClass);
    MultiLineEllipsis.ellipsis(elements);
  }
  static isFunction(func)
  {
    if (typeof func === "function") {
      return true;
    }
    return false;
  }
  static readNodeValue(element)
  {
    if(element)
    {
      var nodeName = element.nodeName.toLowerCase().trim();
      if(nodeName === 'input' || nodeName ==='textarea')
      {
        return element.value;
      }
      else if(nodeName === 'select')
      {
        return element.options[element.selectedIndex].value;
      }
      else if(nodeName === 'label') {
        return element.textContent;
      }
      return '';
    }
  }

  static navigateToElement(elementIdentifier,win, isFrame,identifierType) {
    var doc;
    if(isFrame) {
      doc = win.document;
    }
    else {
      doc = document;
    }

    var element;
    if(identifierType === 'class') {
      element = doc.getElementsByClassName(elementIdentifier)[0];
    }
    else {
      element = doc.getElementById(elementIdentifier);
    }
    element.scrollIntoView();
    window.scrollTo(0,0);
  }

  static clearSelection(win,doc) {
    if (win && win.getSelection) {
        win.getSelection().removeAllRanges();
    } else if (doc && doc.selection) {
        document.selection.empty();
    }
  }
};
export default DataFormatter;
