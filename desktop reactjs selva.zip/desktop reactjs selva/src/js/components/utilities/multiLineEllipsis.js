/*
This component is used to truncate text with ellipses when
the text overflows the container. This utility component is
present because of the inconsistent support for multiline
ellipses across browsers. Requires the following

1. The element on which the ellipsis needs to be set should
have fixed height and width
2. overflow: hidden must be set
3. The element should have the text directly within without any children.
*/
class MultiLineWrapper
{
  currentElement = null;
  clonedElement = null;

  static ellipsis = function(elements)
  {
    var overflowHeight =  function () {
      return clonedElement.offsetHeight > currentElement.offsetHeight;
    };
    var overflowWidth =  function () {
      return clonedElement.offsetWidth > currentElement.offsetWidth;
    };

    for (var i = 0; i < elements.length; i++) {
      var currentElement = elements[i];
      var elementStyles = window.getComputedStyle(currentElement);
      if(elementStyles['overflow'] == "hidden")
      {
        var text = currentElement.innerHTML;
        var multiline = currentElement.classList.contains('multiline');
        var clonedElement = currentElement.cloneNode(true);
        clonedElement.style.visibility = 'hidden';
        clonedElement.style.position = 'absolute';
        clonedElement.style.overflow = 'visible';
        clonedElement.style.width = multiline ? currentElement.offsetWidth +'px' : 'auto';
        clonedElement.style.height = multiline ? 'auto': currentElement.offsetHeight + 'px';
        document.body.appendChild(clonedElement);

        var overflowFunc = multiline ? overflowHeight : overflowWidth;

        // Trim text till the width of the container is reached
        while (text.length > 0 && overflowFunc())
        {
          text = text.substr(0, text.length - 1);
          clonedElement.innerHTML = text + "...";
        }
        currentElement.innerHTML = clonedElement.innerHTML;
        document.body.removeChild(clonedElement);
      }
    }
  }
};
export default MultiLineWrapper;
