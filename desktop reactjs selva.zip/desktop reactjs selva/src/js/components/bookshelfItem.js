import React from 'react';
import AppActions from '../actions/app.actions';
import AppStore from '../stores/app.store';
import AppConstants from '../constants/app.constants';
import DataFormatter from './utilities/dataFormatter';

var bookId = "" , bookTitle = "";
class Book extends React.Component {
  state = {
    book: {},
    bookId: "",
    coverImageURL: "",
    title:""
  };

  componentWillMount = function() {
    var userRole = DataFormatter.getKeyFromObject("userInformation","role");
      var bookArray = this.props.book.books;
    console.log('Book --> ', bookArray.length, bookArray);
      try {
      if(bookArray.length == 1) {

        console.log('image--> ',  bookArray[0].metadata.host + bookArray[0].metadata.coverImage);
        this.setState({
          bookId: bookArray[0].id,
          coverImageURL: bookArray[0].metadata.host + bookArray[0].metadata.coverImage,
          title : bookArray[0].metadata.title
        });
        //this.state.bookId;
        //AppActions.bookClicked(bookArray[0].id);
      } else {
        if(bookArray.length > 1) {
        var book1Metadata = bookArray[0].metadata || "";
        var book2Metadata = bookArray[1].metadata || "";
        if(book1Metadata != "") {
          var book1Role = book1Metadata.role || "";
        } else {
          var book1Role = "";
        }
        if(book2Metadata != "") {
          var book2Role = book2Metadata.role || "";
        } else {
          var book2Role = "";
        }
       if(String(book1Role) === String(userRole)) {
        this.setState({
          bookId: bookArray[0].id,
          coverImageURL: book1Metadata.host + book1Metadata.coverImage,
          title : book1Metadata.title
        });
        } else {
         if(String(book2Role) === String(userRole)) {
           console.log('image -->', book2Metadata.host + book2Metadata.coverImage)
           this.setState({
          bookId: bookArray[1].id,
          coverImageURL: book2Metadata.host + book2Metadata.coverImage,
          title : book2Metadata.title
        });
         } else {
           console.log('image -->', book1Metadata.host + book1Metadata.coverImage)
           this.setState({
          bookId: bookArray[0].id,
          coverImageURL: book1Metadata.host + book1Metadata.coverImage,
          title : book1Metadata.title
        });
         }
        }
        }
       }
      } catch(e){
        console.log('book error->', e);
      }

  }
	bookdownloaded=false;
  openBook = (bookDetails,event) => {
			this.bookdownloaded=true;
      var userRole = DataFormatter.getKeyFromObject("userInformation","role");
      var userId = String(DataFormatter.getKeyFromObject("userInformation", "id"));
      DataFormatter.createAWSSession();
      var bookArray = bookDetails.props.book.books;
      try{
            if(bookArray.length == 1) {
        bookId = bookArray[0].id,
        bookTitle = bookArray[0].metadata ? bookArray[0].metadata.title : "" ;
        AppActions.bookClicked(bookArray[0].id);
      } else {
        if(bookArray.length > 1) {
        var book1Metadata = bookArray[0].metadata || "";
        var book2Metadata = bookArray[1].metadata || "";
        if(book1Metadata != "") {
          var book1Role = book1Metadata.role || "";
        } else {
          var book1Role = "";
        }
        if(book2Metadata != "") {
          var book2Role = book2Metadata.role || "";
        } else {
          var book2Role = "";
        }
       if(String(book1Role) === String(userRole)) {
        bookId = bookArray[0].id,
        bookTitle = bookArray[0].metadata ? bookArray[0].metadata.title : "" ;
        AppActions.bookClicked(bookArray[0].id);
        } else {
         if(String(book2Role) === String(userRole)) {
          bookId = bookArray[1].id,
          bookTitle = bookArray[1].metadata ? bookArray[1].metadata.title : "" ;
          AppActions.bookClicked(bookArray[1].id);
         } else {
          bookId = bookArray[0].id,
          bookTitle = bookArray[0].metadata ? bookArray[0].metadata.title : "" ;
          AppActions.bookClicked(bookArray[0].id);
         }
        }
       }
      }
    } catch(e){}

      if(!bookTitle) {
        bookTitle = bookDetails.props.book.title || "";
      }
      DataFormatter.setObjectInStorage('bookId', bookId);
      DataFormatter.setObjectInStorage('bookTitle', bookTitle);
      DataFormatter.sendAWSEvent("bookshelf", { "action": "download" , "book_id" : bookId , "book_title" : bookTitle , "user_id": userId});
      DataFormatter.sendAWSEvent("reader", { "action": "open" , "screen_orientation" : "not_available" , "reading_mode" : "not_available" , "book_title" : bookTitle , "book_id" : bookId , "entry_page_index" : "0" , "user_id": userId});
 }
  render()
  {
    console.log('BookShelfItem render called');
    var downloadBook;
    if(this.props.book.downloadBook)
    {
      downloadBook=  <div className= 'bookDownloadOverlay'><img src='assets/images/cloud.png'/></div>;
    }
    if(this.props.book.coverImageURL) {
    return (
      <div onClick={this.openBook.bind(this.props.book,this)} className='bookshelfItem'>
      {downloadBook}
      <div className='bookThumbnail' style={ this.props.book.downloadBook ? {opacity:0.5} : null }>
      <img id={this.state.bookId} src={this.state.coverImageURL} />
      </div>
      <div className='bookName ellipsis multiline' title = {this.props.book.title}>{this.props.book.title}</div>
      </div>
     );
   } else {return (
     <div></div>
    );
    }
  }
};
export default Book;
