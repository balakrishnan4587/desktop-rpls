import React from 'react';
import Navbar from './navbar';
import Error from './error';

class Header extends React.Component {
  render() {
    return (
		<div>
			<Navbar/>
			<Error fontstyleDD={this.props.fontstyle} contentDD={this.props.content}/>
		</div>		
    );
  }
};
export default Header;