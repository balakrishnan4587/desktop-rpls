let CustomMixins = {
	mixin : function(target, source) {
		target = target.prototype; source = source;
		Object.getOwnPropertyNames(source).forEach(function (name) {
			console.log('function -->', target, name);
			if (name !== "constructor") Object.defineProperty(target, name,
				Object.getOwnPropertyDescriptor(source, name));
		});
	}
}
export default CustomMixins;
