/**
* Rangy, a cross-browser JavaScript range and selection library
* http://code.google.com/p/rangy/
*
* Copyright %%build:year%%, Tim Down
* Licensed under the MIT license.
* Version: %%build:version%%
* Build date: %%build:date%%
*/
function isDocument(e){return e&&e.nodeType===DOCUMENT_NODE}function getDocument(e){return isDocument(e)?e:isDocument(e.ownerDocument)?e.ownerDocument:isDocument(e.document)?e.document:e.parentNode?getDocument(e.parentNode):e.commonAncestorContainer?getDocument(e.commonAncestorContainer):e.startContainer?getDocument(e.startContainer):e.anchorNode?getDocument(e.anchorNode):void 0}function indexOf(e,t,n){n=n||0;var o=-1;if(null==e)return o;var r=e.length,i=0>n?r+n:n;if(i>=e.length)return-1;for(;r>i;){if(e[i]===t)return i;i++}return-1}function parents(e,t){var n=[];t=t||noop;do n.push(e),e=e.parentNode;while(e&&e.tagName&&t(e));return n.slice(1)}function noop(e){return!0}function seek(e,t){if(e.whatToShow!==SHOW_TEXT)throw new Error(E_SHOW);var n=0,o=e.referenceNode,r=null;if(isNumber(t))r={forward:function(){},backward:function(){}};else{if(!isText(t))throw new Error(E_WHERE);var i=before(o,t)?!1:function(){return o!==t},a=function(){return o!=t}||!e.pointerBeforeReferenceNode;r={forward:i,backward:a}}for(;r.forward()&&null!==(o=e.nextNode());)n+=o.nodeValue.length;for(;r.backward()&&null!==(o=e.previousNode());)n-=o.nodeValue.length;return n}function isNumber(e){return!isNaN(parseInt(e))&&isFinite(e)}function isText(e){return e.nodeType===TEXT_NODE}function before(e,t){if(e===t)return!1;for(var n=null,o=[e].concat(ancestors(e)).reverse(),r=[t].concat(ancestors(t)).reverse();o[0]===r[0];)n=o.shift(),r.shift();o=o[0],r=r[0];var i=indexOf(n.childNodes,o),a=indexOf(n.childNodes,r);return i>a}function fromNode(e,t){t=t||document;for(var n="/";e!==t;){if(!e){var o="The supplied node is not contained by the root node.",r="InvalidNodeTypeError";throw new DOMException(o,r)}var r=nodeName(e),i=nodePosition(e);n="/"+r+"["+i+"]"+n,e=e.parentNode}return n.replace(/\/$/,"")}function toNode(e,t,n){if(t=t||document,n=n||null,"function"==typeof t&&(n=t,t=document),t!==document&&(e=e.replace(/^\//,"./")),null===n&&document.lookupNamespaceURI){var o=getDocument(t).documentElement,r=o.lookupNamespaceURI(null)||HTML_NAMESPACE;n=function(e){var t={_default_:r};return t[e]||o.lookupNamespaceURI(e)}}return resolve(e,t,n)}function nodeName(e){switch(e.nodeName){case"#text":return"text()";case"#comment":return"comment()";case"#cdata-section":return"cdata-section()";default:return e.nodeName.toLowerCase()}}function nodePosition(e){for(var t=e.nodeName,n=1;e=e.previousSibling;)e.nodeName===t&&(n+=1);return n}function resolve(e,t,n){try{var o=e.replace(/\/(?!\.)([^\/:\(]+)(?=\/|$)/g,"/_default_:$1");return platformResolve(o,t,n)}catch(r){return fallbackResolve(e,t)}}function fallbackResolve(e,t){for(var n=e.split("/"),o=t;o;){var r=n.shift();if(void 0===r)break;if("."!==r){var i=r.split(/[\[\]]/),a=i[0].replace("_default_:",""),s=i[1]?parseInt(i[1]):1;o=findChild(o,a,s)}}return o}function platformResolve(e,t,n){var o=document.evaluate(e,t,n,FIRST_ORDERED_NODE_TYPE,null);return o.singleNodeValue}function findChild(e,t,n){for(e=e.firstChild;e;e=e.nextSibling)if(nodeName(e)===t&&0===--n)return e;return null}function fromRange(e,t){var n=e.startContainer,o=e.startOffset,r=e.endContainer,i=e.endOffset,a=fromNode(n,t),s=fromNode(r,t);return{start:a,end:s,startOffset:o,endOffset:i}}function toRange(e,t,n,o,r){function i(e){console.log("notFound: Node"+e+" not found ")}function a(e){console.log("indexSize: Node"+e+" There is no text at the requested offset ")}var s=getDocument(r),c=toNode(e,r);if(null===c)return i("start"),null;var l=s.createNodeIterator(c,SHOW_TEXT,null,!1),d=t-seek(l,t);if(c=l.referenceNode?l.referenceNode:l.root,!l.pointerBeforeReferenceNode&&void 0!=l.pointerBeforeReferenceNode){if(d>0)return a("start"),null;d+=c.length}var u=toNode(n,r);if(null===u)return i("end"),null;var f=s.createNodeIterator(u,SHOW_TEXT,null,!1),h=o-seek(f,o);if(u=f.referenceNode?f.referenceNode:f.root,!f.pointerBeforeReferenceNode&&void 0!=f.pointerBeforeReferenceNode){if(h>0)return a("end"),null;h+=u.length}var g=s.createRange();return g.setStart(c,d),g.setEnd(u,h),g}function initRangy(){rangy.init();var e=document.getElementsByClassName("monelem_component")[0];if(e||(e=document.getElementsByClassName("bookFrame")[0]),e){console.log("Got Iframe ");var t=e.contentDocument.createElement("style");t.innerHTML=".highlight {background-color: yellow;}",e.contentDocument.body.appendChild(t),highlighter=rangy.createHighlighter(e.contentWindow.document)}else{console.log("No Iframe ");var t=document.createElement("style");t.innerHTML=".highlight {background-color: yellow;}",document.body.appendChild(t),highlighter=rangy.createHighlighter()}highlighter.addClassApplier(rangy.createCssClassApplier("highlight",{ignoreWhiteSpace:!0,elementProperties:{href:"#"},tagNames:["span","a"]}))}function highlightSelectedText(){var e,t,n={},o=document.getElementsByClassName("bookFrame")[0];if(o){var r=o.contentWindow.window;e=rangy.getSelection(r),t=o.contentWindow.document.body}else e=rangy.getSelection(),t=document.body;var i,a=e.getAllRanges();a.forEach(function(e){console.log("Range"+e.startContainer),i=fromRange(e,t)}),console.log("selected --- "+e.toString());var s=highlighter.highlightSelection("highlight",e),c=s[0];return c.xpathRange=getSerializedXpathRange(i),console.log("highlight --- "+c),n.selection=e.toString(),console.log("---getting serialized highlights --"),n.serializedHighlight=c.xpathRange,console.log("---got serialized highlights --"+n),n}function getSerializedHash(e){console.log("---getSerializedHash --");var t=e.characterRange,n=[t.start,t.end,e.id,e.classApplier.cssClass,e.containerElementId],o=n.join("$");return console.log("---getSerializedHash completed --"),o}function getSerializedXpathRange(e){var t=[e.start,e.startOffset,e.end,e.endOffset],n=t.join("::");return console.log("---getSerializedXpathRange completed --"+n),n}function loadHighlights(e){var t,n=e.split("|"),o="type:textContent",r=document.getElementsByClassName("monelem_component")[0];t=r?r.contentWindow.document.body:document.getElementsByClassName("bookFrame")[0].contentWindow.document;for(var i=new Array,a=!1,s=0;s<n.length;s++)n[s].length<1||(n[s].indexOf("$")>-1?(o=o+"|"+n[s],a=!0):i.push(n[s]));a&&highlighter.deserialize(o),i.forEach(function(e){var n=e.split("::"),o=toRange(n[0],n[1],n[2],n[3],t.body);if(null!=o){var r=rangy.createRange(t);r.setStartAndEnd(o.startContainer,o.startOffset,o.endContainer,o.endOffset);var i=rangy.getSelection(document.getElementsByClassName("bookFrame")[0].contentWindow.window);i.addRange(r);var a=highlighter.highlightSelection("highlight",i),s=a[0];s.xpathRange=e,clearSelection()}})}function clearHighlights(){console.log("---clearHighlights --"),highlighter.removeAllHighlights(),console.log("---clearHighlights completed --")}function clearSelection(){console.log("---Clear Selection --");var e=document.getElementsByClassName("monelem_component")[0];e||(e=document.getElementsByClassName("bookFrame")[0]);if(e){var t=e.contentWindow.window;t.getSelection&&t.getSelection().empty&&(console.log("---calling window selection empty --"),t.getSelection().empty(),console.log("---called window selection empty --"))}else t.getSelection&&t.getSelection().empty&&(console.log("---calling window selection empty --"),t.getSelection().empty(),console.log("---called window selection empty --"));console.log("---Clear Selection completed --")}var log4javascript_stub=function(){function e(){return function(){}}function t(e,t){for(var n in t)e[n]=t[n]}function n(){}function o(){}function r(){}var i,a=e(),s=e();t(s.prototype,{addChild:a,getEffectiveAppenders:a,invalidateAppenderCache:a,getAdditivity:a,setAdditivity:a,addAppender:a,removeAppender:a,removeAllAppenders:a,log:a,setLevel:a,getLevel:a,getEffectiveLevel:a,trace:a,debug:a,info:a,warn:a,error:a,fatal:a,isEnabledFor:a,isTraceEnabled:a,isDebugEnabled:a,isInfoEnabled:a,isWarnEnabled:a,isErrorEnabled:a,isFatalEnabled:a,callAppenders:a,group:a,groupEnd:a,time:a,timeEnd:a,assert:a,parent:new s});var c=function(){return new s};t(n.prototype,{setEventTypes:a,addEventListener:a,removeEventListener:a,dispatchEvent:a,eventTypes:[],eventListeners:{}}),o.prototype=new n,i=new o,i={isStub:!0,version:"1.4",edition:"log4javascript",setEventTypes:a,addEventListener:a,removeEventListener:a,dispatchEvent:a,eventTypes:[],eventListeners:{},logLog:{setQuietMode:a,setAlertAllErrors:a,debug:a,displayDebug:a,warn:a,error:a},handleError:a,setEnabled:a,isEnabled:a,setTimeStampsInMilliseconds:a,isTimeStampsInMilliseconds:a,evalInScope:a,setShowStackTraces:a,getLogger:c,getDefaultLogger:c,getNullLogger:c,getRootLogger:c,resetConfiguration:a,Level:e(),LoggingEvent:e(),Layout:e(),Appender:e()},i.LoggingEvent.prototype={getThrowableStrRep:a,getCombinedMessages:a},i.Level.prototype={toString:a,equals:a,isGreaterOrEqual:a};var l=new i.Level;return t(i.Level,{ALL:l,TRACE:l,DEBUG:l,INFO:l,WARN:l,ERROR:l,FATAL:l,OFF:l}),i.Layout.prototype={defaults:{},format:a,ignoresThrowable:a,getContentType:a,allowBatching:a,getDataValues:a,setKeys:a,setCustomField:a,hasCustomFields:a,setTimeStampsInMilliseconds:a,isTimeStampsInMilliseconds:a,getTimeStampValue:a,toString:a},i.SimpleDateFormat=e(),i.SimpleDateFormat.prototype={setMinimalDaysInFirstWeek:a,getMinimalDaysInFirstWeek:a,format:a},i.PatternLayout=e(),i.PatternLayout.prototype=new i.Layout,i.Appender=e(),i.Appender.prototype=new n,t(i.Appender.prototype,{layout:new i.PatternLayout,threshold:i.Level.ALL,loggers:[],doAppend:a,append:a,setLayout:a,getLayout:a,setThreshold:a,getThreshold:a,setAddedToLogger:a,setRemovedFromLogger:a,group:a,groupEnd:a,toString:a}),i.SimpleLayout=e(),i.SimpleLayout.prototype=new i.Layout,i.NullLayout=e(),i.NullLayout.prototype=new i.Layout,i.XmlLayout=e(),i.XmlLayout.prototype=new i.Layout,t(i.XmlLayout.prototype,{escapeCdata:a,isCombinedMessages:a}),i.JsonLayout=e(),i.JsonLayout.prototype=new i.Layout,t(i.JsonLayout.prototype,{isReadable:a,isCombinedMessages:a}),i.HttpPostDataLayout=e(),i.HttpPostDataLayout.prototype=new i.Layout,i.PatternLayout=e(),i.PatternLayout.prototype=new i.Layout,i.AlertAppender=e(),i.AlertAppender.prototype=new i.Appender,i.BrowserConsoleAppender=e(),i.BrowserConsoleAppender.prototype=new i.Appender,i.AjaxAppender=e(),i.AjaxAppender.prototype=new i.Appender,t(i.AjaxAppender.prototype,{getSessionId:a,setSessionId:a,isTimed:a,setTimed:a,getTimerInterval:a,setTimerInterval:a,isWaitForResponse:a,setWaitForResponse:a,getBatchSize:a,setBatchSize:a,isSendAllOnUnload:a,setSendAllOnUnload:a,setRequestSuccessCallback:a,setFailCallback:a,getPostVarName:a,setPostVarName:a,sendAll:a,defaults:{requestSuccessCallback:null,failCallback:null}}),r.prototype=new i.Appender,t(r.prototype,{create:a,isNewestMessageAtTop:a,setNewestMessageAtTop:a,isScrollToLatestMessage:a,setScrollToLatestMessage:a,getWidth:a,setWidth:a,getHeight:a,setHeight:a,getMaxMessages:a,setMaxMessages:a,isShowCommandLine:a,setShowCommandLine:a,isShowHideButton:a,setShowHideButton:a,isShowCloseButton:a,setShowCloseButton:a,getCommandLineObjectExpansionDepth:a,setCommandLineObjectExpansionDepth:a,isInitiallyMinimized:a,setInitiallyMinimized:a,isUseDocumentWrite:a,setUseDocumentWrite:a,group:a,groupEnd:a,clear:a,focus:a,focusCommandLine:a,focusSearch:a,getCommandWindow:a,setCommandWindow:a,executeLastCommand:a,getCommandLayout:a,setCommandLayout:a,evalCommandAndAppend:a,addCommandLineFunction:a,storeCommandHistory:a,unload:a}),r.addGlobalCommandLineFunction=a,i.InPageAppender=e(),i.InPageAppender.prototype=new r,t(i.InPageAppender.prototype,{addCssProperty:a,hide:a,show:a,isVisible:a,close:a,defaults:{layout:new i.PatternLayout,maxMessages:null}}),i.InlineAppender=i.InPageAppender,i.PopUpAppender=e(),i.PopUpAppender.prototype=new r,t(i.PopUpAppender.prototype,{isUseOldPopUp:a,setUseOldPopUp:a,isComplainAboutPopUpBlocking:a,setComplainAboutPopUpBlocking:a,isFocusPopUp:a,setFocusPopUp:a,isReopenWhenClosed:a,setReopenWhenClosed:a,close:a,hide:a,show:a,defaults:{layout:new i.PatternLayout,maxMessages:null}}),i}();if("undefined"==typeof window.log4javascript)var log4javascript=log4javascript_stub;var DOCUMENT_NODE=9;const E_SHOW="Argument 1 of seek must use filter NodeFilter.SHOW_TEXT.",E_WHERE="Argument 2 of seek must be a number or a Text Node.",SHOW_TEXT=4,TEXT_NODE=3,FIRST_ORDERED_NODE_TYPE=9,HTML_NAMESPACE="http://www.w3.org/1999/xhtml";!function(e){function t(e,t){var n=typeof e[t];return n==y||!(n!=C||!e[t])||"unknown"==n}function n(e,t){return!(typeof e[t]!=C||!e[t])}function o(e,t){return typeof e[t]!=E}function r(e){return function(t,n){for(var o=n.length;o--;)if(!e(t,n[o]))return!1;return!0}}function i(e){return e&&O(e,A)&&x(e,T)}function a(e){return n(e,"body")?e.body:e.getElementsByTagName("body")[0]}function s(e){n(window,"console")&&t(window.console,"log")&&window.console.log(e)}function c(e,t){t?window.alert(e):s(e)}function l(e){D.initialized=!0,D.supported=!1,c("Rangy is not supported on this page in your browser. Reason: "+e,D.config.alertOnFail)}function d(e){c("Rangy warning: "+e,D.config.alertOnWarn)}function u(e){return e.message||e.description||String(e)}function f(){if(!D.initialized){var e,n=!1,o=!1;t(document,"createRange")&&(e=document.createRange(),O(e,w)&&x(e,S)&&(n=!0));var r=a(document);if(!r||"body"!=r.nodeName.toLowerCase())return void l("No body element found");if(r&&t(r,"createTextRange")&&(e=r.createTextRange(),i(e)&&(o=!0)),!n&&!o)return void l("Neither Range nor TextRange are available");D.initialized=!0,D.features={implementsDomRange:n,implementsTextRange:o};var c,d;for(var f in _)(c=_[f])instanceof g&&c.init(c,D);for(var h=0,p=I.length;p>h;++h)try{I[h](D)}catch(m){d="Rangy init listener threw an exception. Continuing. Detail: "+u(m),R.error(d,m),s(d)}}}function h(e){e=e||window,f();for(var t=0,n=L.length;n>t;++t)L[t](e)}function g(e,t,n){this.name=e,this.dependencies=t,this.initialized=!1,this.supported=!1,this.initializer=n}function p(e,t,n,o){var r=new g(t,n,function(e){if(!e.initialized){e.initialized=!0;try{o(D,e),e.supported=!0}catch(n){var r="Module '"+t+"' failed to load: "+u(n);R.error(r,n),s(r)}}});_[t]=r}function m(){}function v(){}e||(e=window);var R=log4javascript.getLogger("rangy.core"),N="function"==typeof e.define&&e.define.amd,C="object",y="function",E="undefined",S=["startContainer","startOffset","endContainer","endOffset","collapsed","commonAncestorContainer"],w=["setStart","setStartBefore","setStartAfter","setEnd","setEndBefore","setEndAfter","collapse","selectNode","selectNodeContents","compareBoundaryPoints","deleteContents","extractContents","cloneContents","insertNode","surroundContents","cloneRange","toString","detach"],T=["boundingHeight","boundingLeft","boundingTop","boundingWidth","htmlText","text"],A=["collapse","compareEndPoints","duplicate","moveToElementText","parentElement","select","setEndPoint","getBoundingClientRect"],O=r(t),b=r(n),x=r(o),_={},D={version:"%%build:version%%",initialized:!1,supported:!0,util:{isHostMethod:t,isHostObject:n,isHostProperty:o,areHostMethods:O,areHostObjects:b,areHostProperties:x,isTextRange:i,getBody:a},features:{},modules:_,config:{alertOnFail:!0,alertOnWarn:!1,preferTextRange:!1}};D.fail=l,D.warn=d,{}.hasOwnProperty?D.util.extend=function(e,t,n){var o,r;for(var i in t)t.hasOwnProperty(i)&&(o=e[i],r=t[i],n&&null!==o&&"object"==typeof o&&null!==r&&"object"==typeof r&&D.util.extend(o,r,!0),e[i]=r);return t.hasOwnProperty("toString")&&(e.toString=t.toString),e}:l("hasOwnProperty not supported"),function(){var e=document.createElement("div");e.appendChild(document.createElement("span"));var t,n=[].slice;try{1==n.call(e.childNodes,0)[0].nodeType&&(t=function(e){return n.call(e,0)})}catch(o){}t||(t=function(e){for(var t=[],n=0,o=e.length;o>n;++n)t[n]=e[n];return t}),D.util.toArray=t}();var P;t(document,"addEventListener")?P=function(e,t,n){e.addEventListener(t,n,!1)}:t(document,"attachEvent")?P=function(e,t,n){e.attachEvent("on"+t,n)}:l("Document does not have required addEventListener or attachEvent method"),D.util.addListener=P;var I=[];D.init=f,D.addInitListener=function(e){D.initialized?e(D):I.push(e)};var L=[];D.addCreateMissingNativeApiListener=function(e){L.push(e)},D.createMissingNativeApi=h,g.prototype={init:function(e){for(var t,n,o=this.dependencies||[],r=0,i=o.length;i>r;++r){if(n=o[r],t=_[n],!(t&&t instanceof g))throw new Error("required module '"+n+"' not found");if(t.init(),!t.supported)throw new Error("required module '"+n+"' not supported")}this.initializer(this)},fail:function(e){throw this.initialized=!0,this.supported=!1,R.error("Module '"+this.name+"' failed to load: "+e),new Error("Module '"+this.name+"' failed to load: "+e)},warn:function(e){D.warn("Module "+this.name+": "+e)},deprecationNotice:function(e,t){D.warn("DEPRECATED: "+e+" in module "+this.name+"is deprecated. Please use "+t+" instead")},createError:function(e){return new Error("Error in Rangy "+this.name+" module: "+e)}},D.createModule=function(e){var t,n;2==arguments.length?(t=arguments[1],n=[]):(t=arguments[2],n=arguments[1]),p(!1,e,n,t)},D.createCoreModule=function(e,t,n){p(!0,e,t,n)},D.RangePrototype=m,D.rangePrototype=new m,D.selectionPrototype=new v;var H=!1,B=function(e){R.info("loadHandler, event is "+e.type),H||(H=!0,D.initialized||f())};return typeof window==E?void l("No window found"):typeof document==E?void l("No document found"):(t(document,"addEventListener")&&document.addEventListener("DOMContentLoaded",B,!1),P(window,"load",B),N&&e.define(function(){return D.amd=!0,D}),void(e.rangy=D))}(this),rangy.createCoreModule("DomUtil",[],function(e,t){function n(e){var t;return typeof e.namespaceURI==_||null===(t=e.namespaceURI)||"http://www.w3.org/1999/xhtml"==t}function o(e){var t=e.parentNode;return 1==t.nodeType?t:null}function r(e){for(var t=0;e=e.previousSibling;)++t;return t}function i(e){switch(e.nodeType){case 7:case 10:return 0;case 3:case 8:return e.length;default:return e.childNodes.length}}function a(e,t){var n,o=[];for(n=e;n;n=n.parentNode)o.push(n);for(n=t;n;n=n.parentNode)if(L(o,n))return n;return null}function s(e,t,n){for(var o=n?t:t.parentNode;o;){if(o===e)return!0;o=o.parentNode}return!1}function c(e,t){return s(e,t,!0)}function l(e,t,n){for(var o,r=n?e:e.parentNode;r;){if(o=r.parentNode,o===t)return r;r=o}return null}function d(e){var t=e.nodeType;return 3==t||4==t||8==t}function u(e){if(!e)return!1;var t=e.nodeType;return 3==t||8==t}function f(e,t){var n=t.nextSibling,o=t.parentNode;return n?o.insertBefore(e,n):o.appendChild(e),e}function h(e,t,n){x.debug("splitDataNode called at index "+t+" in node "+S(e));var o=e.cloneNode(!1);if(o.deleteData(0,t),e.deleteData(t,e.length-t),f(o,e),n)for(var i,a=0;i=n[a++];)i.node==e&&i.offset>t?(i.node=o,i.offset-=t):i.node==e.parentNode&&i.offset>r(e)&&++i.offset;return o}function g(e){if(9==e.nodeType)return e;if(typeof e.ownerDocument!=_)return e.ownerDocument;if(typeof e.document!=_)return e.document;if(e.parentNode)return g(e.parentNode);throw t.createError("getDocument: no document found for node")}function p(e){var n=g(e);if(typeof n.defaultView!=_)return n.defaultView;if(typeof n.parentWindow!=_)return n.parentWindow;throw t.createError("Cannot get a window object for node")}function m(e){if(typeof e.contentDocument!=_)return e.contentDocument;if(typeof e.contentWindow!=_)return e.contentWindow.document;throw t.createError("getIframeDocument: No Document object found for iframe element")}function v(e){if(typeof e.contentWindow!=_)return e.contentWindow;if(typeof e.contentDocument!=_)return e.contentDocument.defaultView;throw t.createError("getIframeWindow: No Window object found for iframe element")}function R(e){return e&&D.isHostMethod(e,"setTimeout")&&D.isHostObject(e,"document")}function N(e,t,n){var o;if(e?D.isHostProperty(e,"nodeType")?o=1==e.nodeType&&"iframe"==e.tagName.toLowerCase()?m(e):g(e):R(e)&&(o=e.document):o=document,!o)throw t.createError(n+"(): Parameter must be a Window object or DOM node");return o}function C(e){for(var t;t=e.parentNode;)e=t;return e}function y(e,n,o,i){var s,c,d,u,f;if(e==o)return x.debug("case 1"),n===i?0:i>n?-1:1;if(s=l(o,e,!0))return x.debug("case 2",S(s),r(s)),n<=r(s)?-1:1;if(s=l(e,o,!0))return x.debug("case 3"),r(s)<i?-1:1;if(c=a(e,o),!c)throw new Error("comparePoints error: nodes have no common ancestor");if(x.debug("case 4"),d=e===c?c:l(e,c,!0),u=o===c?c:l(o,c,!0),d===u)throw x.warn("comparePoints got to case 4 and childA and childB are the same!",e,n,o,i),t.createError("comparePoints got to case 4 and childA and childB are the same!");for(f=c.firstChild;f;){if(f===d)return-1;if(f===u)return 1;f=f.nextSibling}}function E(e){var t;try{return t=e.parentNode,!1}catch(n){return!0}}function S(e){if(!e)return"[No node]";if(H&&E(e))return"[Broken node]";if(d(e))return'"'+e.data+'"';if(1==e.nodeType){var t=e.id?' id="'+e.id+'"':"";return"<"+e.nodeName+t+">[index:"+r(e)+",length:"+e.childNodes.length+"]["+(e.innerHTML||"[innerHTML not supported]").slice(0,25)+"]"}return e.nodeName}function w(e){for(var t,n=g(e).createDocumentFragment();t=e.firstChild;)n.appendChild(t);return n}function T(e){this.root=e,this._next=e}function A(e){return new T(e)}function O(e,t){this.node=e,this.offset=t}function b(e){this.code=this[e],this.codeName=e,this.message="DOMException: "+this.codeName}var x=log4javascript.getLogger("rangy.dom"),_="undefined",D=e.util;D.areHostMethods(document,["createDocumentFragment","createElement","createTextNode"])||t.fail("document missing a Node creation method"),D.isHostMethod(document,"getElementsByTagName")||t.fail("document missing getElementsByTagName method");var P=document.createElement("div");D.areHostMethods(P,["insertBefore","appendChild","cloneNode"]||!D.areHostObjects(P,["previousSibling","nextSibling","childNodes","parentNode"]))||t.fail("Incomplete Element implementation"),D.isHostProperty(P,"innerHTML")||t.fail("Element is missing innerHTML property");var I=document.createTextNode("test");D.areHostMethods(I,["splitText","deleteData","insertData","appendData","cloneNode"]||!D.areHostObjects(P,["previousSibling","nextSibling","childNodes","parentNode"])||!D.areHostProperties(I,["data"]))||t.fail("Incomplete Text Node implementation");var L=function(e,t){for(var n=e.length;n--;)if(e[n]===t)return!0;return!1},H=!1;!function(){var t=document.createElement("b");t.innerHTML="1";var n=t.firstChild;t.innerHTML="<br/>",H=E(n),e.features.crashyTextNodes=H}();var B;typeof window.getComputedStyle!=_?B=function(e,t){return p(e).getComputedStyle(e,null)[t]}:typeof document.documentElement.currentStyle!=_?B=function(e,t){return e.currentStyle[t]}:t.fail("No means of obtaining computed style properties found"),T.prototype={_current:null,hasNext:function(){return!!this._next},next:function(){var e,t,n=this._current=this._next;if(this._current)if(e=n.firstChild)this._next=e;else{for(t=null;n!==this.root&&!(t=n.nextSibling);)n=n.parentNode;this._next=t}return this._current},detach:function(){this._current=this._next=this.root=null}},O.prototype={equals:function(e){return!!e&&this.node===e.node&&this.offset==e.offset},inspect:function(){return"[DomPosition("+S(this.node)+":"+this.offset+")]"},toString:function(){return this.inspect()}},b.prototype={INDEX_SIZE_ERR:1,HIERARCHY_REQUEST_ERR:3,WRONG_DOCUMENT_ERR:4,NO_MODIFICATION_ALLOWED_ERR:7,NOT_FOUND_ERR:8,NOT_SUPPORTED_ERR:9,INVALID_STATE_ERR:11},b.prototype.toString=function(){return this.message},e.dom={arrayContains:L,isHtmlNamespace:n,parentElement:o,getNodeIndex:r,getNodeLength:i,getCommonAncestor:a,isAncestorOf:s,isOrIsAncestorOf:c,getClosestAncestorIn:l,isCharacterDataNode:d,isTextOrCommentNode:u,insertAfter:f,splitDataNode:h,getDocument:g,getWindow:p,getIframeWindow:v,getIframeDocument:m,getBody:D.getBody,isWindow:R,getContentDocument:N,getRootContainer:C,comparePoints:y,isBrokenNode:E,inspectNode:S,getComputedStyleProperty:B,fragmentFromNodeChildren:w,createIterator:A,DomPosition:O},e.DOMException=b}),rangy.createCoreModule("DomRange",["DomUtil"],function(e,t){function n(e,t){return 3!=e.nodeType&&(V(e,t.startContainer)||V(e,t.endContainer))}function o(e){return e.document||X(e.startContainer)}function r(e){return new F(e.parentNode,z(e))}function i(e){return new F(e.parentNode,z(e)+1)}function a(e,t,n){var o=11==e.nodeType?e.firstChild:e;return U(t)?n==t.length?W.insertAfter(e,t):t.parentNode.insertBefore(e,0==n?t:$(t,n)):n>=t.childNodes.length?t.appendChild(e):t.insertBefore(e,t.childNodes[n]),o}function s(e,t,n){if(O(e),O(t),o(t)!=o(e))throw new j("WRONG_DOCUMENT_ERR");var r=q(e.startContainer,e.startOffset,t.endContainer,t.endOffset),i=q(e.endContainer,e.endOffset,t.startContainer,t.startOffset);return n?0>=r&&i>=0:0>r&&i>0}function c(e){for(var t,n,r,i=o(e.range).createDocumentFragment();n=e.next();){if(t=e.isPartiallySelectedSubtree(),M.debug("cloneSubtree got node "+W.inspectNode(n)+" from iterator. partiallySelected: "+t),n=n.cloneNode(!t),t&&(r=e.getSubtreeIterator(),n.appendChild(c(r)),r.detach()),10==n.nodeType)throw new j("HIERARCHY_REQUEST_ERR");i.appendChild(n)}return i}function l(e,t,n){var o,r;n=n||{stop:!1};for(var i,a;i=e.next();)if(e.isPartiallySelectedSubtree()){if(t(i)===!1)return void(n.stop=!0);if(a=e.getSubtreeIterator(),l(a,t,n),a.detach(),n.stop)return}else for(o=W.createIterator(i);r=o.next();)if(t(r)===!1)return void(n.stop=!0)}function d(e){for(var t;e.next();)e.isPartiallySelectedSubtree()?(t=e.getSubtreeIterator(),d(t),t.detach()):e.remove()}function u(e){M.debug("extract on iterator",e);for(var t,n,r=o(e.range).createDocumentFragment();t=e.next();){if(M.debug("extractSubtree got node "+W.inspectNode(t)+" from iterator. partiallySelected: "+e.isPartiallySelectedSubtree()),e.isPartiallySelectedSubtree()?(t=t.cloneNode(!1),n=e.getSubtreeIterator(),t.appendChild(u(n)),n.detach()):e.remove(),10==t.nodeType)throw new j("HIERARCHY_REQUEST_ERR");r.appendChild(t)}return r}function f(e,t,n){var o,r=!(!t||!t.length),i=!!n;r&&(o=new RegExp("^("+t.join("|")+")$"));var a=[];return l(new g(e,!1),function(t){if((!r||o.test(t.nodeType))&&(!i||n(t))){var s=e.startContainer;if(t!=s||!U(s)||e.startOffset!=s.length){var c=e.endContainer;t==c&&U(c)&&0==e.endOffset||a.push(t)}}}),a}function h(e){var t="undefined"==typeof e.getName?"Range":e.getName();return"["+t+"("+W.inspectNode(e.startContainer)+":"+e.startOffset+", "+W.inspectNode(e.endContainer)+":"+e.endOffset+")]"}function g(e,t){if(this.range=e,this.clonePartiallySelectedTextNodes=t,M.info("New RangeIterator ",W.inspectNode(e.startContainer),e.startOffset,W.inspectNode(e.endContainer),e.endOffset),!e.collapsed){this.sc=e.startContainer,this.so=e.startOffset,this.ec=e.endContainer,this.eo=e.endOffset;var n=e.commonAncestorContainer;this.sc===this.ec&&U(this.sc)?(this.isSingleCharacterDataNode=!0,this._first=this._last=this._next=this.sc):(this._first=this._next=this.sc!==n||U(this.sc)?Y(this.sc,n,!0):this.sc.childNodes[this.so],this._last=this.ec!==n||U(this.ec)?Y(this.ec,n,!0):this.ec.childNodes[this.eo-1]),M.info("RangeIterator first and last",W.inspectNode(this._first),W.inspectNode(this._last))}}function p(e){this.code=this[e],this.codeName=e,this.message="RangeException: "+this.codeName}function m(e){return function(t,n){for(var o,r=n?t:t.parentNode;r;){if(o=r.nodeType,Q(e,o))return r;r=r.parentNode}return null}}function v(e,t){if(ae(e,t))throw new p("INVALID_NODE_TYPE_ERR")}function R(e){if(!e.startContainer)throw new j("INVALID_STATE_ERR_1")}function N(e,t){if(!Q(t,e.nodeType))throw new p("INVALID_NODE_TYPE_ERR")}function C(e,t){if(0>t||t>(U(e)?e.length:e.childNodes.length))throw new j("INDEX_SIZE_ERR")}function y(e,t){if(re(e,!0)!==re(t,!0))throw new j("WRONG_DOCUMENT_ERR")}function E(e){if(ie(e,!0))throw new j("NO_MODIFICATION_ALLOWED_ERR")}function S(e,t){if(!e)throw new j(t)}function w(e){return Z&&W.isBrokenNode(e)||!Q(ee,e.nodeType)&&!re(e,!0)}function T(e,t){return t<=(U(e)?e.length:e.childNodes.length)}function A(e){return!!e.startContainer&&!!e.endContainer&&!w(e.startContainer)&&!w(e.endContainer)&&T(e.startContainer,e.startOffset)&&T(e.endContainer,e.endOffset)}function O(e){if(R(e),!A(e))throw new Error("Range error: Range is no longer valid after DOM mutation ("+e.inspect()+")")}function b(e,t){O(e),M.debug("splitBoundaries called "+e.inspect(),t);var n=e.startContainer,o=e.startOffset,r=e.endContainer,i=e.endOffset,a=n===r;U(r)&&i>0&&i<r.length&&($(r,i,t),M.debug("Split end",W.inspectNode(r),i)),U(n)&&o>0&&o<n.length&&(M.debug("Splitting start",W.inspectNode(n),o),n=$(n,o,t),a?(i-=o,r=n):r==n.parentNode&&i>=z(n)&&i++,o=0,M.debug("Split start",W.inspectNode(n),o)),e.setStartAndEnd(n,o,r,i),M.debug("splitBoundaries done")}function x(e){e.START_TO_START=fe,e.START_TO_END=he,e.END_TO_END=ge,e.END_TO_START=pe,e.NODE_BEFORE=me,e.NODE_AFTER=ve,e.NODE_BEFORE_AND_AFTER=Re,e.NODE_INSIDE=Ne}function _(e){x(e),x(e.prototype)}function D(e,t){return function(){O(this);var n,o,r=this.startContainer,a=this.startOffset,s=this.commonAncestorContainer,c=new g(this,!0);r!==s&&(n=Y(r,s,!0),o=i(n),r=o.node,a=o.offset),l(c,E),c.reset();var d=e(c);return c.detach(),t(this,r,a,r,a),d}}function P(t,o,a){function s(e,t){return function(n){R(this),N(n,K),N(J(n),ee);var o=(e?r:i)(n);(t?c:l)(this,o.node,o.offset)}}function c(e,t,n){var r=e.endContainer,i=e.endOffset;(t!==e.startContainer||n!==e.startOffset)&&((J(t)!=J(r)||1==q(t,n,r,i))&&(r=t,i=n),o(e,t,n,r,i))}function l(e,t,n){var r=e.startContainer,i=e.startOffset;(t!==e.endContainer||n!==e.endOffset)&&((J(t)!=J(r)||-1==q(t,n,r,i))&&(r=t,i=n),o(e,r,i,t,n))}var f=function(){};f.prototype=e.rangePrototype,t.prototype=new f,k.extend(t.prototype,{setStart:function(e,t){R(this),v(e,!0),C(e,t),c(this,e,t)},setEnd:function(e,t){R(this),v(e,!0),C(e,t),l(this,e,t)},setStartAndEnd:function(){R(this);var e=arguments,t=e[0],n=e[1],r=t,i=n;switch(e.length){case 3:i=e[2];break;case 4:r=e[2],i=e[3]}o(this,t,n,r,i)},setBoundary:function(e,t,n){this["set"+(n?"Start":"End")](e,t)},setStartBefore:s(!0,!0),setStartAfter:s(!1,!0),setEndBefore:s(!0,!1),setEndAfter:s(!1,!1),collapse:function(e){O(this),e?o(this,this.startContainer,this.startOffset,this.startContainer,this.startOffset):o(this,this.endContainer,this.endOffset,this.endContainer,this.endOffset)},selectNodeContents:function(e){R(this),v(e,!0),o(this,e,0,e,G(e))},selectNode:function(e){R(this),v(e,!1),N(e,K);var t=r(e),n=i(e);o(this,t.node,t.offset,n.node,n.offset)},extractContents:D(u,o),deleteContents:D(d,o),canSurroundContents:function(){O(this),E(this.startContainer),E(this.endContainer);var e=new g(this,!0),t=e._first&&n(e._first,this)||e._last&&n(e._last,this);return e.detach(),!t},detach:function(){a(this)},splitBoundaries:function(){b(this)},splitBoundariesPreservingPositions:function(e){b(this,e)},normalizeBoundaries:function(){O(this);var e=this.startContainer,t=this.startOffset,n=this.endContainer,r=this.endOffset,i=function(e){var t=e.nextSibling;t&&t.nodeType==e.nodeType&&(n=e,r=e.length,e.appendData(t.data),t.parentNode.removeChild(t))},a=function(o){var i=o.previousSibling;if(i&&i.nodeType==o.nodeType){e=o;var a=o.length;if(t=i.length,o.insertData(0,i.data),i.parentNode.removeChild(i),e==n)r+=t,n=e;else if(n==o.parentNode){var s=z(o);r==s?(n=o,r=a):r>s&&r--}}},s=!0;if(U(n))n.length==r&&i(n);else{if(r>0){var c=n.childNodes[r-1];c&&U(c)&&i(c)}s=!this.collapsed}if(s){if(U(e))0==t&&a(e);else if(t<e.childNodes.length){var l=e.childNodes[t];l&&U(l)&&a(l)}}else e=n,t=r;o(this,e,t,n,r)},collapseToPoint:function(e,t){R(this),v(e,!0),C(e,t),this.setStartAndEnd(e,t)}}),_(t)}function I(e){e.collapsed=e.startContainer===e.endContainer&&e.startOffset===e.endOffset,e.commonAncestorContainer=e.collapsed?e.startContainer:W.getCommonAncestor(e.startContainer,e.endContainer)}function L(e,t,n,o,r){e.startContainer=t,e.startOffset=n,e.endContainer=o,e.endOffset=r,e.document=W.getDocument(t),I(e)}function H(e){R(e),e.startContainer=e.startOffset=e.endContainer=e.endOffset=e.document=null,e.collapsed=e.commonAncestorContainer=null}function B(e){this.startContainer=e,this.startOffset=0,this.endContainer=e,this.endOffset=0,this.document=e,I(this)}var M=log4javascript.getLogger("rangy.DomRange"),W=e.dom,k=e.util,F=W.DomPosition,j=e.DOMException,U=W.isCharacterDataNode,z=W.getNodeIndex,V=W.isOrIsAncestorOf,X=W.getDocument,q=W.comparePoints,$=W.splitDataNode,Y=W.getClosestAncestorIn,G=W.getNodeLength,Q=W.arrayContains,J=W.getRootContainer,Z=e.features.crashyTextNodes;
g.prototype={_current:null,_next:null,_first:null,_last:null,isSingleCharacterDataNode:!1,reset:function(){this._current=null,this._next=this._first},hasNext:function(){return!!this._next},next:function(){var e=this._current=this._next;return e&&(this._next=e!==this._last?e.nextSibling:null,U(e)&&this.clonePartiallySelectedTextNodes&&(e===this.ec&&(e=e.cloneNode(!0)).deleteData(this.eo,e.length-this.eo),this._current===this.sc&&(e=e.cloneNode(!0)).deleteData(0,this.so))),e},remove:function(){var e,t,n=this._current;!U(n)||n!==this.sc&&n!==this.ec?n.parentNode?n.parentNode.removeChild(n):M.warn("Node to be removed has no parent node. Is this the child of an attribute node in Firefox 2?"):(e=n===this.sc?this.so:0,t=n===this.ec?this.eo:n.length,e!=t&&n.deleteData(e,t-e))},isPartiallySelectedSubtree:function(){var e=this._current;return n(e,this.range)},getSubtreeIterator:function(){var e;if(this.isSingleCharacterDataNode)e=this.range.cloneRange(),e.collapse(!1);else{e=new B(o(this.range));var t=this._current,n=t,r=0,i=t,a=G(t);V(t,this.sc)&&(n=this.sc,r=this.so),V(t,this.ec)&&(i=this.ec,a=this.eo),L(e,n,r,i,a)}return new g(e,this.clonePartiallySelectedTextNodes)},detach:function(){this.range=this._current=this._next=this._first=this._last=this.sc=this.so=this.ec=this.eo=null}},p.prototype={BAD_BOUNDARYPOINTS_ERR:1,INVALID_NODE_TYPE_ERR:2},p.prototype.toString=function(){return this.message};var K=[1,3,4,5,7,8,10],ee=[2,9,11],te=[5,6,10,12],ne=[1,3,4,5,7,8,10,11],oe=[1,3,4,5,7,8],re=m([9,11]),ie=m(te),ae=m([6,10,12]),se=document.createElement("style"),ce=!1;try{se.innerHTML="<b>x</b>",ce=3==se.firstChild.nodeType}catch(le){}e.features.htmlParsingConforms=ce;var de=ce?function(e){var t=this.startContainer,n=X(t);if(!t)throw new j("INVALID_STATE_ERR_2");var o=null;return 1==t.nodeType?o=t:U(t)&&(o=W.parentElement(t)),o=null===o||"HTML"==o.nodeName&&W.isHtmlNamespace(X(o).documentElement)&&W.isHtmlNamespace(o)?n.createElement("body"):o.cloneNode(!1),o.innerHTML=e,W.fragmentFromNodeChildren(o)}:function(e){R(this);var t=o(this),n=t.createElement("body");return n.innerHTML=e,W.fragmentFromNodeChildren(n)},ue=["startContainer","startOffset","endContainer","endOffset","collapsed","commonAncestorContainer"],fe=0,he=1,ge=2,pe=3,me=0,ve=1,Re=2,Ne=3;k.extend(e.rangePrototype,{compareBoundaryPoints:function(e,t){O(this),y(this.startContainer,t.startContainer);var n,o,r,i,a=e==pe||e==fe?"start":"end",s=e==he||e==fe?"start":"end";return n=this[a+"Container"],o=this[a+"Offset"],r=t[s+"Container"],i=t[s+"Offset"],q(n,o,r,i)},insertNode:function(e){if(O(this),N(e,ne),E(this.startContainer),V(e,this.startContainer))throw new j("HIERARCHY_REQUEST_ERR");var t=a(e,this.startContainer,this.startOffset);this.setStartBefore(t)},cloneContents:function(){O(this);var e,t;if(this.collapsed)return o(this).createDocumentFragment();if(this.startContainer===this.endContainer&&U(this.startContainer))return e=this.startContainer.cloneNode(!0),e.data=e.data.slice(this.startOffset,this.endOffset),t=o(this).createDocumentFragment(),t.appendChild(e),t;var n=new g(this,!0);return e=c(n),n.detach(),e},canSurroundContents:function(){O(this),E(this.startContainer),E(this.endContainer);var e=new g(this,!0),t=e._first&&n(e._first,this)||e._last&&n(e._last,this);return e.detach(),!t},surroundContents:function(e){if(N(e,oe),!this.canSurroundContents())throw new p("BAD_BOUNDARYPOINTS_ERR");var t=this.extractContents();if(e.hasChildNodes())for(;e.lastChild;)e.removeChild(e.lastChild);a(e,this.startContainer,this.startOffset),e.appendChild(t),this.selectNode(e)},cloneRange:function(){O(this);for(var e,t=new B(o(this)),n=ue.length;n--;)e=ue[n],t[e]=this[e];return t},toString:function(){O(this);var e=this.startContainer;if(e===this.endContainer&&U(e))return 3==e.nodeType||4==e.nodeType?e.data.slice(this.startOffset,this.endOffset):"";var t=[],n=new g(this,!0);return M.info("toString iterator: "+W.inspectNode(n._first)+", "+W.inspectNode(n._last)),l(n,function(e){(3==e.nodeType||4==e.nodeType)&&t.push(e.data)}),n.detach(),t.join("")},compareNode:function(e){O(this);var t=e.parentNode,n=z(e);if(!t)throw new j("NOT_FOUND_ERR");var o=this.comparePoint(t,n),r=this.comparePoint(t,n+1);return 0>o?r>0?Re:me:r>0?ve:Ne},comparePoint:function(e,t){return O(this),S(e,"HIERARCHY_REQUEST_ERR"),y(e,this.startContainer),q(e,t,this.startContainer,this.startOffset)<0?-1:q(e,t,this.endContainer,this.endOffset)>0?1:0},createContextualFragment:de,toHtml:function(){O(this);var e=this.commonAncestorContainer.parentNode.cloneNode(!1);return e.appendChild(this.cloneContents()),e.innerHTML},intersectsNode:function(e,t){if(O(this),S(e,"NOT_FOUND_ERR"),X(e)!==o(this))return!1;var n=e.parentNode,r=z(e);S(n,"NOT_FOUND_ERR");var i=q(n,r,this.endContainer,this.endOffset),a=q(n,r+1,this.startContainer,this.startOffset);return t?0>=i&&a>=0:0>i&&a>0},isPointInRange:function(e,t){return O(this),S(e,"HIERARCHY_REQUEST_ERR"),y(e,this.startContainer),q(e,t,this.startContainer,this.startOffset)>=0&&q(e,t,this.endContainer,this.endOffset)<=0},intersectsRange:function(e){return s(this,e,!1)},intersectsOrTouchesRange:function(e){return s(this,e,!0)},intersection:function(e){if(this.intersectsRange(e)){var t=q(this.startContainer,this.startOffset,e.startContainer,e.startOffset),n=q(this.endContainer,this.endOffset,e.endContainer,e.endOffset),o=this.cloneRange();return M.info("intersection",this.inspect(),e.inspect(),t,n),-1==t&&o.setStart(e.startContainer,e.startOffset),1==n&&o.setEnd(e.endContainer,e.endOffset),o}return null},union:function(e){if(this.intersectsOrTouchesRange(e)){var t=this.cloneRange();return-1==q(e.startContainer,e.startOffset,this.startContainer,this.startOffset)&&t.setStart(e.startContainer,e.startOffset),1==q(e.endContainer,e.endOffset,this.endContainer,this.endOffset)&&t.setEnd(e.endContainer,e.endOffset),t}throw new p("Ranges do not intersect")},containsNode:function(e,t){return t?this.intersectsNode(e,!1):this.compareNode(e)==Ne},containsNodeContents:function(e){return this.comparePoint(e,0)>=0&&this.comparePoint(e,G(e))<=0},containsRange:function(e){var t=this.intersection(e);return null!==t&&e.equals(t)},containsNodeText:function(e){var t=this.cloneRange();t.selectNode(e);var n=t.getNodes([3]);if(n.length>0){t.setStart(n[0],0);var o=n.pop();t.setEnd(o,o.length);var r=this.containsRange(t);return r}return this.containsNodeContents(e)},getNodes:function(e,t){return O(this),f(this,e,t)},getDocument:function(){return o(this)},collapseBefore:function(e){R(this),this.setEndBefore(e),this.collapse(!1)},collapseAfter:function(e){R(this),this.setStartAfter(e),this.collapse(!0)},getBookmark:function(t){var n=o(this),r=e.createRange(n);t=t||W.getBody(n),r.selectNodeContents(t);var i=this.intersection(r),a=0,s=0;return i&&(r.setEnd(i.startContainer,i.startOffset),a=r.toString().length,s=a+i.toString().length),{start:a,end:s,containerNode:t}},moveToBookmark:function(e){var t=e.containerNode,n=0;this.setStart(t,0),this.collapse(!0);for(var o,r,i,a,s=[t],c=!1,l=!1;!l&&(o=s.pop());)if(3==o.nodeType)r=n+o.length,!c&&e.start>=n&&e.start<=r&&(this.setStart(o,e.start-n),c=!0),c&&e.end>=n&&e.end<=r&&(this.setEnd(o,e.end-n),l=!0),n=r;else for(a=o.childNodes,i=a.length;i--;)s.push(a[i])},getName:function(){return"DomRange"},equals:function(e){return B.rangesEqual(this,e)},isValid:function(){return A(this)},inspect:function(){return h(this)}}),P(B,L,H),k.extend(B,{rangeProperties:ue,RangeIterator:g,copyComparisonConstants:_,createPrototypeRange:P,inspect:h,getRangeDocument:o,rangesEqual:function(e,t){return e.startContainer===t.startContainer&&e.startOffset===t.startOffset&&e.endContainer===t.endContainer&&e.endOffset===t.endOffset}}),e.DomRange=B,e.RangeException=p}),rangy.createCoreModule("WrappedRange",["DomRange"],function(e,t){var n,o,r=e.dom,i=e.util,a=r.DomPosition,s=e.DomRange,c=r.getBody,l=r.getContentDocument,d=r.isCharacterDataNode,u=log4javascript.getLogger("rangy.WrappedRange");if(e.features.implementsDomRange&&!function(){function o(e){for(var t,n=g.length;n--;)t=g[n],e[t]=e.nativeRange[t];e.collapsed=e.startContainer===e.endContainer&&e.startOffset===e.endOffset}function a(e,t,n,o,r){var i=e.startContainer!==t||e.startOffset!=n,a=e.endContainer!==o||e.endOffset!=r,s=!e.equals(e.nativeRange);(i||a||s)&&(e.setEnd(o,r),e.setStart(t,n))}function d(e){e.detached=!0;for(var t=g.length;t--;)e[g[t]]=null}var f,h,g=s.rangeProperties;n=function(e){if(!e)throw t.createError("WrappedRange: Range must be specified");this.nativeRange=e,o(this)},s.createPrototypeRange(n,a,d),f=n.prototype,f.selectNode=function(e){this.nativeRange.selectNode(e),o(this)},f.cloneContents=function(){return this.nativeRange.cloneContents()},f.surroundContents=function(e){this.nativeRange.surroundContents(e),o(this)},f.collapse=function(e){this.nativeRange.collapse(e),o(this)},f.cloneRange=function(){return new n(this.nativeRange.cloneRange())},f.refresh=function(){o(this)},f.toString=function(){return this.nativeRange.toString()};var p=document.createTextNode("test");c(document).appendChild(p);var m=document.createRange();m.setStart(p,0),m.setEnd(p,0);try{m.setStart(p,1),f.setStart=function(e,t){this.nativeRange.setStart(e,t),o(this)},f.setEnd=function(e,t){this.nativeRange.setEnd(e,t),o(this)},h=function(e){return function(t){this.nativeRange[e](t),o(this)}}}catch(v){u.info("Browser has bug (present in Firefox 2 and below) that prevents moving the start of a Range to a point after its current end. Correcting for it."),f.setStart=function(e,t){try{this.nativeRange.setStart(e,t)}catch(n){this.nativeRange.setEnd(e,t),this.nativeRange.setStart(e,t)}o(this)},f.setEnd=function(e,t){try{this.nativeRange.setEnd(e,t)}catch(n){this.nativeRange.setStart(e,t),this.nativeRange.setEnd(e,t)}o(this)},h=function(e,t){return function(n){try{this.nativeRange[e](n)}catch(r){this.nativeRange[t](n),this.nativeRange[e](n)}o(this)}}}f.setStartBefore=h("setStartBefore","setEndBefore"),f.setStartAfter=h("setStartAfter","setEndAfter"),f.setEndBefore=h("setEndBefore","setStartBefore"),f.setEndAfter=h("setEndAfter","setStartAfter"),f.selectNodeContents=function(e){this.setStartAndEnd(e,0,r.getNodeLength(e))},m.selectNodeContents(p),m.setEnd(p,3);var R=document.createRange();R.selectNodeContents(p),R.setEnd(p,4),R.setStart(p,2),-1==m.compareBoundaryPoints(m.START_TO_END,R)&&1==m.compareBoundaryPoints(m.END_TO_START,R)?(u.info("START_TO_END and END_TO_START wrong way round. Correcting in wrapper."),f.compareBoundaryPoints=function(e,t){return t=t.nativeRange||t,e==t.START_TO_END?e=t.END_TO_START:e==t.END_TO_START&&(e=t.START_TO_END),this.nativeRange.compareBoundaryPoints(e,t)}):f.compareBoundaryPoints=function(e,t){return this.nativeRange.compareBoundaryPoints(e,t.nativeRange||t)};var N=document.createElement("div");N.innerHTML="123";var C=N.firstChild,y=c(document);y.appendChild(N),m.setStart(C,1),m.setEnd(C,2),m.deleteContents(),"13"==C.data?(f.deleteContents=function(){this.nativeRange.deleteContents(),o(this)},f.extractContents=function(){var e=this.nativeRange.extractContents();return o(this),e}):u.info("Incorrect native Range deleteContents() implementation. Using Rangy's own."),y.removeChild(N),y=null,i.isHostMethod(m,"createContextualFragment")&&(f.createContextualFragment=function(e){return this.nativeRange.createContextualFragment(e)}),c(document).removeChild(p),f.getName=function(){return"WrappedRange"},e.WrappedRange=n,e.createNativeRange=function(e){return e=l(e,t,"createNativeRange"),e.createRange()}}(),e.features.implementsTextRange){var f=function(e){var t=e.parentElement();u.info("getTextRangeContainerElement parentEl is "+r.inspectNode(t));var n=e.duplicate();n.collapse(!0);var o=n.parentElement();n=e.duplicate(),n.collapse(!1);var i=n.parentElement(),a=o==i?o:r.getCommonAncestor(o,i);return a==t?a:r.getCommonAncestor(t,a)},h=function(e){return 0==e.compareEndPoints("StartToEnd",e)},g=function(e,t,n,o,i){var s=e.duplicate();s.collapse(n);var c=s.parentElement();if(r.isOrIsAncestorOf(t,c)||(c=t,u.warn("Collapse has moved TextRange outside its original container, so correcting",r.inspectNode(c))),u.debug("getTextRangeBoundaryPosition start "+n+", containerElement is "+r.inspectNode(c)),!c.canHaveHTML){var l=new a(c.parentNode,r.getNodeIndex(c));return{boundaryPosition:l,nodeInfo:{nodeIndex:l.offset,containerElement:l.node}}}var f=r.getDocument(c).createElement("span");f.parentNode&&f.parentNode.removeChild(f);for(var h,g,p,m,v,R=n?"StartToStart":"StartToEnd",N=i&&i.containerElement==c?i.nodeIndex:0,C=c.childNodes.length,y=C,E=y;;){if(u.debug("nodeIndex is "+E+", start: "+N+", end: "+y),E==C?c.appendChild(f):c.insertBefore(f,c.childNodes[E]),s.moveToElementText(f),h=s.compareEndPoints(R,e),0==h||N==y)break;if(-1==h){if(y==N+1)break;N=E}else y=y==N+1?N:E;E=Math.floor((N+y)/2),c.removeChild(f)}if(u.debug("*** GOT node index "+E),v=f.nextSibling,-1==h&&v&&d(v)){s.setEndPoint(n?"EndToStart":"EndToEnd",e);var S;if(/[\r\n]/.test(v.data)){var w=s.duplicate(),T=w.text.replace(/\r\n/g,"\r").length;for(S=w.moveStart("character",T);-1==(h=w.compareEndPoints("StartToEnd",w));)S++,w.moveStart("character",1)}else S=s.text.length;m=new a(v,S)}else u.debug("Range boundary is at node boundary"),g=(o||!n)&&f.previousSibling,p=(o||n)&&f.nextSibling,u.info("workingNode: "+r.inspectNode(f)),u.info("previousNode: "+r.inspectNode(g)),u.info("nextNode: "+r.inspectNode(p)),m=p&&d(p)?new a(p,0):g&&d(g)?new a(g,g.data.length):new a(c,r.getNodeIndex(f));return f.parentNode.removeChild(f),{boundaryPosition:m,nodeInfo:{nodeIndex:E,containerElement:c}}},p=function(e,t){var n,o,i,a,s=e.offset,l=r.getDocument(e.node),u=c(l).createTextRange(),f=d(e.node);return f?(n=e.node,o=n.parentNode):(a=e.node.childNodes,n=s<a.length?a[s]:null,o=e.node),i=l.createElement("span"),i.innerHTML="&#feff;",n?o.insertBefore(i,n):o.appendChild(i),u.moveToElementText(i),u.collapse(!t),o.removeChild(i),f&&u[t?"moveStart":"moveEnd"]("character",s),u};if(o=function(e){this.textRange=e,this.refresh()},o.prototype=new s(document),o.prototype.refresh=function(){var e,t,n,o=f(this.textRange);h(this.textRange)?t=e=g(this.textRange,o,!0,!0).boundaryPosition:(u.debug("Refreshing Range from TextRange. parent element: "+r.inspectNode(o)+", parentElement(): "+r.inspectNode(this.textRange.parentElement())),n=g(this.textRange,o,!0,!1),e=n.boundaryPosition,t=g(this.textRange,o,!1,!1,n.nodeInfo).boundaryPosition),this.setStart(e.node,e.offset),this.setEnd(t.node,t.offset)},o.prototype.getName=function(){return"WrappedTextRange"},s.copyComparisonConstants(o),o.rangeToTextRange=function(e){if(e.collapsed)return p(new a(e.startContainer,e.startOffset),!0);var t=p(new a(e.startContainer,e.startOffset),!0),n=p(new a(e.endContainer,e.endOffset),!1),o=c(s.getRangeDocument(e)).createTextRange();return o.setEndPoint("StartToStart",t),o.setEndPoint("EndToEnd",n),o},e.WrappedTextRange=o,!e.features.implementsDomRange||e.config.preferTextRange){var m=function(){return this}();"undefined"==typeof m.Range&&(m.Range=o),e.createNativeRange=function(e){return e=l(e,t,"createNativeRange"),c(e).createTextRange()},e.WrappedRange=o}}e.createRange=function(n){return n=l(n,t,"createRange"),new e.WrappedRange(e.createNativeRange(n))},e.createRangyRange=function(e){return e=l(e,t,"createRangyRange"),new s(e)},e.createIframeRange=function(n){return t.deprecationNotice("createIframeRange()","createRange(iframeEl)"),e.createRange(n)},e.createIframeRangyRange=function(n){return t.deprecationNotice("createIframeRangyRange()","createRangyRange(iframeEl)"),e.createRangyRange(n)},e.addCreateMissingNativeApiListener(function(t){var n=t.document;"undefined"==typeof n.createRange&&(n.createRange=function(){return e.createRange(n)}),n=t=null})}),rangy.createCoreModule("WrappedSelection",["DomRange","WrappedRange"],function(e,t){function n(e){return"string"==typeof e?/^backward(s)?$/i.test(e):!!e}function o(e,n){if(e){if(b.isWindow(e))return e;if(e instanceof v)return e.win;var o=b.getContentDocument(e,t,n);return b.getWindow(o)}return window}function r(e){return o(e,"getWinSelection").getSelection()}function i(e){return o(e,"getDocSelection").document.selection}function a(e){var t=!1;return e.anchorNode&&(t=1==b.comparePoints(e.anchorNode,e.anchorOffset,e.focusNode,e.focusOffset)),t}function s(e,t,n){var o=n?"end":"start",r=n?"start":"end";e.anchorNode=t[o+"Container"],e.anchorOffset=t[o+"Offset"],e.focusNode=t[r+"Container"],e.focusOffset=t[r+"Offset"]}function c(e){var t=e.nativeSelection;e.anchorNode=t.anchorNode,e.anchorOffset=t.anchorOffset,e.focusNode=t.focusNode,e.focusOffset=t.focusOffset}function l(e){e.anchorNode=e.focusNode=null,e.anchorOffset=e.focusOffset=0,e.rangeCount=0,e.isCollapsed=!0,e._ranges.length=0}function d(t){var n;return t instanceof D?(n=e.createNativeRange(t.getDocument()),n.setEnd(t.endContainer,t.endOffset),n.setStart(t.startContainer,t.startOffset)):t instanceof P?n=t.nativeRange:H.implementsDomRange&&t instanceof b.getWindow(t.startContainer).Range&&(n=t),n}function u(e){if(!e.length||1!=e[0].nodeType)return!1;for(var t=1,n=e.length;n>t;++t)if(!b.isAncestorOf(e[0],e[t]))return!1;return!0}function f(e){var n=e.getNodes();if(!u(n))throw t.createError("getSingleElementFromRange: range "+e.inspect()+" did not consist of a single element");return n[0]}function h(e){return!!e&&"undefined"!=typeof e.text}function g(e,t){var n=new P(t);e._ranges=[n],s(e,n,!1),e.rangeCount=1,e.isCollapsed=n.collapsed}function p(t){if(t._ranges.length=0,"None"==t.docSelection.type)l(t);else{var n=t.docSelection.createRange();if(h(n))g(t,n);else{t.rangeCount=n.length;for(var o,r=M(n.item(0)),i=0;i<t.rangeCount;++i)o=e.createRange(r),o.selectNode(n.item(i)),t._ranges.push(o);t.isCollapsed=1==t.rangeCount&&t._ranges[0].collapsed,s(t,t._ranges[t.rangeCount-1],!1)}}}function m(e,n){for(var o=e.docSelection.createRange(),r=f(n),i=M(o.item(0)),a=W(i).createControlRange(),s=0,c=o.length;c>s;++s)a.add(o.item(s));try{a.add(r)}catch(l){throw t.createError("addRange(): Element within the specified Range could not be added to control selection (does it have layout?)")}a.select(),p(e)}function v(e,t,n){this.nativeSelection=e,this.docSelection=t,this._ranges=[],this.win=n,this.refresh()}function R(e){e.win=e.anchorNode=e.focusNode=e._ranges=null,e.rangeCount=e.anchorOffset=e.focusOffset=0,e.detached=!0}function N(e,t){for(var n,o,r=ne.length;r--;)if(n=ne[r],o=n.selection,"deleteAll"==t)R(o);else if(n.win==e)return"delete"==t?(ne.splice(r,1),!0):o;return"deleteAll"==t&&(ne.length=0),null}function C(e,n){for(var o,r=M(n[0].startContainer),i=W(r).createControlRange(),a=0,s=n.length;s>a;++a){o=f(n[a]);try{i.add(o)}catch(c){throw t.createError("setRanges(): Element within one of the specified Ranges could not be added to control selection (does it have layout?)")}}i.select(),p(e)}function y(e,t){if(e.win.document!=M(t))throw new I("WRONG_DOCUMENT_ERR")}function E(t){return function(n,o){var r;this.rangeCount?(r=this.getRangeAt(0),r["set"+(t?"Start":"End")](n,o)):(r=e.createRange(this.win.document),r.setStartAndEnd(n,o)),this.setSingleRange(r,this.isBackward())}}function S(e){var t=[],n=new L(e.anchorNode,e.anchorOffset),o=new L(e.focusNode,e.focusOffset),r="function"==typeof e.getName?e.getName():"Selection";if("undefined"!=typeof e.rangeCount)for(var i=0,a=e.rangeCount;a>i;++i)t[i]=D.inspect(e.getRangeAt(i));return"["+r+"(Ranges: "+t.join(", ")+")(anchor: "+n.inspect()+", focus: "+o.inspect()+"]"}e.config.checkSelectionRanges=!0;var w,T,A="boolean",O="number",b=e.dom,x=e.util,_=x.isHostMethod,D=e.DomRange,P=e.WrappedRange,I=e.DOMException,L=b.DomPosition,H=e.features,B="Control",M=b.getDocument,W=b.getBody,k=D.rangesEqual,F=log4javascript.getLogger("rangy.WrappedSelection"),j=_(window,"getSelection"),U=x.isHostObject(document,"selection");H.implementsWinGetSelection=j,H.implementsDocSelection=U;var z=U&&(!j||e.config.preferTextRange);z?(w=i,e.isSelectionValid=function(e){var t=o(e,"isSelectionValid").document,n=t.selection;return"None"!=n.type||M(n.createRange().parentElement())==t}):j?(w=r,e.isSelectionValid=function(){return!0}):t.fail("Neither document.selection or window.getSelection() detected."),e.getNativeSelection=w;var V=w(),X=e.createNativeRange(document),q=W(document),$=x.areHostProperties(V,["anchorNode","focusNode","anchorOffset","focusOffset"]);H.selectionHasAnchorAndFocus=$;var Y=_(V,"extend");H.selectionHasExtend=Y;var G=typeof V.rangeCount==O;H.selectionHasRangeCount=G;var Q=!1,J=!0,Z=Y?function(t,n){var o=D.getRangeDocument(n),r=e.createRange(o);r.collapseToPoint(n.endContainer,n.endOffset),t.addRange(d(r)),t.extend(n.startContainer,n.startOffset)}:null;x.areHostMethods(V,["addRange","getRangeAt","removeAllRanges"])&&typeof V.rangeCount==O&&H.implementsDomRange&&!function(){var t=window.getSelection();if(t){for(var n=t.rangeCount,o=n>1,r=[],i=a(t),s=0;n>s;++s)r[s]=t.getRangeAt(s);var c=W(document),l=c.appendChild(document.createElement("div"));l.contentEditable="false";var d=l.appendChild(document.createTextNode("   ")),u=document.createRange();if(u.setStart(d,1),u.collapse(!0),t.addRange(u),J=1==t.rangeCount,t.removeAllRanges(),!o){var f=u.cloneRange();u.setStart(d,0),f.setEnd(d,3),f.setStart(d,2),t.addRange(u),t.addRange(f),Q=2==t.rangeCount,f.detach()}for(c.removeChild(l),t.removeAllRanges(),s=0;n>s;++s)0==s&&i?Z?Z(t,r[s]):(e.warn("Rangy initialization: original selection was backwards but selection has been restored forwards because the browser does not support Selection.extend"),t.addRange(r[s])):t.addRange(r[s])}}(),H.selectionSupportsMultipleRanges=Q,H.collapsedNonEditableSelectionsSupported=J;var K,ee=!1;q&&_(q,"createControlRange")&&(K=q.createControlRange(),x.areHostProperties(K,["item","add"])&&(ee=!0)),H.implementsControlRange=ee,T=$?function(e){return e.anchorNode===e.focusNode&&e.anchorOffset===e.focusOffset}:function(e){return e.rangeCount?e.getRangeAt(e.rangeCount-1).collapsed:!1};var te;_(V,"getRangeAt")?te=function(e,t){try{return e.getRangeAt(t)}catch(n){return null}}:$&&(te=function(t){var n=M(t.anchorNode),o=e.createRange(n);return o.setStartAndEnd(t.anchorNode,t.anchorOffset,t.focusNode,t.focusOffset),o.collapsed!==this.isCollapsed&&o.setStartAndEnd(t.focusNode,t.focusOffset,t.anchorNode,t.anchorOffset),o}),v.prototype=e.selectionPrototype;var ne=[],oe=function(e){if(e&&e instanceof v)return e.refresh(),e;e=o(e,"getNativeSelection");var t=N(e),n=w(e),r=U?i(e):null;return t?(t.nativeSelection=n,t.docSelection=r,t.refresh()):(t=new v(n,r,e),ne.push({win:e,selection:t})),t};e.getSelection=oe,e.getIframeSelection=function(n){return t.deprecationNotice("getIframeSelection()","getSelection(iframeEl)"),e.getSelection(b.getIframeWindow(n))};var re=v.prototype;if(!z&&$&&x.areHostMethods(V,["removeAllRanges","addRange"])){re.removeAllRanges=function(){this.nativeSelection.removeAllRanges(),l(this)};var ie=function(e,t){Z(e.nativeSelection,t),e.refresh()};G?re.addRange=function(t,o){if(ee&&U&&this.docSelection.type==B)m(this,t);else if(n(o)&&Y)ie(this,t);else{var r;if(Q?r=this.rangeCount:(this.removeAllRanges(),r=0),this.nativeSelection.addRange(d(t).cloneRange()),this.rangeCount=this.nativeSelection.rangeCount,this.rangeCount==r+1){if(e.config.checkSelectionRanges){var i=te(this.nativeSelection,this.rangeCount-1);i&&!k(i,t)&&(t=new P(i))}this._ranges[this.rangeCount-1]=t,s(this,t,ce(this.nativeSelection)),this.isCollapsed=T(this)}else this.refresh()}}:re.addRange=function(e,t){n(t)&&Y?ie(this,e):(this.nativeSelection.addRange(d(e)),this.refresh())},re.setRanges=function(e){if(ee&&e.length>1)C(this,e);else{this.removeAllRanges();for(var t=0,n=e.length;n>t;++t)this.addRange(e[t])}}}else{if(!(_(V,"empty")&&_(X,"select")&&ee&&z))return t.fail("No means of selecting a Range or TextRange was found"),!1;re.removeAllRanges=function(){try{if(this.docSelection.empty(),"None"!=this.docSelection.type){var e;if(this.anchorNode)e=M(this.anchorNode);else if(this.docSelection.type==B){var t=this.docSelection.createRange();t.length&&(e=M(t.item(0)))}if(e){var n=W(e).createTextRange();n.select(),this.docSelection.empty()}}}catch(o){}l(this)},re.addRange=function(t){this.docSelection.type==B?m(this,t):(e.WrappedTextRange.rangeToTextRange(t).select(),this._ranges[0]=t,this.rangeCount=1,this.isCollapsed=this._ranges[0].collapsed,s(this,t,!1))},re.setRanges=function(e){this.removeAllRanges();var t=e.length;t>1?C(this,e):t&&this.addRange(e[0])}}re.getRangeAt=function(e){if(0>e||e>=this.rangeCount)throw new I("INDEX_SIZE_ERR");return this._ranges[e].cloneRange()};var ae;if(z)ae=function(t){var n;e.isSelectionValid(t.win)?n=t.docSelection.createRange():(n=W(t.win.document).createTextRange(),n.collapse(!0)),F.warn("selection refresh called, selection type: "+t.docSelection.type),t.docSelection.type==B?p(t):h(n)?g(t,n):l(t)};else if(_(V,"getRangeAt")&&typeof V.rangeCount==O)ae=function(t){if(ee&&U&&t.docSelection.type==B)p(t);else if(t._ranges.length=t.rangeCount=t.nativeSelection.rangeCount,t.rangeCount){for(var n=0,o=t.rangeCount;o>n;++n)t._ranges[n]=new e.WrappedRange(t.nativeSelection.getRangeAt(n));s(t,t._ranges[t.rangeCount-1],ce(t.nativeSelection)),t.isCollapsed=T(t)}else l(t)};else{if(!$||typeof V.isCollapsed!=A||typeof X.collapsed!=A||!H.implementsDomRange)return t.fail("No means of obtaining a Range or TextRange from the user's selection was found"),!1;ae=function(e){var t,n=e.nativeSelection;n.anchorNode?(t=te(n,0),e._ranges=[t],e.rangeCount=1,c(e),e.isCollapsed=T(e)):l(e)}}re.refresh=function(e){var t=e?this._ranges.slice(0):null,n=this.anchorNode,o=this.anchorOffset;if(ae(this),e){var r=t.length;if(r!=this._ranges.length)return F.debug("Selection.refresh: Range count has changed: was "+r+", is now "+this._ranges.length),!0;if(this.anchorNode!=n||this.anchorOffset!=o)return F.debug("Selection.refresh: anchor different, so selection has changed"),!0;for(;r--;)if(!k(t[r],this._ranges[r]))return F.debug("Selection.refresh: Range at index "+r+" has changed: was "+t[r].inspect()+", is now "+this._ranges[r].inspect()),!0;return!1}};var se=function(e,t){var n=e.getAllRanges();e.removeAllRanges();for(var o=0,r=n.length;r>o;++o)k(t,n[o])||e.addRange(n[o]);e.rangeCount||l(e)};ee?re.removeRange=function(e){if(this.docSelection.type==B){for(var t,n=this.docSelection.createRange(),o=f(e),r=M(n.item(0)),i=W(r).createControlRange(),a=!1,s=0,c=n.length;c>s;++s)t=n.item(s),t!==o||a?i.add(n.item(s)):a=!0;i.select(),p(this)}else se(this,e)}:re.removeRange=function(e){se(this,e)};var ce;!z&&$&&H.implementsDomRange?(ce=a,re.isBackward=function(){return ce(this)}):ce=re.isBackward=function(){return!1},re.isBackwards=re.isBackward,re.toString=function(){F.debug("selection toString called");for(var e=[],t=0,n=this.rangeCount;n>t;++t)e[t]=""+this._ranges[t];return e.join("")},re.collapse=function(t,n){y(this,t);var o=e.createRange(t);o.collapseToPoint(t,n),this.setSingleRange(o),this.isCollapsed=!0},re.collapseToStart=function(){if(!this.rangeCount)throw new I("INVALID_STATE_ERR_3");var e=this._ranges[0];this.collapse(e.startContainer,e.startOffset)},re.collapseToEnd=function(){if(!this.rangeCount)throw new I("INVALID_STATE_ERR_4");var e=this._ranges[this.rangeCount-1];this.collapse(e.endContainer,e.endOffset)},re.selectAllChildren=function(t){y(this,t);var n=e.createRange(t);n.selectNodeContents(t),this.setSingleRange(n)},re.deleteFromDocument=function(){if(ee&&U&&this.docSelection.type==B){for(var e,t=this.docSelection.createRange();t.length;)e=t.item(0),t.remove(e),e.parentNode.removeChild(e);this.refresh()}else if(this.rangeCount){var n=this.getAllRanges();if(n.length){this.removeAllRanges();for(var o=0,r=n.length;r>o;++o)n[o].deleteContents();this.addRange(n[r-1])}}},re.eachRange=function(e,t){for(var n=0,o=this._ranges.length;o>n;++n)if(e(this.getRangeAt(n)))return t},re.getAllRanges=function(){var e=[];return this.eachRange(function(t){e.push(t)}),e},re.setSingleRange=function(e,t){this.removeAllRanges(),this.addRange(e,t)},re.callMethodOnEachRange=function(e,t){var n=[];return this.eachRange(function(o){n.push(o[e].apply(o,t))}),n},re.setStart=E(!0),re.setEnd=E(!1),e.rangePrototype.select=function(e){oe(this.getDocument()).setSingleRange(this,e)},re.changeEachRange=function(e){var t=[],n=this.isBackward();this.eachRange(function(n){e(n),t.push(n)}),this.removeAllRanges(),n&&1==t.length?this.addRange(t[0],"backward"):this.setRanges(t)},re.containsNode=function(e,t){return this.eachRange(function(n){return n.containsNode(e,t)},!0)},re.getBookmark=function(e){return{backward:this.isBackward(),rangeBookmarks:this.callMethodOnEachRange("getBookmark",[e])}},re.moveToBookmark=function(t){for(var n,o,r=[],i=0;n=t.rangeBookmarks[i++];)o=e.createRange(this.win),o.moveToBookmark(n),r.push(o);t.backward?this.setSingleRange(r[0],"backward"):this.setRanges(r)},re.toHtml=function(){return this.callMethodOnEachRange("toHtml").join("")},re.getName=function(){return"WrappedSelection"},re.inspect=function(){return S(this)},re.detach=function(){N(this.win,"delete"),R(this)},v.detachAll=function(){N(null,"deleteAll")},v.inspect=S,v.isDirectionBackward=n,e.Selection=v,e.selectionPrototype=re,e.addCreateMissingNativeApiListener(function(e){"undefined"==typeof e.getSelection&&(e.getSelection=function(){return oe(e)}),e=null})}),rangy.createModule("ClassApplier",["WrappedSelection"],function(e,t){function n(e,t){for(var n in e)if(e.hasOwnProperty(n)&&t(n,e[n])===!1)return!1;return!0}function o(e){return e.replace(/^\s\s*/,"").replace(/\s\s*$/,"")}function r(e,t){return e.className&&new RegExp("(?:^|\\s)"+t+"(?:\\s|$)").test(e.className)}function i(e,t){e.className?r(e,t)||(e.className+=" "+t):e.className=t}function a(e){return e.split(/\s+/).sort().join(" ")}function s(e){return a(e.className)}function c(e,t){return s(e)==s(t)}function l(e,t,n,o,r){var i=e.node,a=e.offset,s=i,c=a;i==o&&a>r&&++c,i!=t||a!=n&&a!=n+1||(s=o,c+=r-n),i==t&&a>n+1&&--c,e.node=s,e.offset=c}function d(e,t,n){B.debug("movePositionWhenRemovingNode "+e,e.node==t,e.offset,n),e.node==t&&e.offset>n&&--e.offset}function u(e,t,n,o){B.group("movePreservingPositions "+I.inspectNode(e)+" to index "+n+" in "+I.inspectNode(t),o),-1==n&&(n=t.childNodes.length);for(var r,i=e.parentNode,a=I.getNodeIndex(e),s=0;r=o[s++];)l(r,i,a,t,n);t.childNodes.length==n?t.appendChild(e):t.insertBefore(e,t.childNodes[n]),B.groupEnd()}function f(e,t){B.group("removePreservingPositions "+I.inspectNode(e),t);for(var n,o=e.parentNode,r=I.getNodeIndex(e),i=0;n=t[i++];)d(n,o,r);e.parentNode.removeChild(e),B.groupEnd()}function h(e,t,n,o,r){for(var i,a=[];i=e.firstChild;)u(i,t,n++,r),a.push(i);return o&&f(e,r),a}function g(e,t){return h(e,e.parentNode,I.getNodeIndex(e),!0,t)}function p(e,t){var n=e.cloneRange();n.selectNodeContents(t);var o=n.intersection(e),r=o?o.toString():"";return""!=r}function m(e){for(var t,n=e.getNodes([3]),o=0;(t=n[o])&&!p(e,t);)++o;for(var r=n.length-1;(t=n[r])&&!p(e,t);)--r;return n.slice(o,r+1)}function v(e,t){if(e.attributes.length!=t.attributes.length)return!1;for(var n,o,r,i=0,a=e.attributes.length;a>i;++i)if(n=e.attributes[i],r=n.name,"class"!=r){if(o=t.attributes.getNamedItem(r),null===n!=(null===o))return!1;if(n.specified!=o.specified)return!1;if(n.specified&&n.nodeValue!==o.nodeValue)return!1}return!0}function R(e,t){for(var n,o=0,r=e.attributes.length;r>o;++o)if(n=e.attributes[o].name,(!t||!H(t,n))&&e.attributes[o].specified&&"class"!=n)return!0;return!1}function N(e,t){return n(t,function(t,n){if("object"==typeof n){if(!N(e[t],n))return!1}else if(e[t]!==n)return!1})}function C(e){var t;return e&&1==e.nodeType&&((t=e.parentNode)&&9==t.nodeType&&"on"==t.designMode||F(e)&&!F(e.parentNode))}function y(e){return(F(e)||1!=e.nodeType&&F(e.parentNode))&&!C(e)}function E(e){return e&&1==e.nodeType&&!j.test(k(e,"display"))}function S(e){if(0==e.data.length)return!0;if(U.test(e.data))return!1;var t=k(e.parentNode,"whiteSpace");switch(t){case"pre":case"pre-wrap":case"-moz-pre-wrap":return!1;case"pre-line":if(/[\r\n]/.test(e.data))return!1}return E(e.previousSibling)||E(e.nextSibling)}function w(e){
var t,n,o=[];for(t=0;n=e[t++];)o.push(new L(n.startContainer,n.startOffset),new L(n.endContainer,n.endOffset));return o}function T(e,t){for(var n,o,r,i=0,a=e.length;a>i;++i)n=e[i],o=t[2*i],r=t[2*i+1],n.setStartAndEnd(o.node,o.offset,r.node,r.offset)}function A(e,t){return I.isCharacterDataNode(e)?0==t?!!e.previousSibling:t==e.length?!!e.nextSibling:!0:t>0&&t<e.childNodes.length}function O(e,n,o,r){var i,a,s=0==o;if(I.isAncestorOf(n,e))return B.info("splitNodeAt(): Descendant is ancestor of node"),e;if(I.isCharacterDataNode(n)){var c=I.getNodeIndex(n);if(0==o)o=c;else{if(o!=n.length)throw t.createError("splitNodeAt() should not be called with offset in the middle of a data node ("+o+" in "+n.data);o=c+1}n=n.parentNode}if(A(n,o)){i=n.cloneNode(!1),a=n.parentNode,i.id&&i.removeAttribute("id");for(var l,d=0;l=n.childNodes[o];)u(l,i,d++,r);return u(i,a,I.getNodeIndex(n)+1,r),n==e?i:O(e,a,I.getNodeIndex(i),r)}if(e!=n){i=n.parentNode;var f=I.getNodeIndex(n);return s||f++,O(e,i,f,r)}return e}function b(e,t){return e.tagName==t.tagName&&c(e,t)&&v(e,t)&&"inline"==k(e,"display")&&"inline"==k(t,"display")}function x(e){var t=e?"nextSibling":"previousSibling";return function(n,o){var r=n.parentNode,i=n[t];if(i){if(i&&3==i.nodeType)return i}else if(o&&(i=r[t],B.info("adjacentNode: "+i),i&&1==i.nodeType&&b(r,i))){var a=i[e?"firstChild":"lastChild"];if(a&&3==a.nodeType)return a}return null}}function _(e){this.isElementMerge=1==e.nodeType,this.textNodes=[];var t=this.isElementMerge?e.lastChild:e;t&&(this.textNodes[0]=t)}function D(e,t,r){var i,a,s,c,l=this;l.cssClass=e;var d=null,u={};if("object"==typeof t&&null!==t){for(r=t.tagNames,d=t.elementProperties,u=t.elementAttributes,a=0;c=X[a++];)t.hasOwnProperty(c)&&(l[c]=t[c]);i=t.normalize}else i=t;l.normalize="undefined"==typeof i?!0:i,l.attrExceptions=[];var f=document.createElement(l.elementTagName);l.elementProperties=l.copyPropertiesToElement(d,f,!0),n(u,function(e){l.attrExceptions.push(e)}),l.elementAttributes=u,l.elementSortedClassName=l.elementProperties.hasOwnProperty("className")?l.elementProperties.className:e,l.applyToAnyTagName=!1;var h=typeof r;if("string"==h)"*"==r?l.applyToAnyTagName=!0:l.tagNames=o(r.toLowerCase()).split(/\s*,\s*/);else if("object"==h&&"number"==typeof r.length)for(l.tagNames=[],a=0,s=r.length;s>a;++a)"*"==r[a]?l.applyToAnyTagName=!0:l.tagNames.push(r[a].toLowerCase());else l.tagNames=[l.elementTagName]}function P(e,t,n){return new D(e,t,n)}var I=e.dom,L=I.DomPosition,H=I.arrayContains,B=log4javascript.getLogger("rangy.classapplier"),M="span",W=function(){function e(e,t,n){return t&&n?" ":""}return function(t,n){t.className&&(t.className=t.className.replace(new RegExp("(^|\\s)"+n+"(\\s|$)"),e))}}(),k=I.getComputedStyleProperty,F=function(){var e=document.createElement("div");return"boolean"==typeof e.isContentEditable?function(e){return e&&1==e.nodeType&&e.isContentEditable}:function(e){return e&&1==e.nodeType&&"false"!=e.contentEditable?"true"==e.contentEditable||F(e.parentNode):!1}}(),j=/^inline(-block|-table)?$/i,U=/[^\r\n\t\f \u200B]/,z=x(!1),V=x(!0);_.prototype={doMerge:function(e){var t=this.textNodes,n=t[0];if(t.length>1){for(var o,r,i,a,s=I.getNodeIndex(n),c=[],l=0,d=0,u=t.length;u>d;++d){if(o=t[d],r=o.parentNode,d>0&&(r.removeChild(o),r.hasChildNodes()||r.parentNode.removeChild(r),e))for(i=0;a=e[i++];)a.node==o&&(a.node=n,a.offset+=l),a.node==r&&a.offset>s&&(--a.offset,a.offset==s+1&&u-1>d&&(a.node=n,a.offset=l));c[d]=o.data,l+=o.data.length}n.data=c.join("")}return n.data},getLength:function(){for(var e=this.textNodes.length,t=0;e--;)t+=this.textNodes[e].length;return t},toString:function(){for(var e=[],t=0,n=this.textNodes.length;n>t;++t)e[t]="'"+this.textNodes[t].data+"'";return"[Merge("+e.join(",")+")]"}};var X=["elementTagName","ignoreWhiteSpace","applyToEditableOnly","useExistingElements","removeEmptyElements","onElementCreate"],q={};D.prototype={elementTagName:M,elementProperties:{},elementAttributes:{},ignoreWhiteSpace:!0,applyToEditableOnly:!1,useExistingElements:!0,removeEmptyElements:!0,onElementCreate:null,copyPropertiesToElement:function(e,t,n){var o,r,s,c,l,d,u={};for(var f in e)if(e.hasOwnProperty(f))if(c=e[f],l=t[f],"className"==f)i(t,c),i(t,this.cssClass),t[f]=a(t[f]),n&&(u[f]=t[f]);else if("style"==f){r=l,n&&(u[f]=s={});for(o in e[f])r[o]=c[o],n&&(s[o]=r[o]);this.attrExceptions.push(f)}else t[f]=c,n&&(u[f]=t[f],d=q.hasOwnProperty(f)?q[f]:f,this.attrExceptions.push(d));return n?u:""},copyAttributesToElement:function(e,t){for(var n in e)e.hasOwnProperty(n)&&t.setAttribute(n,e[n])},hasClass:function(e){return 1==e.nodeType&&H(this.tagNames,e.tagName.toLowerCase())&&r(e,this.cssClass)},getSelfOrAncestorWithClass:function(e){for(;e;){if(this.hasClass(e))return e;e=e.parentNode}return null},isModifiable:function(e){return!this.applyToEditableOnly||y(e)},isIgnorableWhiteSpaceNode:function(e){return this.ignoreWhiteSpace&&e&&3==e.nodeType&&S(e)},postApply:function(e,t,n,o){B.group("postApply "+t.toHtml());for(var r,i,a,s=e[0],c=e[e.length-1],l=[],d=s,u=c,f=0,h=c.length,g=0,p=e.length;p>g;++g)i=e[g],a=z(i,!o),B.debug("Checking for merge. text node: "+i.data+", parent: "+I.inspectNode(i.parentNode)+", preceding: "+I.inspectNode(a)),a?(r||(r=new _(a),l.push(r)),r.textNodes.push(i),i===s&&(d=r.textNodes[0],f=d.length),i===c&&(u=r.textNodes[0],h=r.getLength())):r=null;var m=V(c,!o);if(m&&(r||(r=new _(c),l.push(r)),r.textNodes.push(m)),l.length){for(B.info("Merging. Merges:",l),g=0,p=l.length;p>g;++g)l[g].doMerge(n);B.info(d.nodeValue,f,u.nodeValue,h),t.setStartAndEnd(d,f,u,h),B.info("Range after merge: "+t.inspect())}B.groupEnd()},createContainer:function(e){var t=e.createElement(this.elementTagName);return this.copyPropertiesToElement(this.elementProperties,t,!1),this.copyAttributesToElement(this.elementAttributes,t),i(t,this.cssClass),this.onElementCreate&&this.onElementCreate(t,this),t},applyToTextNode:function(e,t){B.group("Apply CSS class '"+this.cssClass+"'. textNode: "+e.data),B.info("Apply CSS class  '"+this.cssClass+"'. textNode: "+e.data);var n=e.parentNode;if(1==n.childNodes.length&&this.useExistingElements&&H(this.tagNames,n.tagName.toLowerCase())&&N(n,this.elementProperties))i(n,this.cssClass);else{var o=this.createContainer(I.getDocument(e));e.parentNode.insertBefore(o,e),o.appendChild(e)}B.groupEnd()},isRemovable:function(e){return e.tagName.toLowerCase()==this.elementTagName&&s(e)==this.elementSortedClassName&&N(e,this.elementProperties)&&!R(e,this.attrExceptions)&&this.isModifiable(e)},isEmptyContainer:function(e){var t=e.childNodes.length;return 1==e.nodeType&&this.isRemovable(e)&&(0==t||1==t&&this.isEmptyContainer(e.firstChild))},removeEmptyContainers:function(e){for(var t,n=this,o=e.getNodes([1],function(e){return n.isEmptyContainer(e)}),r=[e],i=w(r),a=0;t=o[a++];)B.debug("Removing empty container "+I.inspectNode(t)),f(t,i);T(r,i)},undoToTextNode:function(e,t,n,o){if(B.info("undoToTextNode",I.inspectNode(e),t.inspect(),I.inspectNode(n),t.containsNode(n)),!t.containsNode(n)){var r=t.cloneRange();r.selectNode(n),B.info("range end in ancestor "+r.isPointInRange(t.endContainer,t.endOffset)+", isSplitPoint "+A(t.endContainer,t.endOffset)),r.isPointInRange(t.endContainer,t.endOffset)&&(O(n,t.endContainer,t.endOffset,o),t.setEndAfter(n)),r.isPointInRange(t.startContainer,t.startOffset)&&(n=O(n,t.startContainer,t.startOffset,o))}B.info("isRemovable",this.isRemovable(n),I.inspectNode(n),"'"+n.innerHTML+"'","'"+n.parentNode.innerHTML+"'"),this.isRemovable(n)?g(n,o):W(n,this.cssClass)},applyToRange:function(e,t){t=t||[];var n=w(t||[]);e.splitBoundariesPreservingPositions(n),this.removeEmptyElements&&this.removeEmptyContainers(e);var o=m(e);if(o.length){for(var r,i=0;r=o[i++];)B.info("textnode "+r.data+" is ignorable: "+this.isIgnorableWhiteSpaceNode(r)),this.isIgnorableWhiteSpaceNode(r)||this.getSelfOrAncestorWithClass(r)||!this.isModifiable(r)||this.applyToTextNode(r,n);r=o[o.length-1],e.setStartAndEnd(o[0],0,r,r.length),this.normalize&&this.postApply(o,e,n,!1),T(t,n)}},applyToRanges:function(e){B.group("applyToRanges");for(var t=e.length;t--;)this.applyToRange(e[t],e);return B.groupEnd(),e},applyToSelection:function(t){B.group("applyToSelection");var n=e.getSelection(t);B.info("applyToSelection "+n.inspect()),n.setRanges(this.applyToRanges(n.getAllRanges())),B.groupEnd()},undoToRange:function(e,t){t=t||[];var n=w(t);B.info("undoToRange "+e.inspect(),n),e.splitBoundariesPreservingPositions(n),this.removeEmptyElements&&this.removeEmptyContainers(e,n);var o,r,i=m(e),a=i[i.length-1];if(i.length){for(var s=0,c=i.length;c>s;++s)o=i[s],r=this.getSelfOrAncestorWithClass(o),r&&this.isModifiable(o)&&this.undoToTextNode(o,e,r,n),e.setStartAndEnd(i[0],0,a,a.length);B.info("Undo set range to '"+i[0].data+"', '"+o.data+"'"),this.normalize&&this.postApply(i,e,n,!0),T(t,n)}},undoToRanges:function(e){for(var t=e.length;t--;)this.undoToRange(e[t],e);return B.groupEnd(),e},undoToSelection:function(t){var n=e.getSelection(t),o=e.getSelection(t).getAllRanges();this.undoToRanges(o),n.setRanges(o)},isAppliedToRange:function(e){if(e.collapsed||""==e.toString())return!!this.getSelfOrAncestorWithClass(e.commonAncestorContainer);var t=e.getNodes([3]);if(t.length)for(var n,o=0;n=t[o++];)if(!this.isIgnorableWhiteSpaceNode(n)&&p(e,n)&&this.isModifiable(n)&&!this.getSelfOrAncestorWithClass(n))return!1;return!0},isAppliedToRanges:function(e){var t=e.length;if(0==t)return!1;for(;t--;)if(!this.isAppliedToRange(e[t]))return!1;return!0},isAppliedToSelection:function(t){var n=e.getSelection(t);return this.isAppliedToRanges(n.getAllRanges())},toggleRange:function(e){this.isAppliedToRange(e)?this.undoToRange(e):this.applyToRange(e)},toggleSelection:function(e){this.isAppliedToSelection(e)?this.undoToSelection(e):this.applyToSelection(e)},getElementsWithClassIntersectingRange:function(e){var t=[],n=this;return e.getNodes([3],function(e){var o=n.getSelfOrAncestorWithClass(e);o&&!H(t,o)&&t.push(o)}),t},detach:function(){}},D.util={hasClass:r,addClass:i,removeClass:W,hasSameClasses:c,replaceWithOwnChildren:g,elementsHaveSameNonClassAttributes:v,elementHasNonClassAttributes:R,splitNodeAt:O,isEditableElement:F,isEditingHost:C,isEditable:y},e.CssClassApplier=e.ClassApplier=D,e.createCssClassApplier=e.createClassApplier=P}),rangy.createModule("Highlighter",["ClassApplier"],function(e,t){function n(e,t){return e.characterRange.start-t.characterRange.start}function o(e,t){this.type=e,this.converterCreator=t}function r(e,t){g[e]=new o(e,t)}function i(e){var t=g[e];if(t instanceof o)return t.create();throw new Error("Highlighter type '"+e+"' is not valid")}function a(e,t){this.start=e,this.end=t}function s(e,t,n,o,r,i){r?(this.id=r,h=Math.max(h,r+1)):this.id=h++,this.characterRange=t,this.doc=e,this.classApplier=n,this.converter=o,this.containerElementId=i||null,this.applied=!1,this.xpathRange=null}function c(e,t){t=t||"textContent",this.doc=e||document,this.classAppliers={},this.highlights=[],this.converter=i(t)}var l=(log4javascript.getLogger("rangy.Highlighter"),e.dom),d=l.arrayContains,u=l.getBody,f=[].forEach?function(e,t){e.forEach(t)}:function(e,t){for(var n=0,o=e.length;o>n;++n)t(e[n])},h=1,g={};o.prototype.create=function(){var e=this.converterCreator();return e.type=this.type,e},e.registerHighlighterType=r,a.prototype={intersects:function(e){return this.start<e.end&&this.end>e.start},union:function(e){return new a(Math.min(this.start,e.start),Math.max(this.end,e.end))},intersection:function(e){return new a(Math.max(this.start,e.start),Math.min(this.end,e.end))},toString:function(){return"[CharacterRange("+this.start+", "+this.end+")]"}},a.fromCharacterRange=function(e){return new a(e.start,e.end)};var p={rangeToCharacterRange:function(e,t){var n=e.getBookmark(t);return new a(n.start,n.end)},characterRangeToRange:function(t,n,o){var r=e.createRange(t);return r.moveToBookmark({start:n.start,end:n.end,containerNode:o}),r},serializeSelection:function(e,t){for(var n=e.getAllRanges(),o=n.length,r=[],i=1==o&&e.isBackward(),a=0,s=n.length;s>a;++a)r[a]={characterRange:this.rangeToCharacterRange(n[a],t),backward:i};return r},restoreSelection:function(e,t,n){e.removeAllRanges();for(var o,r,i,a=e.win.document,s=0,c=t.length;c>s;++s)r=t[s],i=r.characterRange,o=this.characterRangeToRange(a,r.characterRange,n),e.addRange(o,r.backward)}};r("textContent",function(){return p}),r("TextRange",function(){var t;return function(){if(!t){var n=e.modules.TextRange;if(!n)throw new Error("TextRange module is missing.");if(!n.supported)throw new Error("TextRange module is present but not supported.");t={rangeToCharacterRange:function(e,t){return a.fromCharacterRange(e.toCharacterRange(t))},characterRangeToRange:function(t,n,o){var r=e.createRange(t);return r.selectCharacters(o,n.start,n.end),r},serializeSelection:function(e,t){return e.saveCharacterRanges(t)},restoreSelection:function(e,t,n){e.restoreCharacterRanges(n,t)}}}return t}}()),s.prototype={getContainerElement:function(){return this.containerElementId?this.doc.getElementById(this.containerElementId):u(this.doc)},getRange:function(){return this.converter.characterRangeToRange(this.doc,this.characterRange,this.getContainerElement())},fromRange:function(e){this.characterRange=this.converter.rangeToCharacterRange(e,this.getContainerElement())},getText:function(){return this.getRange().toString()},containsElement:function(e){return this.getRange().containsNodeContents(e.firstChild)},unapply:function(){this.classApplier.undoToRange(this.getRange()),this.applied=!1},apply:function(){this.classApplier.applyToRange(this.getRange()),this.applied=!0},getHighlightElements:function(){return this.classApplier.getElementsWithClassIntersectingRange(this.getRange())},toString:function(){return"[Highlight(ID: "+this.id+", class: "+this.classApplier.cssClass+", character range: "+this.characterRange.start+" - "+this.characterRange.end+")]"}},c.prototype={addClassApplier:function(e){this.classAppliers[e.cssClass]=e},getHighlightForElement:function(e){for(var t=this.highlights,n=0,o=t.length;o>n;++n)if(t[n].containsElement(e))return t[n];return null},removeHighlights:function(e){for(var t,n=0,o=this.highlights.length;o>n;++n)t=this.highlights[n],d(e,t)&&(t.unapply(),this.highlights.splice(n--,1))},removeAllHighlights:function(){this.removeHighlights(this.highlights)},getIntersectingHighlights:function(e){var t=[],n=this.highlights;this.converter;return f(e,function(e){f(n,function(n){e.intersectsRange(n.getRange())&&!d(t,n)&&t.push(n)})}),t},highlightCharacterRanges:function(t,n,o){var r,i,c,l=this.highlights,d=this.converter,u=this.doc,h=[],g=this.classAppliers[t];o=o||null;var p,m,v;o&&(p=this.doc.getElementById(o),p&&(m=e.createRange(this.doc),m.selectNodeContents(p),v=new a(0,m.toString().length)));var R,N,C;for(r=0,i=n.length;i>r;++r){for(R=n[r],C=!1,v&&(R=R.intersection(v)),c=0;c<l.length;++c)o==l[c].containerElementId&&(N=l[c].characterRange,N.intersects(R)&&(h.push(l[c]),l[c]=new s(u,N.union(R),g,d,null,o)));C||l.push(new s(u,R,g,d,null,o))}f(h,function(e){e.unapply()});var y=[];return f(l,function(e){e.applied||(e.apply(),y.push(e))}),y},highlightRanges:function(t,n,o){var r,i=[],a=this.converter,s=o?o.id:null;return o&&(r=e.createRange(o),r.selectNodeContents(o)),f(n,function(e){var t=o?r.intersection(e):e;i.push(a.rangeToCharacterRange(t,o||u(e.getDocument())))}),this.highlightCharacterRanges(i,n,s)},highlightSelection:function(t,n,o){var r=this.converter;n=n||e.getSelection();var i=this.classAppliers[t],s=n.win.document,c=o?s.getElementById(o):u(s);if(!i)throw new Error("No class applier found for class '"+t+"'");var l=r.serializeSelection(n,c),d=[];f(l,function(e){d.push(a.fromCharacterRange(e.characterRange))});var h=this.highlightCharacterRanges(t,d,o);return r.restoreSelection(n,l,c),h},unhighlightSelection:function(t){t=t||e.getSelection();var n=this.getIntersectingHighlights(t.getAllRanges());return this.removeHighlights(n),t.removeAllRanges(),n},getHighlightsInSelection:function(t){return t=t||e.getSelection(),this.getIntersectingHighlights(t.getAllRanges())},selectionOverlapsHighlight:function(e){return this.getHighlightsInSelection(e).length>0},serialize:function(e){var t=this.highlights;t.sort(n);var o=["type:"+this.converter.type];return f(t,function(t){var n=t.characterRange,r=[n.start,n.end,t.id,t.classApplier.cssClass,t.containerElementId];e&&e.serializeHighlightText&&r.push(t.getText()),o.push(r.join("$"))}),o.join("|")},deserialize:function(e){var t,n,o,r=e.split("|"),c=[],l=r[0],d=!1;if(!l||!(t=/^type:(\w+)$/.exec(l)))throw new Error("Serialized highlights are invalid.");n=t[1],n!=this.converter.type&&(o=i(n),d=!0),r.shift();for(var f,h,g,p,m,v,R=r.length;R-- >0;){if(v=r[R].split("$"),g=new a(+v[0],+v[1]),p=v[4]||null,m=p?this.doc.getElementById(p):u(this.doc),d&&(g=this.converter.rangeToCharacterRange(o.characterRangeToRange(this.doc,g,m),m)),f=this.classAppliers[v[3]],!f)throw new Error("No class applier found for class '"+v[3]+"'");h=new s(this.doc,g,f,this.converter,parseInt(v[2]),p),h.apply(),c.push(h)}this.highlights=c}},e.Highlighter=c,e.createHighlighter=function(e,t){return new c(e,t)}});var highlighter,savedSerializedHighlight="";
  //Uncomment this line if using import statement
  import RSVP from 'rsvp';
  (function(root, factory) {
    if (typeof define === 'function' && define.amd) {
      // AMD
      define([], factory);
    } else if (typeof exports === 'object') {
      // Node, CommonJS-like
      module.exports = factory();
    } else {
      // Browser globals
      root.ePubWrapper = factory();
      (function(){"use strict";function lib$rsvp$utils$$objectOrFunction(x){return typeof x==="function"||typeof x==="object"&&x!==null}function lib$rsvp$utils$$isFunction(x){return typeof x==="function"}function lib$rsvp$utils$$isMaybeThenable(x){return typeof x==="object"&&x!==null}var lib$rsvp$utils$$_isArray;if(!Array.isArray){lib$rsvp$utils$$_isArray=function(x){return Object.prototype.toString.call(x)==="[object Array]"}}else{lib$rsvp$utils$$_isArray=Array.isArray}var lib$rsvp$utils$$isArray=lib$rsvp$utils$$_isArray;var lib$rsvp$utils$$now=Date.now||function(){return(new Date).getTime()};function lib$rsvp$utils$$F(){}var lib$rsvp$utils$$o_create=Object.create||function(o){if(arguments.length>1){throw new Error("Second argument not supported")}if(typeof o!=="object"){throw new TypeError("Argument must be an object")}lib$rsvp$utils$$F.prototype=o;return new lib$rsvp$utils$$F};function lib$rsvp$events$$indexOf(callbacks,callback){for(var i=0,l=callbacks.length;i<l;i++){if(callbacks[i]===callback){return i}}return-1}function lib$rsvp$events$$callbacksFor(object){var callbacks=object._promiseCallbacks;if(!callbacks){callbacks=object._promiseCallbacks={}}return callbacks}var lib$rsvp$events$$default={mixin:function(object){object["on"]=this["on"];object["off"]=this["off"];object["trigger"]=this["trigger"];object._promiseCallbacks=undefined;return object},on:function(eventName,callback){if(typeof callback!=="function"){throw new TypeError("Callback must be a function")}var allCallbacks=lib$rsvp$events$$callbacksFor(this),callbacks;callbacks=allCallbacks[eventName];if(!callbacks){callbacks=allCallbacks[eventName]=[]}if(lib$rsvp$events$$indexOf(callbacks,callback)===-1){callbacks.push(callback)}},off:function(eventName,callback){var allCallbacks=lib$rsvp$events$$callbacksFor(this),callbacks,index;if(!callback){allCallbacks[eventName]=[];return}callbacks=allCallbacks[eventName];index=lib$rsvp$events$$indexOf(callbacks,callback);if(index!==-1){callbacks.splice(index,1)}},trigger:function(eventName,options,label){var allCallbacks=lib$rsvp$events$$callbacksFor(this),callbacks,callback;if(callbacks=allCallbacks[eventName]){for(var i=0;i<callbacks.length;i++){callback=callbacks[i];callback(options,label)}}}};var lib$rsvp$config$$config={instrument:false};lib$rsvp$events$$default["mixin"](lib$rsvp$config$$config);function lib$rsvp$config$$configure(name,value){if(name==="onerror"){lib$rsvp$config$$config["on"]("error",value);return}if(arguments.length===2){lib$rsvp$config$$config[name]=value}else{return lib$rsvp$config$$config[name]}}var lib$rsvp$instrument$$queue=[];function lib$rsvp$instrument$$scheduleFlush(){setTimeout(function(){var entry;for(var i=0;i<lib$rsvp$instrument$$queue.length;i++){entry=lib$rsvp$instrument$$queue[i];var payload=entry.payload;payload.guid=payload.key+payload.id;payload.childGuid=payload.key+payload.childId;if(payload.error){payload.stack=payload.error.stack}lib$rsvp$config$$config["trigger"](entry.name,entry.payload)}lib$rsvp$instrument$$queue.length=0},50)}function lib$rsvp$instrument$$instrument(eventName,promise,child){if(1===lib$rsvp$instrument$$queue.push({name:eventName,payload:{key:promise._guidKey,id:promise._id,eventName:eventName,detail:promise._result,childId:child&&child._id,label:promise._label,timeStamp:lib$rsvp$utils$$now(),error:lib$rsvp$config$$config["instrument-with-stack"]?new Error(promise._label):null}})){lib$rsvp$instrument$$scheduleFlush()}}var lib$rsvp$instrument$$default=lib$rsvp$instrument$$instrument;function lib$rsvp$$internal$$withOwnPromise(){return new TypeError("A promises callback cannot return that same promise.")}function lib$rsvp$$internal$$noop(){}var lib$rsvp$$internal$$PENDING=void 0;var lib$rsvp$$internal$$FULFILLED=1;var lib$rsvp$$internal$$REJECTED=2;var lib$rsvp$$internal$$GET_THEN_ERROR=new lib$rsvp$$internal$$ErrorObject;function lib$rsvp$$internal$$getThen(promise){try{return promise.then}catch(error){lib$rsvp$$internal$$GET_THEN_ERROR.error=error;return lib$rsvp$$internal$$GET_THEN_ERROR}}function lib$rsvp$$internal$$tryThen(then,value,fulfillmentHandler,rejectionHandler){try{then.call(value,fulfillmentHandler,rejectionHandler)}catch(e){return e}}function lib$rsvp$$internal$$handleForeignThenable(promise,thenable,then){lib$rsvp$config$$config.async(function(promise){var sealed=false;var error=lib$rsvp$$internal$$tryThen(then,thenable,function(value){if(sealed){return}sealed=true;if(thenable!==value){lib$rsvp$$internal$$resolve(promise,value)}else{lib$rsvp$$internal$$fulfill(promise,value)}},function(reason){if(sealed){return}sealed=true;lib$rsvp$$internal$$reject(promise,reason)},"Settle: "+(promise._label||" unknown promise"));if(!sealed&&error){sealed=true;lib$rsvp$$internal$$reject(promise,error)}},promise)}function lib$rsvp$$internal$$handleOwnThenable(promise,thenable){if(thenable._state===lib$rsvp$$internal$$FULFILLED){lib$rsvp$$internal$$fulfill(promise,thenable._result)}else if(thenable._state===lib$rsvp$$internal$$REJECTED){thenable._onError=null;lib$rsvp$$internal$$reject(promise,thenable._result)}else{lib$rsvp$$internal$$subscribe(thenable,undefined,function(value){if(thenable!==value){lib$rsvp$$internal$$resolve(promise,value)}else{lib$rsvp$$internal$$fulfill(promise,value)}},function(reason){lib$rsvp$$internal$$reject(promise,reason)})}}function lib$rsvp$$internal$$handleMaybeThenable(promise,maybeThenable){if(maybeThenable.constructor===promise.constructor){lib$rsvp$$internal$$handleOwnThenable(promise,maybeThenable)}else{var then=lib$rsvp$$internal$$getThen(maybeThenable);if(then===lib$rsvp$$internal$$GET_THEN_ERROR){lib$rsvp$$internal$$reject(promise,lib$rsvp$$internal$$GET_THEN_ERROR.error)}else if(then===undefined){lib$rsvp$$internal$$fulfill(promise,maybeThenable)}else if(lib$rsvp$utils$$isFunction(then)){lib$rsvp$$internal$$handleForeignThenable(promise,maybeThenable,then)}else{lib$rsvp$$internal$$fulfill(promise,maybeThenable)}}}function lib$rsvp$$internal$$resolve(promise,value){if(promise===value){lib$rsvp$$internal$$fulfill(promise,value)}else if(lib$rsvp$utils$$objectOrFunction(value)){lib$rsvp$$internal$$handleMaybeThenable(promise,value)}else{lib$rsvp$$internal$$fulfill(promise,value)}}function lib$rsvp$$internal$$publishRejection(promise){if(promise._onError){promise._onError(promise._result)}lib$rsvp$$internal$$publish(promise)}function lib$rsvp$$internal$$fulfill(promise,value){if(promise._state!==lib$rsvp$$internal$$PENDING){return}promise._result=value;promise._state=lib$rsvp$$internal$$FULFILLED;if(promise._subscribers.length===0){if(lib$rsvp$config$$config.instrument){lib$rsvp$instrument$$default("fulfilled",promise)}}else{lib$rsvp$config$$config.async(lib$rsvp$$internal$$publish,promise)}}function lib$rsvp$$internal$$reject(promise,reason){if(promise._state!==lib$rsvp$$internal$$PENDING){return}promise._state=lib$rsvp$$internal$$REJECTED;promise._result=reason;lib$rsvp$config$$config.async(lib$rsvp$$internal$$publishRejection,promise)}function lib$rsvp$$internal$$subscribe(parent,child,onFulfillment,onRejection){var subscribers=parent._subscribers;var length=subscribers.length;parent._onError=null;subscribers[length]=child;subscribers[length+lib$rsvp$$internal$$FULFILLED]=onFulfillment;subscribers[length+lib$rsvp$$internal$$REJECTED]=onRejection;if(length===0&&parent._state){lib$rsvp$config$$config.async(lib$rsvp$$internal$$publish,parent)}}function lib$rsvp$$internal$$publish(promise){var subscribers=promise._subscribers;var settled=promise._state;if(lib$rsvp$config$$config.instrument){lib$rsvp$instrument$$default(settled===lib$rsvp$$internal$$FULFILLED?"fulfilled":"rejected",promise)}if(subscribers.length===0){return}var child,callback,detail=promise._result;for(var i=0;i<subscribers.length;i+=3){child=subscribers[i];callback=subscribers[i+settled];if(child){lib$rsvp$$internal$$invokeCallback(settled,child,callback,detail)}else{callback(detail)}}promise._subscribers.length=0}function lib$rsvp$$internal$$ErrorObject(){this.error=null}var lib$rsvp$$internal$$TRY_CATCH_ERROR=new lib$rsvp$$internal$$ErrorObject;function lib$rsvp$$internal$$tryCatch(callback,detail){try{return callback(detail)}catch(e){lib$rsvp$$internal$$TRY_CATCH_ERROR.error=e;return lib$rsvp$$internal$$TRY_CATCH_ERROR}}function lib$rsvp$$internal$$invokeCallback(settled,promise,callback,detail){var hasCallback=lib$rsvp$utils$$isFunction(callback),value,error,succeeded,failed;if(hasCallback){value=lib$rsvp$$internal$$tryCatch(callback,detail);if(value===lib$rsvp$$internal$$TRY_CATCH_ERROR){failed=true;error=value.error;value=null}else{succeeded=true}if(promise===value){lib$rsvp$$internal$$reject(promise,lib$rsvp$$internal$$withOwnPromise());return}}else{value=detail;succeeded=true}if(promise._state!==lib$rsvp$$internal$$PENDING){}else if(hasCallback&&succeeded){lib$rsvp$$internal$$resolve(promise,value)}else if(failed){lib$rsvp$$internal$$reject(promise,error)}else if(settled===lib$rsvp$$internal$$FULFILLED){lib$rsvp$$internal$$fulfill(promise,value)}else if(settled===lib$rsvp$$internal$$REJECTED){lib$rsvp$$internal$$reject(promise,value)}}function lib$rsvp$$internal$$initializePromise(promise,resolver){var resolved=false;try{resolver(function resolvePromise(value){if(resolved){return}resolved=true;lib$rsvp$$internal$$resolve(promise,value)},function rejectPromise(reason){if(resolved){return}resolved=true;lib$rsvp$$internal$$reject(promise,reason)})}catch(e){lib$rsvp$$internal$$reject(promise,e)}}function lib$rsvp$enumerator$$makeSettledResult(state,position,value){if(state===lib$rsvp$$internal$$FULFILLED){return{state:"fulfilled",value:value}}else{return{state:"rejected",reason:value}}}function lib$rsvp$enumerator$$Enumerator(Constructor,input,abortOnReject,label){var enumerator=this;enumerator._instanceConstructor=Constructor;enumerator.promise=new Constructor(lib$rsvp$$internal$$noop,label);enumerator._abortOnReject=abortOnReject;if(enumerator._validateInput(input)){enumerator._input=input;enumerator.length=input.length;enumerator._remaining=input.length;enumerator._init();if(enumerator.length===0){lib$rsvp$$internal$$fulfill(enumerator.promise,enumerator._result)}else{enumerator.length=enumerator.length||0;enumerator._enumerate();if(enumerator._remaining===0){lib$rsvp$$internal$$fulfill(enumerator.promise,enumerator._result)}}}else{lib$rsvp$$internal$$reject(enumerator.promise,enumerator._validationError())}}var lib$rsvp$enumerator$$default=lib$rsvp$enumerator$$Enumerator;lib$rsvp$enumerator$$Enumerator.prototype._validateInput=function(input){return lib$rsvp$utils$$isArray(input)};lib$rsvp$enumerator$$Enumerator.prototype._validationError=function(){return new Error("Array Methods must be provided an Array")};lib$rsvp$enumerator$$Enumerator.prototype._init=function(){this._result=new Array(this.length)};lib$rsvp$enumerator$$Enumerator.prototype._enumerate=function(){var enumerator=this;var length=enumerator.length;var promise=enumerator.promise;var input=enumerator._input;for(var i=0;promise._state===lib$rsvp$$internal$$PENDING&&i<length;i++){enumerator._eachEntry(input[i],i)}};lib$rsvp$enumerator$$Enumerator.prototype._eachEntry=function(entry,i){var enumerator=this;var c=enumerator._instanceConstructor;if(lib$rsvp$utils$$isMaybeThenable(entry)){if(entry.constructor===c&&entry._state!==lib$rsvp$$internal$$PENDING){entry._onError=null;enumerator._settledAt(entry._state,i,entry._result)}else{enumerator._willSettleAt(c.resolve(entry),i)}}else{enumerator._remaining--;enumerator._result[i]=enumerator._makeResult(lib$rsvp$$internal$$FULFILLED,i,entry)}};lib$rsvp$enumerator$$Enumerator.prototype._settledAt=function(state,i,value){var enumerator=this;var promise=enumerator.promise;if(promise._state===lib$rsvp$$internal$$PENDING){enumerator._remaining--;if(enumerator._abortOnReject&&state===lib$rsvp$$internal$$REJECTED){lib$rsvp$$internal$$reject(promise,value)}else{enumerator._result[i]=enumerator._makeResult(state,i,value)}}if(enumerator._remaining===0){lib$rsvp$$internal$$fulfill(promise,enumerator._result)}};lib$rsvp$enumerator$$Enumerator.prototype._makeResult=function(state,i,value){return value};lib$rsvp$enumerator$$Enumerator.prototype._willSettleAt=function(promise,i){var enumerator=this;lib$rsvp$$internal$$subscribe(promise,undefined,function(value){enumerator._settledAt(lib$rsvp$$internal$$FULFILLED,i,value)},function(reason){enumerator._settledAt(lib$rsvp$$internal$$REJECTED,i,reason)})};function lib$rsvp$promise$all$$all(entries,label){return new lib$rsvp$enumerator$$default(this,entries,true,label).promise}var lib$rsvp$promise$all$$default=lib$rsvp$promise$all$$all;function lib$rsvp$promise$race$$race(entries,label){var Constructor=this;var promise=new Constructor(lib$rsvp$$internal$$noop,label);if(!lib$rsvp$utils$$isArray(entries)){lib$rsvp$$internal$$reject(promise,new TypeError("You must pass an array to race."));return promise}var length=entries.length;function onFulfillment(value){lib$rsvp$$internal$$resolve(promise,value)}function onRejection(reason){lib$rsvp$$internal$$reject(promise,reason)}for(var i=0;promise._state===lib$rsvp$$internal$$PENDING&&i<length;i++){lib$rsvp$$internal$$subscribe(Constructor.resolve(entries[i]),undefined,onFulfillment,onRejection)}return promise}var lib$rsvp$promise$race$$default=lib$rsvp$promise$race$$race;function lib$rsvp$promise$resolve$$resolve(object,label){var Constructor=this;if(object&&typeof object==="object"&&object.constructor===Constructor){return object}var promise=new Constructor(lib$rsvp$$internal$$noop,label);lib$rsvp$$internal$$resolve(promise,object);return promise}var lib$rsvp$promise$resolve$$default=lib$rsvp$promise$resolve$$resolve;function lib$rsvp$promise$reject$$reject(reason,label){var Constructor=this;var promise=new Constructor(lib$rsvp$$internal$$noop,label);lib$rsvp$$internal$$reject(promise,reason);return promise}var lib$rsvp$promise$reject$$default=lib$rsvp$promise$reject$$reject;var lib$rsvp$promise$$guidKey="rsvp_"+lib$rsvp$utils$$now()+"-";var lib$rsvp$promise$$counter=0;function lib$rsvp$promise$$needsResolver(){throw new TypeError("You must pass a resolver function as the first argument to the promise constructor")}function lib$rsvp$promise$$needsNew(){throw new TypeError("Failed to construct 'Promise': Please use the 'new' operator, this object constructor cannot be called as a function.")}function lib$rsvp$promise$$Promise(resolver,label){var promise=this;promise._id=lib$rsvp$promise$$counter++;promise._label=label;promise._state=undefined;promise._result=undefined;promise._subscribers=[];if(lib$rsvp$config$$config.instrument){lib$rsvp$instrument$$default("created",promise)}if(lib$rsvp$$internal$$noop!==resolver){if(!lib$rsvp$utils$$isFunction(resolver)){lib$rsvp$promise$$needsResolver()}if(!(promise instanceof lib$rsvp$promise$$Promise)){lib$rsvp$promise$$needsNew()}lib$rsvp$$internal$$initializePromise(promise,resolver)}}var lib$rsvp$promise$$default=lib$rsvp$promise$$Promise;lib$rsvp$promise$$Promise.cast=lib$rsvp$promise$resolve$$default;lib$rsvp$promise$$Promise.all=lib$rsvp$promise$all$$default;lib$rsvp$promise$$Promise.race=lib$rsvp$promise$race$$default;lib$rsvp$promise$$Promise.resolve=lib$rsvp$promise$resolve$$default;lib$rsvp$promise$$Promise.reject=lib$rsvp$promise$reject$$default;lib$rsvp$promise$$Promise.prototype={constructor:lib$rsvp$promise$$Promise,_guidKey:lib$rsvp$promise$$guidKey,_onError:function(reason){var promise=this;lib$rsvp$config$$config.after(function(){if(promise._onError){lib$rsvp$config$$config["trigger"]("error",reason,promise._label)}})},then:function(onFulfillment,onRejection,label){var parent=this;var state=parent._state;if(state===lib$rsvp$$internal$$FULFILLED&&!onFulfillment||state===lib$rsvp$$internal$$REJECTED&&!onRejection){if(lib$rsvp$config$$config.instrument){lib$rsvp$instrument$$default("chained",parent,parent)}return parent}parent._onError=null;var child=new parent.constructor(lib$rsvp$$internal$$noop,label);var result=parent._result;if(lib$rsvp$config$$config.instrument){lib$rsvp$instrument$$default("chained",parent,child)}if(state){var callback=arguments[state-1];lib$rsvp$config$$config.async(function(){lib$rsvp$$internal$$invokeCallback(state,child,callback,result)})}else{lib$rsvp$$internal$$subscribe(parent,child,onFulfillment,onRejection)}return child},"catch":function(onRejection,label){return this.then(undefined,onRejection,label)},"finally":function(callback,label){var promise=this;var constructor=promise.constructor;return promise.then(function(value){return constructor.resolve(callback()).then(function(){return value})},function(reason){return constructor.resolve(callback()).then(function(){throw reason})},label)}};function lib$rsvp$all$settled$$AllSettled(Constructor,entries,label){this._superConstructor(Constructor,entries,false,label)}lib$rsvp$all$settled$$AllSettled.prototype=lib$rsvp$utils$$o_create(lib$rsvp$enumerator$$default.prototype);lib$rsvp$all$settled$$AllSettled.prototype._superConstructor=lib$rsvp$enumerator$$default;lib$rsvp$all$settled$$AllSettled.prototype._makeResult=lib$rsvp$enumerator$$makeSettledResult;lib$rsvp$all$settled$$AllSettled.prototype._validationError=function(){return new Error("allSettled must be called with an array")};function lib$rsvp$all$settled$$allSettled(entries,label){return new lib$rsvp$all$settled$$AllSettled(lib$rsvp$promise$$default,entries,label).promise}var lib$rsvp$all$settled$$default=lib$rsvp$all$settled$$allSettled;function lib$rsvp$all$$all(array,label){return lib$rsvp$promise$$default.all(array,label)}var lib$rsvp$all$$default=lib$rsvp$all$$all;var lib$rsvp$asap$$len=0;var lib$rsvp$asap$$toString={}.toString;var lib$rsvp$asap$$vertxNext;function lib$rsvp$asap$$asap(callback,arg){lib$rsvp$asap$$queue[lib$rsvp$asap$$len]=callback;lib$rsvp$asap$$queue[lib$rsvp$asap$$len+1]=arg;lib$rsvp$asap$$len+=2;if(lib$rsvp$asap$$len===2){lib$rsvp$asap$$scheduleFlush()}}var lib$rsvp$asap$$default=lib$rsvp$asap$$asap;var lib$rsvp$asap$$browserWindow=typeof window!=="undefined"?window:undefined;var lib$rsvp$asap$$browserGlobal=lib$rsvp$asap$$browserWindow||{};var lib$rsvp$asap$$BrowserMutationObserver=lib$rsvp$asap$$browserGlobal.MutationObserver||lib$rsvp$asap$$browserGlobal.WebKitMutationObserver;var lib$rsvp$asap$$isNode=typeof self==="undefined"&&typeof process!=="undefined"&&{}.toString.call(process)==="[object process]";var lib$rsvp$asap$$isWorker=typeof Uint8ClampedArray!=="undefined"&&typeof importScripts!=="undefined"&&typeof MessageChannel!=="undefined";function lib$rsvp$asap$$useNextTick(){var nextTick=process.nextTick;var version=process.versions.node.match(/^(?:(\d+)\.)?(?:(\d+)\.)?(\*|\d+)$/);if(Array.isArray(version)&&version[1]==="0"&&version[2]==="10"){nextTick=setImmediate}return function(){nextTick(lib$rsvp$asap$$flush)}}function lib$rsvp$asap$$useVertxTimer(){return function(){lib$rsvp$asap$$vertxNext(lib$rsvp$asap$$flush)}}function lib$rsvp$asap$$useMutationObserver(){var iterations=0;var observer=new lib$rsvp$asap$$BrowserMutationObserver(lib$rsvp$asap$$flush);var node=document.createTextNode("");observer.observe(node,{characterData:true});return function(){node.data=iterations=++iterations%2}}function lib$rsvp$asap$$useMessageChannel(){var channel=new MessageChannel;channel.port1.onmessage=lib$rsvp$asap$$flush;return function(){channel.port2.postMessage(0)}}function lib$rsvp$asap$$useSetTimeout(){return function(){setTimeout(lib$rsvp$asap$$flush,1)}}var lib$rsvp$asap$$queue=new Array(1e3);function lib$rsvp$asap$$flush(){for(var i=0;i<lib$rsvp$asap$$len;i+=2){var callback=lib$rsvp$asap$$queue[i];var arg=lib$rsvp$asap$$queue[i+1];callback(arg);lib$rsvp$asap$$queue[i]=undefined;lib$rsvp$asap$$queue[i+1]=undefined}lib$rsvp$asap$$len=0}function lib$rsvp$asap$$attemptVertex(){try{var r=require;var vertx=r("vertx");lib$rsvp$asap$$vertxNext=vertx.runOnLoop||vertx.runOnContext;return lib$rsvp$asap$$useVertxTimer()}catch(e){return lib$rsvp$asap$$useSetTimeout()}}var lib$rsvp$asap$$scheduleFlush;if(lib$rsvp$asap$$isNode){lib$rsvp$asap$$scheduleFlush=lib$rsvp$asap$$useNextTick()}else if(lib$rsvp$asap$$BrowserMutationObserver){lib$rsvp$asap$$scheduleFlush=lib$rsvp$asap$$useMutationObserver()}else if(lib$rsvp$asap$$isWorker){lib$rsvp$asap$$scheduleFlush=lib$rsvp$asap$$useMessageChannel()}else if(lib$rsvp$asap$$browserWindow===undefined&&typeof require==="function"){lib$rsvp$asap$$scheduleFlush=lib$rsvp$asap$$attemptVertex()}else{lib$rsvp$asap$$scheduleFlush=lib$rsvp$asap$$useSetTimeout()}function lib$rsvp$defer$$defer(label){var deferred={};deferred["promise"]=new lib$rsvp$promise$$default(function(resolve,reject){deferred["resolve"]=resolve;deferred["reject"]=reject},label);return deferred}var lib$rsvp$defer$$default=lib$rsvp$defer$$defer;function lib$rsvp$filter$$filter(promises,filterFn,label){return lib$rsvp$promise$$default.all(promises,label).then(function(values){if(!lib$rsvp$utils$$isFunction(filterFn)){throw new TypeError("You must pass a function as filter's second argument.")}var length=values.length;var filtered=new Array(length);for(var i=0;i<length;i++){filtered[i]=filterFn(values[i])}return lib$rsvp$promise$$default.all(filtered,label).then(function(filtered){var results=new Array(length);var newLength=0;for(var i=0;i<length;i++){if(filtered[i]){results[newLength]=values[i];newLength++}}results.length=newLength;return results})})}var lib$rsvp$filter$$default=lib$rsvp$filter$$filter;function lib$rsvp$promise$hash$$PromiseHash(Constructor,object,label){this._superConstructor(Constructor,object,true,label)}var lib$rsvp$promise$hash$$default=lib$rsvp$promise$hash$$PromiseHash;lib$rsvp$promise$hash$$PromiseHash.prototype=lib$rsvp$utils$$o_create(lib$rsvp$enumerator$$default.prototype);lib$rsvp$promise$hash$$PromiseHash.prototype._superConstructor=lib$rsvp$enumerator$$default;lib$rsvp$promise$hash$$PromiseHash.prototype._init=function(){this._result={}};lib$rsvp$promise$hash$$PromiseHash.prototype._validateInput=function(input){return input&&typeof input==="object"};lib$rsvp$promise$hash$$PromiseHash.prototype._validationError=function(){return new Error("Promise.hash must be called with an object")};lib$rsvp$promise$hash$$PromiseHash.prototype._enumerate=function(){var enumerator=this;var promise=enumerator.promise;var input=enumerator._input;var results=[];for(var key in input){if(promise._state===lib$rsvp$$internal$$PENDING&&Object.prototype.hasOwnProperty.call(input,key)){results.push({position:key,entry:input[key]})}}var length=results.length;enumerator._remaining=length;var result;for(var i=0;promise._state===lib$rsvp$$internal$$PENDING&&i<length;i++){result=results[i];enumerator._eachEntry(result.entry,result.position)}};function lib$rsvp$hash$settled$$HashSettled(Constructor,object,label){this._superConstructor(Constructor,object,false,label)}lib$rsvp$hash$settled$$HashSettled.prototype=lib$rsvp$utils$$o_create(lib$rsvp$promise$hash$$default.prototype);lib$rsvp$hash$settled$$HashSettled.prototype._superConstructor=lib$rsvp$enumerator$$default;lib$rsvp$hash$settled$$HashSettled.prototype._makeResult=lib$rsvp$enumerator$$makeSettledResult;lib$rsvp$hash$settled$$HashSettled.prototype._validationError=function(){return new Error("hashSettled must be called with an object")};function lib$rsvp$hash$settled$$hashSettled(object,label){return new lib$rsvp$hash$settled$$HashSettled(lib$rsvp$promise$$default,object,label).promise}var lib$rsvp$hash$settled$$default=lib$rsvp$hash$settled$$hashSettled;function lib$rsvp$hash$$hash(object,label){return new lib$rsvp$promise$hash$$default(lib$rsvp$promise$$default,object,label).promise}var lib$rsvp$hash$$default=lib$rsvp$hash$$hash;function lib$rsvp$map$$map(promises,mapFn,label){return lib$rsvp$promise$$default.all(promises,label).then(function(values){if(!lib$rsvp$utils$$isFunction(mapFn)){throw new TypeError("You must pass a function as map's second argument.")}var length=values.length;var results=new Array(length);for(var i=0;i<length;i++){results[i]=mapFn(values[i])}return lib$rsvp$promise$$default.all(results,label)})}var lib$rsvp$map$$default=lib$rsvp$map$$map;function lib$rsvp$node$$Result(){this.value=undefined}var lib$rsvp$node$$ERROR=new lib$rsvp$node$$Result;var lib$rsvp$node$$GET_THEN_ERROR=new lib$rsvp$node$$Result;function lib$rsvp$node$$getThen(obj){try{return obj.then}catch(error){lib$rsvp$node$$ERROR.value=error;return lib$rsvp$node$$ERROR}}function lib$rsvp$node$$tryApply(f,s,a){try{f.apply(s,a)}catch(error){lib$rsvp$node$$ERROR.value=error;return lib$rsvp$node$$ERROR}}function lib$rsvp$node$$makeObject(_,argumentNames){var obj={};var name;var i;var length=_.length;var args=new Array(length);for(var x=0;x<length;x++){args[x]=_[x]}for(i=0;i<argumentNames.length;i++){name=argumentNames[i];obj[name]=args[i+1]}return obj}function lib$rsvp$node$$arrayResult(_){var length=_.length;var args=new Array(length-1);for(var i=1;i<length;i++){args[i-1]=_[i]}return args}function lib$rsvp$node$$wrapThenable(then,promise){return{then:function(onFulFillment,onRejection){return then.call(promise,onFulFillment,onRejection)}}}function lib$rsvp$node$$denodeify(nodeFunc,options){var fn=function(){var self=this;var l=arguments.length;var args=new Array(l+1);var arg;var promiseInput=false;for(var i=0;i<l;++i){arg=arguments[i];if(!promiseInput){promiseInput=lib$rsvp$node$$needsPromiseInput(arg);if(promiseInput===lib$rsvp$node$$GET_THEN_ERROR){var p=new lib$rsvp$promise$$default(lib$rsvp$$internal$$noop);lib$rsvp$$internal$$reject(p,lib$rsvp$node$$GET_THEN_ERROR.value);return p}else if(promiseInput&&promiseInput!==true){arg=lib$rsvp$node$$wrapThenable(promiseInput,arg)}}args[i]=arg}var promise=new lib$rsvp$promise$$default(lib$rsvp$$internal$$noop);args[l]=function(err,val){if(err)lib$rsvp$$internal$$reject(promise,err);else if(options===undefined)lib$rsvp$$internal$$resolve(promise,val);else if(options===true)lib$rsvp$$internal$$resolve(promise,lib$rsvp$node$$arrayResult(arguments));else if(lib$rsvp$utils$$isArray(options))lib$rsvp$$internal$$resolve(promise,lib$rsvp$node$$makeObject(arguments,options));else lib$rsvp$$internal$$resolve(promise,val)};if(promiseInput){return lib$rsvp$node$$handlePromiseInput(promise,args,nodeFunc,self)}else{return lib$rsvp$node$$handleValueInput(promise,args,nodeFunc,self)}};fn.__proto__=nodeFunc;return fn}var lib$rsvp$node$$default=lib$rsvp$node$$denodeify;function lib$rsvp$node$$handleValueInput(promise,args,nodeFunc,self){var result=lib$rsvp$node$$tryApply(nodeFunc,self,args);if(result===lib$rsvp$node$$ERROR){lib$rsvp$$internal$$reject(promise,result.value)}return promise}function lib$rsvp$node$$handlePromiseInput(promise,args,nodeFunc,self){return lib$rsvp$promise$$default.all(args).then(function(args){var result=lib$rsvp$node$$tryApply(nodeFunc,self,args);if(result===lib$rsvp$node$$ERROR){lib$rsvp$$internal$$reject(promise,result.value)}return promise})}function lib$rsvp$node$$needsPromiseInput(arg){if(arg&&typeof arg==="object"){if(arg.constructor===lib$rsvp$promise$$default){return true}else{return lib$rsvp$node$$getThen(arg)}}else{return false}}var lib$rsvp$platform$$platform;if(typeof self==="object"){lib$rsvp$platform$$platform=self}else if(typeof global==="object"){lib$rsvp$platform$$platform=global}else{throw new Error("no global: `self` or `global` found")}var lib$rsvp$platform$$default=lib$rsvp$platform$$platform;function lib$rsvp$race$$race(array,label){return lib$rsvp$promise$$default.race(array,label)}var lib$rsvp$race$$default=lib$rsvp$race$$race;function lib$rsvp$reject$$reject(reason,label){return lib$rsvp$promise$$default.reject(reason,label)}var lib$rsvp$reject$$default=lib$rsvp$reject$$reject;function lib$rsvp$resolve$$resolve(value,label){return lib$rsvp$promise$$default.resolve(value,label)}var lib$rsvp$resolve$$default=lib$rsvp$resolve$$resolve;function lib$rsvp$rethrow$$rethrow(reason){setTimeout(function(){throw reason});throw reason}var lib$rsvp$rethrow$$default=lib$rsvp$rethrow$$rethrow;lib$rsvp$config$$config.async=lib$rsvp$asap$$default;lib$rsvp$config$$config.after=function(cb){setTimeout(cb,0)};var lib$rsvp$$cast=lib$rsvp$resolve$$default;function lib$rsvp$$async(callback,arg){lib$rsvp$config$$config.async(callback,arg)}function lib$rsvp$$on(){lib$rsvp$config$$config["on"].apply(lib$rsvp$config$$config,arguments)}function lib$rsvp$$off(){lib$rsvp$config$$config["off"].apply(lib$rsvp$config$$config,arguments)}if(typeof window!=="undefined"&&typeof window["__PROMISE_INSTRUMENTATION__"]==="object"){var lib$rsvp$$callbacks=window["__PROMISE_INSTRUMENTATION__"];lib$rsvp$config$$configure("instrument",true);for(var lib$rsvp$$eventName in lib$rsvp$$callbacks){if(lib$rsvp$$callbacks.hasOwnProperty(lib$rsvp$$eventName)){lib$rsvp$$on(lib$rsvp$$eventName,lib$rsvp$$callbacks[lib$rsvp$$eventName])}}}var lib$rsvp$umd$$RSVP={race:lib$rsvp$race$$default,Promise:lib$rsvp$promise$$default,allSettled:lib$rsvp$all$settled$$default,hash:lib$rsvp$hash$$default,hashSettled:lib$rsvp$hash$settled$$default,denodeify:lib$rsvp$node$$default,on:lib$rsvp$$on,off:lib$rsvp$$off,map:lib$rsvp$map$$default,filter:lib$rsvp$filter$$default,resolve:lib$rsvp$resolve$$default,reject:lib$rsvp$reject$$default,all:lib$rsvp$all$$default,rethrow:lib$rsvp$rethrow$$default,defer:lib$rsvp$defer$$default,EventTarget:lib$rsvp$events$$default,configure:lib$rsvp$config$$configure,async:lib$rsvp$$async};if(typeof define==="function"&&define["amd"]){define(function(){return lib$rsvp$umd$$RSVP})}else if(typeof module!=="undefined"&&module["exports"]){module["exports"]=lib$rsvp$umd$$RSVP}else if(typeof lib$rsvp$platform$$default!=="undefined"){lib$rsvp$platform$$default["RSVP"]=lib$rsvp$umd$$RSVP}}).call(this);

    }
  }(this, function() {
    function ePubWrapper(ePubConfig) {

      var _this = this;
      // The event map object that stores registered events.
      _this.eventMap = [];

      // Spine lookup table
      _this.spineLookup = null;

      // Tracks current book settings
      _this.currentBookSettings = {
        currentPage: 1,
        currentSpineRecord: {},
        totalPages:0
      }
      var ePubHelper = new ePubHelper();
      var ePubRequest = new ePubRequest();
      var ePubConstants = new ePubConstants();
      /*
      This class contins the global constants that the ePub wrapper will use.
      */
      function ePubConstants() {
        var _this = this;
        // Highlight related constants.
        _this.loadHighlightPrefix = 'type:textContent|';


        _this.dataTypes = {
          initializeBook: "initializeBook",
          pageContent: "pageContent",
          event: "event"
        }
        _this.eventTypes = {
          pageLoaded: "pageLoaded",
          styleAdded: "styleAdded",
          styleRemoved: "styleRemoved",
          requestError: "error",
          linkClicked: "linkClicked",
          textSelected: "textSelected",
          highlightClicked:"highlightClicked"
        }
      }
      /*
      This class contains helper methods for the ePub wrapper to
      function effectively.
      */
      function ePubHelper() {
        var _this = this;
        // This method is a polyfill for the object merge.
        _this.mergeObjectPolyfill = function() {
          if (!Object.assign) {
            Object.defineProperty(Object, 'assign', {
              enumerable: false,
              configurable: true,
              writable: true,
              value: function(target) {
                'use strict';
                if (target === undefined || target === null) {
                  throw new TypeError('Cannot convert first argument to object');
                }
                var to = Object(target);
                for (var i = 1; i < arguments.length; i++) {
                  var nextSource = arguments[i];
                  if (nextSource === undefined || nextSource === null) {
                    continue;
                  }
                  nextSource = Object(nextSource);

                  var keysArray = Object.keys(nextSource);
                  for (var nextIndex = 0, len = keysArray.length; nextIndex < len; nextIndex++) {
                    var nextKey = keysArray[nextIndex];
                    var desc = Object.getOwnPropertyDescriptor(nextSource, nextKey);
                    if (desc !== undefined && desc.enumerable) {
                      to[nextKey] = nextSource[nextKey];
                    }
                  }
                }
                return to;
              }
            });
          }
        }

        // Checks if the parameter passed is a function
        _this.isFunction = function(func) {
          if (typeof func === "function") {
            return true;
          }
          return false;
        }
        // Checks whether an object is null,undefined or empty.
        _this.isNullOrUndefined = function(obj) {
          if (obj === null || obj === undefined) {
            return true;
          }
          return false;
        }
        // Checks whether an object is null,undefined or empty.
        _this.isObjectEmpty = function(obj) {
          if (Object.keys(obj).length === 0) {
            return true;
          }
          return false;
        }
        // Generates a UUID based on the current date and time.
        _this.generateUUID = function() {
          var d = new Date().getTime();
          var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            var r = (d + Math.random() * 16) % 16 | 0;
            d = Math.floor(d / 16);
            return (c == 'x' ? r : (r & 0x7 | 0x8)).toString(16);
          });
          return uuid;
        };
        // Checks whether the input parameter is an element or not.
        _this.isElement = function(obj) {
          return !!(obj && obj.nodeType == 1);
        };
        // Checks whether the input parameter provided is number.
        _this.isNumber = function(n) {
          return !isNaN(parseFloat(n)) && isFinite(n);
        };
        // Checks whether the input parameter provided is string.
        _this.isString = function(str) {
          return (typeof str === 'string' || str instanceof String);
        };
        // Gets an element based on ID
        _this.getElement = function(elem) {
          return document.getElementById(elem);
        };
        /*
        This method adjusts the page numbers/percentage to maximum bounds if
        the request aims to exceed beyond possible limits
        */
        _this.adjustPageBounds = function(spineCount, number, isPercent) {
          number = parseInt(number);
          var totalPossiblePages = spineCount;
          var adjustedPageNumber;
          if (number > totalPossiblePages) {
            if (isPercent) {
              adjustedPageNumber = 100;
            }
            else {
              adjustedPageNumber = totalPossiblePages;
            }
          }
          else if (number <= 0) {
            adjustedPageNumber = 1;
          }
          else {
            adjustedPageNumber = number;
          }
          return adjustedPageNumber;
        }
        /*
        This method gets the various parameters like protocol,host,origin
        etc based on the url passed to it.
        */
        _this.getURI = function(url) {
          var uri = {
            protocol : '',
            host : '',
            path : '',
            origin : '',
            directory : '',
            base : '',
            filename : '',
            extension : '',
            fragment : '',
            href : url
          },
          blob = url.indexOf('blob:'),
          doubleSlash = url.indexOf('://'),
          search = url.indexOf('?'),
          fragment = url.indexOf("#"),
          withoutProtocol,
          dot,
          firstSlash;
          if(blob === 0) {
            uri.protocol = "blob";
            uri.base = url.indexOf(0, fragment);
            return uri;
          }
          if(fragment != -1) {
            uri.fragment = url.slice(fragment + 1);
            url = url.slice(0, fragment);
          }
          if(search != -1) {
            uri.search = url.slice(search + 1);
            url = url.slice(0, search);
            href = url;
          }
          if(doubleSlash != -1) {
            uri.protocol = url.slice(0, doubleSlash);
            withoutProtocol = url.slice(doubleSlash+3);
            firstSlash = withoutProtocol.indexOf('/');
            if(firstSlash === -1) {
              uri.host = uri.path;
              uri.path = "";
            }
            else {
              uri.host = withoutProtocol.slice(0, firstSlash);
              uri.path = withoutProtocol.slice(firstSlash);
            }
            uri.origin = uri.protocol + "://" + uri.host;
            uri.directory = _this.getFolder(uri.path);
            uri.base = uri.origin + uri.directory;
            // return origin;
          }
          else {
            uri.path = url;
            uri.directory = _this.getFolder(url);
            uri.base = uri.directory;
          }

          //-- Filename
          uri.filename = url.replace(uri.base, '');
          dot = uri.filename.lastIndexOf('.');
          if(dot != -1) {
            uri.extension = uri.filename.slice(dot+1);
          }
          return uri;
        }
        /*
        Gets the base folder structure.
        */
        _this.getFolder = function(url) {
          var lastSlash = url.lastIndexOf('/');
          if(lastSlash == -1) var folder = '';
          folder = url.slice(0, lastSlash + 1);
          return folder;
        }
        /*
        This method returns a proper relative URL.
        */
        _this.resolveUrl = function(base, path) {
          var url,
          segments = [],
          uri = _this.getURI(path),
          folders = base.split("/"),
          paths;
          if(uri.host) {
            return path;
          }
          folders.pop();
          paths = path.split("/");
          paths.forEach(function(p){
            if(p === "..") {
              folders.pop();
            }
            else {
              segments.push(p);
            }
          });
          url = folders.concat(segments);

          return url.join("/");
        }
        /*
        This method will replace links within the book if needed
        It will also return the formed URI object for making a request.
        */
        _this.replaceLinks = function(link) {
          var href = link.getAttribute("href"),
          isRelative = href.search("://"),
          directory,
          relative,
          location,
          base,
          uri,
          url;
          //Open in a new tab since its an external URL.
          if(isRelative != -1){
            link.setAttribute("target", "_blank");

          }else{
            // Links may need to be resolved, such as ../chp1.xhtml
            base = document.querySelector(".bookFrame").contentDocument.querySelector("base");
            url = base.getAttribute("href");
            if(href.indexOf(".xhtml") > -1 || href.indexOf(".html") > -1){
              url = url.replace("/public","/private");
            }
            url = url.substring(0,url.lastIndexOf('/') + 1) + href;
            uri = _this.getURI(url);
            directory = uri.directory;
            if(directory) {
              // We must ensure that the file:// protocol is preserved for
              // local file links, as in certain contexts (such as under
              // Titanium), file links without the file:// protocol will not
              // work
              if (uri.protocol === "file") {
                relative = _this.resolveUrl(uri.base, href);
              } else {
                relative = _this.resolveUrl(directory, href);
              }
            }
            else {
              relative = href;
            }
            return uri;
          }
        }
      }

      function ePubFrame(frameConfig) {
        var _this = this;
        _this.render = {};
        _this.isFirstLoad = true;

        /*
        This method is used to remap relative url's within the
        html document to actual URL's so that the page can be
        rendered with images,stylesheets etc.
        */
        _this.remapAssets = function(responseDoc) {
            var head = responseDoc.getElementsByTagName("head")[0];
            var baseTag, updateFolderPath;
            baseTag = document.createElement('base');
            updateFolderPath = _this.currentSpineRecord.url;
            baseTag.href = updateFolderPath.replace("private", "public");
            head.insertBefore(baseTag, head.firstChild);
            var readerPlusURL = window.location.origin;
            // This method used open the Iframe content in new window by clicking the image
            var myscript = document.createElement("script");
            myscript.setAttribute("type", "text/javascript");
            myscript.innerHTML = 'function iframeClick(id){\n' +
                '$("#"+id).next().css({"visibility","visible"});\n' +
                'alert("hello");\n' +
                '}';
            head.appendChild(myscript);
            //This method used to play and pause by clciking the poster images in video
            var script = " function toggle(video) {" +
               "var isFirefox = typeof InstallTrigger !== 'undefined';" +
               "              if (video.paused) { " +
               "               if(!isFirefox)     " +
               "                  video.play();   " +
               "             }                    " +
               "              else {              " +
               "               if(!isFirefox)     " +
               "                  video.pause();  " +
               "              }                   " +
               "         }                        ";


            var videoScript = document.createElement("script")
            videoScript.setAttribute("type", "text/javascript");
            videoScript.innerHTML = script;
            head.appendChild(videoScript);


            responseDoc.getElementsByTagName("body")[0].style.overflowX = "hidden";
            var index = -1;
            var startindex = 0;
            var counter = 0;
            function spliceSlice(str, index, count, add) {
                var prefix = str.slice(0, index);
                var postfix = str.slice(index, count);
                return prefix + add + postfix;
            }
            /*Math Elements to use Fallback Image if present */
            var imageElement, width, height, style, equationImage, j=0;
            var mathElements = responseDoc.getElementsByTagName('math');
            if(mathElements.length === 0) {
            	mathElements = responseDoc.getElementsByTagName('m:math');
            }
            var elementLength = mathElements.length;
            for(var i=0; i < elementLength; i++){
            	equationImage = mathElements[j].getAttribute('altimg');
            	if(equationImage.length > 0 && equationImage!=null && equationImage != "") {
            	imageElement = document.createElement('img');
            	width = mathElements[j].getAttribute('altimg-width');
            	height = mathElements[j].getAttribute('altimg-height');
            	style = "display:block; position: relative; width:" + width + "height:" + height;
            	imageElement.setAttribute("src", equationImage);
            	imageElement.setAttribute("style" , style);
            	var parent = mathElements[j].parentElement ? mathElements[j].parentElement : mathElements[j].parentNode;
            	parent.removeChild(mathElements[j]);
            	parent.appendChild(imageElement);
              } else {
              	j = j + 1;
              }
            }

            /* Style tag added for customized audio player in iframe */
		    var body1 = responseDoc.getElementsByTagName('body')[0];
		    var audiocssscriptTag = document.createElement("style");
		     audiocssscriptTag.setAttribute("type", "text/css");
		     var readerLocation = window.location.origin;
		     var cssString ='.audiojs{width:470px;height:36px;background:#404040;overflow:hidden;font-family:monospace;font-size:12px;background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0,#444),color-stop(.5,#555),color-stop(.51,#444),color-stop(1,#444));background-image:-moz-linear-gradient(center top,#444 0,#555 50%,#444 51%,#444 100%);-webkit-box-shadow:1px 1px 8px rgba(0,0,0,.3);-moz-box-shadow:1px 1px 8px rgba(0,0,0,.3);-o-box-shadow:1px 1px 8px rgba(0,0,0,.3);box-shadow:1px 1px 8px rgba(0,0,0,.3)}.audiojs audio{position:absolute;left:-1px}audio:not([controls]){display:none}audio{width:300px;height:30px}.audiojs .play-pause{width:35px;height:40px;padding:4px 12px;margin:0;float:left;overflow:hidden;border-right:1px solid #000}.audiojs .scrubber{position:relative;float:left;width:280px;background:#5a5a5a;height:14px;margin:10px;border-top:1px solid #3f3f3f;border-left:0;border-bottom:0;overflow:hidden}.audiojs .error-message{float:left;display:none;margin:0 10px;height:36px;width:400px;overflow:hidden;line-height:36px;white-space:nowrap;color:#fff;text-overflow:ellipsis}.audiojs .play{background:url("' + readerLocation + '/assets/player-graphics.gif") -2px -1px no-repeat;display:block; margin:1}.audiojs .pause{background:url("' + readerLocation + '/assets/player-graphics.gif") -2px -91px no-repeat; margin:1}.audiojs .loading{background:url("' + readerLocation + '/assets/player-graphics.gif") -2px -31px no-repeat}.audiojs .error{background:url("' + readerLocation + '/assets/player-graphics.gif") -2px -61px no-repeat}.audiojs p{display:none;width:25px;height:40px;margin:0;cursor:pointer}p{display:block;-webkit-margin-before:1em;-webkit-margin-after:1em;-webkit-margin-start:0;-webkit-margin-end:0}.audiojs .time{float:left;height:36px;line-height:36px;padding:0 6px 0 20px;border-left:1px solid #000;color:#ddd;text-shadow:1px 1px 0 rgba(0,0,0,.5)}.audiojs .progress,audiojs .loaded{position:absolute;top:0;left:0;height:14px;width:0}audiojs .loaded{background:#000;background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0,#222),color-stop(.5,#333),color-stop(.51,#222),color-stop(1,#222));background-image:-moz-linear-gradient(center top,#222 0,#333 50%,#222 51%,#222 100%)}.audiojs .progress{background:#ccc;z-index:1;background-image:-webkit-gradient(linear,left top,left bottom,color-stop(0,#ccc),color-stop(.5,#ddd),color-stop(.51,#ccc),color-stop(1,#ccc));background-image:-moz-linear-gradient(center top,#ccc 0,#ddd 50%,#ccc 51%,#ccc 100%)}.playing .error,.playing .loading,.playing .play{display:none}.playing .pause{display:block}';
		    audiocssscriptTag.innerHTML=  cssString;
		    body1.appendChild(audiocssscriptTag);
		    var html = responseDoc.documentElement.innerHTML;
            do {
                counter++;
                var divContent = '<div id="div' + counter + '" style="background-color:gray;margin-bottom:10px"><center><img alt="" height="513" width="800" src="http://cdn.gloss.pearson-intl.com/web-resources/img/ic_assessment.png" onclick="window.open(document.getElementById(\'frame' + counter + '\').getAttribute(\'src\'))" /></center></div>';
                var index = html.indexOf("<iframe", startindex);
                if (index != -1) {
                    startindex = index + divContent.length + 10;
                    html = spliceSlice(html, index + 8, html.length, "id='frame" + counter + "' ")
                    html = spliceSlice(html, index, html.length, divContent);
                }
            } while (index != -1)

            html = html.replace(new RegExp('<iframe', 'g'), "<iframe style='display:none'");
            html = html.replace(new RegExp('<video', 'g'), '<video onclick="toggle(this)"');
            return html;
        }
        /*
        This method is triggered once the xhtml contents are fetched
        successfully after making an XHR call. This method will
        paint the iframe with the new content received.
        */
        _this.frameContentReceived = function(responseDoc) {
          console.log('epub responseDoc->', responseDoc, '_this.isFirstLoad', _this.isFirstLoad);
          var frame;
          responseDoc = _this.remapAssets(responseDoc);
          console.log('epub after remapAssets ');
          // If first load, create the frame freshly, else overwrite the frame.
          if (_this.isFirstLoad) {
            frame = _this.targetElement.appendChild(_this.render.iframe);
            _this.isFirstLoad = false;
          }
          else {
            frame = document.getElementById(_this.render.iframe.getAttribute('id'));
          }
          console.log('epub after 1 ');
          if(frame.contentWindow.MathJax){
               frame.contentWindow.MathJax = false;
            }
          console.log('epub after 2 ');
          var doc = frame.contentWindow.document;
          doc.open();
          doc.write(responseDoc);
          doc.close();
          console.log('epub after 3 ');
          /*
          Adding MathML NameSpace to the IFrame HTML and the MathJax.js to the head of the IFrame.
          */
          var html = frame.contentWindow.document.getElementsByTagName('html')[0];
          var headToAddMathML = frame.contentWindow.document.getElementsByTagName('head')[0];
          html.setAttribute('xmlns:m', "http://www.w3.org/1998/Math/MathML");
          var mathXMLscriptTag = document.createElement("script");
          mathXMLscriptTag.setAttribute("src", "https://cdn.mathjax.org/mathjax/latest/MathJax.js?config=TeX-AMS-MML_HTMLorMML");
          headToAddMathML.appendChild(mathXMLscriptTag);
          // Text Selection event trigger.
          if(ePubHelper.isFunction(frameConfig.contentSelectedCallback)) {
            document.querySelector('.bookFrame').contentDocument.
            addEventListener("mouseup",frameConfig.contentSelectedCallback);
          }
          console.log('epub after 4 ');
          // Add padding to the iframe content document.
          frame.contentDocument.body.style.paddingLeft = frame.contentDocument.body.style.paddingRight = "3%";
          // Always reset to top of iframe when content is refreshed.
          frame.contentWindow.scrollTo(0, 0);
                    console.log('epub after 4.1 ');
        }
        // Global config object for XHR request
        _this.ePubRequestConfiguration = {
          requestType: "json",
          dataType: "",
          requestURL: '',
          requestParam: {},
          dataCallback: _this.frameContentReceived,
        };

        // Variables used to store the current document and frame elements.
        _this.render.iframe = null;
        _this.render.document = null;
        _this.render.window = null;
        _this.render.docEl = null;
        _this.render.bodyEl = null;
        _this.render.leftPos = 0;
        _this.render.pageWidth = 0;

        _this.getLocalStorageObject = function(key) {
          if(window.localStorage) {
          var localStorageItem = localStorage.getItem(key);
            if(localStorageItem!==null) {
            return JSON.parse(localStorageItem);
             }
        }
        console.log('epub after 6 ');
      }

        /*
        This method will create an iframe on first load with the
        specified properties.
        */
        _this.createFrame = function() {
          _this.render.iframe = document.createElement('iframe');
          _this.render.iframe.id = "iframe:" + ePubHelper.generateUUID();
          _this.render.iframe.seamless = "seamless";
          // Back up if seamless isn't supported
          _this.render.iframe.style.border = "none";
          //_this.render.iframe.width = "125%";
          //Handling Fixed Layout Books
          var bookObject = _this.getLocalStorageObject('currentBook');
          if((bookObject.metadata.custom && bookObject.metadata.custom.height != 0) || (bookObject.metadata.custom && bookObject.metadata.custom.width != 0)) {

          _this.render.iframe.height = bookObject.metadata.custom.height  + 'px';
          _this.render.iframe.width = bookObject.metadata.custom.width + 'px';

          } else {
          _this.render.iframe.height = "100%";
         }
          _this.render.iframe.className = "bookFrame"
          return _this.render.iframe;
        }

        /*
        * Sets the source of the iframe with the given URL string
        * Takes:  The Spine record
        */
        _this.loadFrame = function(spineRecord) {
          console.log('epub spineRecord', spineRecord);
      if(spineRecord != null && spineRecord != undefined){
        _this.currentSpineRecord = spineRecord;
        _this.ePubRequestConfiguration.requestType = 'html';
        _this.ePubRequestConfiguration.requestURL = spineRecord.url;
        _this.ePubRequestConfiguration.requestParam = ePubConfig.requestHeaderParam;
        console.log('epub loadFrame making url', spineRecord.url);
        ePubRequest.getData(_this.ePubRequestConfiguration);
      }else{
        return false;
      }

          var render = _this.render;
          render.flag = 0;
          console.log("epub loadFrame _this.window->", _this.window);
          if (_this.window) {
            _this.unload();
          }

          _this.frameLoadedProcessing = function(e) {
console.log('epub frameLoadedProcessing called', e);
            var title;
            render.document = render.iframe.contentDocument;
            render.docEl = render.document.documentElement;
            render.headEl = render.document.head;
            render.bodyEl = render.document.body || render.document.querySelector("body");
            render.window = render.iframe.contentWindow;
            //-- Clear Margins
            if (render.bodyEl) {
              render.bodyEl.style.margin = "0";
            }

            // HTML element must have direction set if RTL or columnns will
            // not be in the correct direction in Firefox
            // Firefox also need the html element to be position right
            if (render.direction == "rtl" && render.docEl.dir != "rtl") {
              render.docEl.dir = "rtl";
              render.docEl.style.position = "absolute";
              render.docEl.style.right = "0";
            }

            var loadedURL = render.document.URL;
            console.log('epub loadedURL', loadedURL);
          //  if(loadedURL.indexOf('http') != -1){
          // initialize rangy
          try{
          initRangy();
           } catch(err) {
              console.log("Rangy has not initialized");
            frameConfig.pageLoadedCallback("pageLoaded", "event");
           }

             seajs.use(['./assets/audio.js'], function(){

               audiojs.events.ready(function() {
               var audioElements = document.querySelector('.bookFrame').contentWindow.document.getElementsByTagName('audio');
               for(var i=0; i<audioElements.length; i++) {
                   audioElements[i].removeAttribute('controls');
                   audioElements[i].setAttribute('preload', "auto");
               }
               var as = audiojs.createAll({}, audioElements);
             });
           });
           console.log('epub pageLoaded called');
            frameConfig.pageLoadedCallback("pageLoaded", "event");
          //  }

          };
           /*
          This function is triggered if the IFrame is not loaded completely due to the external contents within the IFrame.
          */
          _this.triggerFrameLoad = function () {
            console.log('epub triggerFrameLoad called');
            render.flag = render.flag + 1;
            if(render.flag == 1 || render.flag == 2) {

              _this.frameLoadedProcessing();
            }
          }

           _this.timeOutFrameLoad = function () {
          if(render.flag == 0)
          {
            _this.triggerFrameLoad();
          }
         }

         setTimeout(_this.timeOutFrameLoad, 15000);

         /*
          This event is fired once the iframe is rendered onto the document.
          Updates the global object instance.
          */
          _this.render.iframe.onload = _this.triggerFrameLoad;

          /*
          This event is triggered when the iframe is not loaded due to any error.
          */
          _this.render.iframe.onerror = function(e) {};
        };

        return {
          /*
          Method which is exposed as API to load the XHTML on to the iframe.
          */
          loadFrameContent: function(contentInformation, targetElement) {
            if (_this.isFirstLoad) {
              _this.targetElement = targetElement;
              _this.createFrame();
            }
            _this.loadFrame(contentInformation);
          }
        };
      }
      /*
      This class is the interface through which all ePub requests are handled
      through an XHR request. Requests are handled through RSVP asynchronously.
      Takes - requestConfig - A configuration object that determines request params.
      Returns - Returns a deferred promise that can be subscribed to.
      */
      function ePubRequest(requestConfig) {
        var _this = this;
        _this.request = function(url, type, headerparam) {
          var supportsURL = window.URL;
          var BLOB_RESPONSE = supportsURL ? "blob" : "arraybuffer";
          var deferred = new RSVP.defer();
          var xhr = new XMLHttpRequest();
          var xhrPrototype = XMLHttpRequest.prototype;

          if (!('overrideMimeType' in xhrPrototype)) {
            // IE10 might have response, but not overrideMimeType
            Object.defineProperty(xhrPrototype, 'overrideMimeType', {
              value: function xmlHttpRequestOverrideMimeType(mimeType) {}
            });
          }
          xhr.open("GET", url, true);
          xhr.onreadystatechange = handler;
          if (type == 'blob') {
            xhr.responseType = BLOB_RESPONSE;
          }
          if (type == "json") {
            xhr.setRequestHeader("Accept", "application/json");
          }
          if (type == "html") {
            xhr.setRequestHeader("Content-type", "application/xhtml+xml");
            xhr.setRequestHeader("appId", headerparam.appId);
            xhr.setRequestHeader("token", headerparam.token);
            xhr.responseType = "document";
          }
          if (type == 'xml') {
            xhr.overrideMimeType('text/xml');
          }
          if (type == "binary") {
            xhr.responseType = "arraybuffer";
          }
          xhr.send();
          // This method is the handler for the xhr request once it gets back.
          function handler() {
            if (this.readyState === this.DONE) {
              if (this.status === 200 || (this.status === 0 && this.response)) { // Android & Firefox reporting 0 for local & blob urls
                var r;
                if (type == 'xml') {
                  // If this.responseXML wasn't set, try to parse using a DOMParser from text
                  if (!this.responseXML) {
                    r = new DOMParser().parseFromString(this.response, "text/xml");
                  } else {
                    r = this.responseXML;
                  }
                } else
                if (type == 'json') {
                  r = JSON.parse(this.response);
                } else
                if (type == 'blob') {

                  if (supportsURL) {
                    r = this.response;
                  } else {
                    //-- Safari doesn't support responseType blob, so create a blob from arraybuffer
                    r = new Blob([this.response]);
                  }
                } else {
                  r = this.response;
                }
                deferred.resolve(r);
              } else {
                deferred.reject({
                  message: this.response,
                  stack: new Error().stack
                });
              }
            }
          }
          return deferred.promise;
        }
        return {
          /*
          This is the public method exposed as an API to get data through
          xhr for ePub.
          */
          getData: function(requestConfiguration) {
            var url = requestConfiguration.requestURL;
            var type = requestConfiguration.requestType;
            var headerparam = requestConfiguration.requestParam;
      if (ePubHelper.isString(url)) {
              _this.request(url, type, headerparam).then(function(data) {
                if (ePubHelper.isFunction(requestConfiguration.dataCallback)) {
                  requestConfiguration.dataCallback(data, requestConfiguration.dataType);
                }
              })
              .catch(function(error) {
                if (ePubHelper.isFunction(requestConfiguration.errorCallback)) {
                  requestConfiguration.errorCallback(error);
                }
              });
          } else {
            var dataobj = url;
        requestConfiguration.dataCallback(dataobj, requestConfiguration.dataType);
          }
          }
        };
      }
      // Global init method that is called internally to initialize the epub.
      _this.initializeWrapper = function() {
        _this.ePubConfiguration = {};
        _this.ePubRequestConfiguration = {
          requestType: "json",
          dataType: "",
          requestURL: '',
          requestParam: {},
          dataCallback: _this.dataReceived,
          errorCallback: _this.onRequestError
        };
        _this.bookInstance = {};

        _this.globalEPubConfig = {
          targetElement: null,
          bookPath: null,
          spreads: false, // Displays two columns
          fixedLayout: false, //-- Will turn off pagination
          styles: {}, // Styles to be applied to epub
          width: false,
          height: false,
        };
        if (!ePubHelper.isNullOrUndefined(ePubConfig) && !ePubHelper.isObjectEmpty(ePubConfig)) {
          // If the browser does not support Object.assign, add a polyfill for the same.
          ePubHelper.mergeObjectPolyfill();
          Object.assign(_this.ePubConfiguration, _this.globalEPubConfig, ePubConfig)
        } else {
          _this.ePubConfiguration = _this.globalEPubConfig;
        }
      }
      /*
      This internal method is used for converting an element id to
      an element instance or returning an element as is for rendering.
      */
      _this.getBookElementForRender = function(element) {
        var targetElement;
        if (!ePubHelper.isNullOrUndefined(element)) {
          if (ePubHelper.isElement(element)) {
            targetElement = element;
          } else {
            targetElement = ePubHelper.getElement(element);
          }
        }
        return targetElement;
      }
      /*
      This method is used to trigger an event based on the name.
      */
      _this.triggerEvent = function(eventName, eventData) {
        console.log('epub triggerEvent called', eventName, eventData);
        var eventCallback = _this.eventMap[eventName];
        if (!ePubHelper.isNullOrUndefined(eventCallback) && ePubHelper.isFunction(eventCallback)) {
          eventCallback(eventData);
        }
      }
      /*
      The callback method that is triggered when the data is
      received from the ePubRequest class.
      Takes -  data,dataType - The actual data and the type of data received.
      */
      _this.dataReceived = function(data, dataType, eventData) {
        switch (dataType) {
          case ePubConstants.dataTypes.initializeBook:
          _this.bookInstance = data;
          _this.currentBookSettings.currentPage = 1;
          _this.currentBookSettings.totalPages = _this.bookInstance.pages.length;
          var spineRecord = _this.bookInstance.pages[0];
          _this.ePubConfiguration.targetElement = _this.getBookElementForRender(_this.ePubConfiguration.targetElement);
          ePubFrame.loadFrameContent(spineRecord, _this.ePubConfiguration.targetElement);

          // Build the spine lookup table
          _this.buildSpineLookup();
          break;
          case ePubConstants.dataTypes.pageContent:
          break;
          case ePubConstants.dataTypes.event:
          if(data === ePubConstants.eventTypes.pageLoaded) {
            var documentBody = document.querySelector('.bookFrame').contentDocument.body;
            var links = documentBody.getElementsByTagName("a");
            for (var i = 0; i < links.length; i++) {
              // Attach an event only if its not a fragment within the same page.
              if(links[i].getAttribute('href') !== null && links[i].getAttribute('href').indexOf("#") !== 0) {
        //Check the current anchor element have external url or not
        if(links[i].getAttribute('href').search("://") == -1){
          links[i].onclick = function() {
            var uri = ePubHelper.replaceLinks(this);
            var hrefLocation = uri.href.split("#")[1];
            if(window.localStorage) {
               localStorage.setItem("hrefLocation", JSON.stringify(hrefLocation));
              }
            _this.gotoRelativeLink(uri);
            return false;
          }
        }else{
          links[i].onclick = function() {
            var uri = ePubHelper.replaceLinks(this);
            return;
          }
        }
              }else{
                 if(links[i].getAttribute('href') !== null){
                  links[i].onclick = function() {
                    _this.jumpLink(this);
            return false;
                  }
                 }
              }
            }
          }
          // trigger the event with the event data filled.
          _this.triggerEvent(data, eventData);
          break;
          default:
          break;
        }
      }
      /*
      This method is used to handle the text selection and trigger a cazllback to
      the client.
      */
      _this.handleTextSelection = function() {
        var selection = document.querySelector('.bookFrame').contentDocument.getSelection();
        // Trigger the event to the client. Should be handled there appropiately.
        _this.triggerEvent(ePubConstants.eventTypes.textSelected,selection);
      }

      /*
      This method is used to handle the highlight click and trigger an event to
      the client.
      */
      _this.handleHighlightClick = function(event) {
        var highlight = highlighter.getHighlightForElement(this);
        if(highlight.xpathRange) {
          var highlightData ={
          highlightHash: highlight.xpathRange,
          highlightText : highlight.getText()
           };
        } else {
          var highlightData ={
          highlightHash: getSerializedHash(highlight),
          highlightText : highlight.getText()
           };
        }
        // Trigger the event to the client. Should be handled there appropiately.
        _this.triggerEvent(ePubConstants.eventTypes.highlightClicked,highlightData);
        return false;
      }

      /*
      This method is automatically triggered when there is any error with
      the XHR request in the ePubRequest class.
      */
      _this.onRequestError = function(error) {
        _this.triggerEvent(ePubConstants.eventTypes.requestError, error);
      }

      // Frame configuration including callbacks.
      _this.frameConfig = {
        pageLoadedCallback: _this.dataReceived,
        contentSelectedCallback: _this.handleTextSelection
      }
      var ePubFrame = new ePubFrame(_this.frameConfig);

      // Internally creates the book object.
      _this.initializeBook = function() {
        _this.ePubRequestConfiguration.requestType = 'json';
        _this.ePubRequestConfiguration.requestURL = _this.ePubConfiguration.bookDataPath;
        _this.ePubRequestConfiguration.requestParam = _this.ePubConfiguration.requestHeaderParam;
        _this.ePubRequestConfiguration.dataType = ePubConstants.dataTypes.initializeBook;
        ePubRequest.getData(_this.ePubRequestConfiguration);
      }
      /*
      This method will build the spine lookup table
      */
      _this.buildSpineLookup = function() {
        var spineIndexByURL = {};
        _this.bookInstance.pages.forEach(function(item) {
          spineIndexByURL[item.href] = item.index;
        });
        _this.spineLookup = spineIndexByURL;
      }

      /*
      This method will build the spine lookup table
      */
      _this.locateLookup = function(filename) {
        var locateIndex;
        for (var item in _this.spineLookup) {
          var curItem = item;
          if(curItem.search(filename) > -1){
            locateIndex = curItem;
            return locateIndex;
          }
        };
      }

      /*
      This method will internally be used to make requests through the wrapper to
      load pages when clicking on the TOC links or any links as such.
      */
      _this.gotoRelativeLink = function(uriObj) {
        // Notify subscribers that an internal/ TOC link has been clicked.
        _this.triggerEvent(ePubConstants.eventTypes.linkClicked,true);
        var totalPages = _this.currentBookSettings.totalPages;
        var spineIndex = _this.locateLookup(uriObj.filename);
        var linkSpineIndex = _this.spineLookup[spineIndex];
        _this.currentBookSettings.currentSpineRecord = _this.bookInstance.pages[linkSpineIndex];
        _this.currentBookSettings.currentPage = linkSpineIndex + 1;
        ePubFrame.loadFrameContent(_this.currentBookSettings.currentSpineRecord, _this.ePubConfiguration.targetElement);
      }

      /*
      This method will construct the TOC Content from the toc object. It will support
      any levels of chapters.
      */
      _this.generateTocContent = function(toc,level) {
        var container = document.createElement("ul");
        if(!level) level = 1;
        var i=0,len=toc.length;
        for(;i<len;i++){
          var chapter = toc[i];
          var listitem = document.createElement("li"),
          link = document.createElement("a"),
          toggle = document.createElement("a");
          var subitems;
          listitem.id = chapter.id;
          listitem.classList.add('list_item');
          link.textContent = chapter.label;
          link.href = chapter.filename;
          link.classList.add('toc_link');
          listitem.appendChild(link);

          if(chapter.subitems.length > 0) {
            level++;
            subitems = _this.generateTocContent(chapter.subitems, level);
            toggle.classList.add('toc_toggle');
            listitem.insertBefore(toggle, link);
            listitem.appendChild(subitems);
          }
          container.appendChild(listitem);
        };
        return container;
      }

      /*
      This method is used to add a new highlight.
      Returns - A serialized object to be sent to the server to store.
      */
      _this.createHighlight = function() {
    var highlight = highlightSelectedText();
    var totalScrollHeight = document.querySelectorAll('.bookFrame')[0].contentWindow.document.body.scrollHeight;
    var currentScrollHeight = document.querySelectorAll('.bookFrame')[0].contentWindow.window.scrollY || document.querySelectorAll('.bookFrame')[0].contentWindow.window.pageYOffset;
    var scrollPercentage = 100 * currentScrollHeight / totalScrollHeight;
    highlight.serializedHighlight = highlight.serializedHighlight + "@" + scrollPercentage;
    if(_this.currentBookSettings.currentSpineRecord.href == undefined) {
      var pageId = _this.bookInstance.pages[0].href.split("/")[1];
          } else {
    	if(_this.currentBookSettings.currentSpineRecord.href.indexOf("/") > -1) {
           var pageId = _this.currentBookSettings.currentSpineRecord.href.split("/")[1];
         } else {
          var pageId = _this.currentBookSettings.currentSpineRecord.href;
        }
    }

        highlight.pageInformation = {
          pageNumber: _this.currentBookSettings.currentPage,
          pageId: pageId
        }
        return highlight;
      }
      /*
      This method is used to load all highlights for that page. Can be a single or
      multiple highlights.
      Also used to attach event listeners to highlighted elements.
      */
      _this.loadHighlights = function(highlights) {
        loadHighlights(highlights);
        // Highlight clicked event trigger.
        var contentDocument = document.querySelector('.bookFrame').contentDocument;
        var highlightedNodes = contentDocument.querySelectorAll('span.highlight')
        if(highlightedNodes.length > 0) {
          for (var highlightIndex = 0; highlightIndex < highlightedNodes.length; highlightIndex++) {
            highlightedNodes[highlightIndex].addEventListener('click', _this.handleHighlightClick);
          }
        }
      }
      /*
      This method is used to clear user highlights
      */
      _this.clearHighlights = function() {
        clearHighlights();
      }

      /*
        This method is used to go to the particular link inside the page
      */
      _this.jumpLink = function(link) {
         var href = link.getAttribute("href");
        _this.triggerEvent('scrollTo',href);
      }

      // Initialize the ePub Config.
      _this.initializeWrapper();
      return {
        /*
        Creates an instance of the ebook and binds it to the particular element
        Takes the DOM element or the element ID as a parameter to render the bool
        */
        createEbookInstance: function() {
          _this.initializeBook();
        },
        /*
        This method enables the UI to register for certain book events.
        */
        registerEvent: function(eventName, callbackMethod) {
          _this.eventMap[eventName] = callbackMethod;
        },
        // Navigates the user to the next page in the book
        navigateToNextPage: function() {
          var totalPages = _this.currentBookSettings.totalPages;
          var targetPage = _this.currentBookSettings.currentPage + 1;
          _this.currentBookSettings.currentPage = ePubHelper.adjustPageBounds(totalPages, targetPage, false);
          _this.currentBookSettings.currentSpineRecord = _this.bookInstance.pages[_this.currentBookSettings.currentPage - 1];
          ePubFrame.loadFrameContent(_this.currentBookSettings.currentSpineRecord, _this.ePubConfiguration.targetElement);
        },
        // Navigates the user to the previous page in the book
        navigateToPreviousPage: function() {
          var totalPages = _this.currentBookSettings.totalPages;
          var targetPage = _this.currentBookSettings.currentPage - 1;
          _this.currentBookSettings.currentPage = ePubHelper.adjustPageBounds(totalPages, targetPage, false);
          _this.currentBookSettings.currentSpineRecord = _this.bookInstance.pages[_this.currentBookSettings.currentPage - 1];
          ePubFrame.loadFrameContent(_this.currentBookSettings.currentSpineRecord, _this.ePubConfiguration.targetElement);
        },
        /*
        Navigates the user to a particular chapter based on his choice
        */
        displayChapter: function(chapter) {
          var totalPages = _this.currentBookSettings.totalPages;
          _this.currentBookSettings.currentPage = ePubHelper.adjustPageBounds(totalPages, chapter, false);
          _this.currentBookSettings.currentSpineRecord = _this.bookInstance.pages[_this.currentBookSettings.currentPage - 1];
          ePubFrame.loadFrameContent(_this.currentBookSettings.currentSpineRecord, _this.ePubConfiguration.targetElement);
        },
        //Navigates to a page number based on the ePub cfi.
        gotoPage: function(pageNumber) {
          var totalPages = _this.currentBookSettings.totalPages;
          _this.currentBookSettings.currentPage = ePubHelper.adjustPageBounds(totalPages, pageNumber, false);
          _this.currentBookSettings.currentSpineRecord = _this.bookInstance.pages[_this.currentBookSettings.currentPage - 1];
          ePubFrame.loadFrameContent(_this.currentBookSettings.currentSpineRecord, _this.ePubConfiguration.targetElement);
        },
        //Navigates to a percentage based on the ePub spine.
        gotoPercentageOfBook: function(percentage) {
          var totalPages = _this.currentBookSettings.totalPages;
          percentage = ePubHelper.adjustPageBounds(totalPages, percentage, true);
          var pageToNavigate = Math.ceil((percentage / 100) * totalPages);
          _this.currentBookSettings.currentPage = pageToNavigate;
          _this.currentBookSettings.currentSpineRecord = _this.bookInstance.pages[_this.currentBookSettings.currentPage - 1];
          ePubFrame.loadFrameContent(_this.currentBookSettings.currentSpineRecord, _this.ePubConfiguration.targetElement);
        },
        // Gets the percentage of the book navigated by using the spine and current locations.
        getPercentageOfBookNavigated: function() {
          var totalPages = _this.currentBookSettings.totalPages;
          var percentageNavigated = (_this.currentBookSettings.currentPage / totalPages) * 100;
          return percentageNavigated;
        },
        // Gets the total number of pages in the book.
        getTotalNumberOfPages: function() {
          return _this.currentBookSettings.totalPages;
        },
        // Gets the current page in the book.
        getCurrentPage: function() {
          return _this.currentBookSettings.currentPage;
        },
        // Gets the current page name in the book.
       getCurrentPageName: function(pageNumber) {
         var curPageName = _this.bookInstance.pages[pageNumber - 1].href;
         return curPageName;
       },
        /*
        This method adds a style to the eBook.
        For e.g font size, font color and so on.
        */
        addBookStyle: function(style, styleValue) {},
        /*
        Removes a style with a particular name from the epub
        Accepts a style name as parameter - For e.g font-size
        */
        removeBookStyle: function(style) {},
        /*
        This method is used to return the metadata for the book.
        */
        getMetaData: function() {
          if (!ePubHelper.isNullOrUndefined(_this.bookInstance)) {
            return _this.bookInstance.metadata;
          }
          return {};
        },
        /*
        This method is used to return the spine for the book.
        */
        getSpine: function() {
          if (!ePubHelper.isNullOrUndefined(_this.bookInstance)) {
            return _this.bookInstance.pages;
          }
          return [];
        },
        /*
        This method is used to return the TOC for the book.
        */
        getTOC: function() {
          if (!ePubHelper.isNullOrUndefined(_this.bookInstance)) {
            return _this.bookInstance.toc;
          }
          return [];
        },
        /*
        This method is used to return the TOC html snippet from generateTocContent function
        */
        getTOCContent: function() {
          if (!ePubHelper.isNullOrUndefined(_this.bookInstance)) {
            return _this.generateTocContent(_this.bookInstance.toc);
          }
          return [];
        },
        /*
        This method is used to return the TOC html snippet from generateTocContent function
        */
        navigateToTOCLink: function(link) {
          var uriObj = ePubHelper.replaceLinks(link);
          _this.gotoRelativeLink(uriObj);
        },
        // Takes the user to the first page in the book.
        gotoFirstPage: function() {
          _this.currentBookSettings.currentPage = 1;
          _this.currentBookSettings.currentSpineRecord = _this.bookInstance.pages[0];
          ePubFrame.loadFrameContent(_this.currentBookSettings.currentSpineRecord, _this.ePubConfiguration.targetElement);
        },
        // Takes the user to the last page in the book.
        gotoLastPage: function() {
          var pageToNavigate = _this.currentBookSettings.totalPages;
          _this.currentBookSettings.currentPage = pageToNavigate;
          _this.currentBookSettings.currentSpineRecord = _this.bookInstance.pages[pageToNavigate - 1];
          ePubFrame.loadFrameContent(_this.currentBookSettings.currentSpineRecord, _this.ePubConfiguration.targetElement);
        },
        // Goes to the TOC page. Needs to be
        // refined to return html to build a toc panel.
        gotoTOCPage: function() {
        var spineIndex = _this.locateLookup(_this.bookInstance.navPath);
          var tocSpineIndex = _this.spineLookup[spineIndex];
          var tocSpineRecord = _this.bookInstance.pages[tocSpineIndex];
          _this.currentBookSettings.currentPage = tocSpineIndex + 1;
          _this.currentBookSettings.currentSpineRecord = tocSpineRecord;
          ePubFrame.loadFrameContent(_this.currentBookSettings.currentSpineRecord, _this.ePubConfiguration.targetElement);
        },
        // Takes the user to the cover page in the application.
        gotoCoverPage: function() {
          var spineIndex = _this.locateLookup(_this.bookInstance.navPath);
          var coverSpineIndex = _this.spineLookup[spineIndex];
          var coverSpineRecord = _this.bookInstance.pages[coverSpineIndex];
          _this.currentBookSettings.currentPage = coverSpineIndex + 1;
          _this.currentBookSettings.currentSpineRecord = coverSpineRecord;
          ePubFrame.loadFrameContent(_this.currentBookSettings.currentSpineRecord, _this.ePubConfiguration.targetElement);
        },
        // Destroys the book instance including event listeners.
        destroyBook: function() {},

        /*
        Triggers a method to save the user selection as a highlight
        */
        createHighlight: function() {
          var highlight = _this.createHighlight();
          // Highlight clicked event trigger.
          var contentDocument = document.querySelector('.bookFrame').contentDocument;
          var highlightedNodes = contentDocument.querySelectorAll('span.highlight')
          if(highlightedNodes.length > 0) {
            for (var highlightIndex = 0; highlightIndex < highlightedNodes.length; highlightIndex++) {
              //Remove and add event listeners.
              highlightedNodes[highlightIndex].removeEventListener('click', _this.handleHighlightClick);
              highlightedNodes[highlightIndex].addEventListener('click', _this.handleHighlightClick);
            }
          }

          return highlight;
        },
        /*
        Triggers a method to restore the user highlight.
        */
        restoreHighlights: function(highlights) {
          if(highlights != ''){
            _this.loadHighlights(highlights);
          }
        },

        /*
        Triggers a method to clear the user highlight.
        */
        clearHighlights: function() {
          _this.clearHighlights();
        }

      };
    }
    return ePubWrapper;
  }));
