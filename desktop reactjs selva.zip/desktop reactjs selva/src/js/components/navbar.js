import React from 'react';
import AppActions from '../actions/app.actions';
import AppConstants from '../constants/app.constants';
import {Navbar, Nav, MenuItem, NavItem, DropdownButton, ButtonGroup} from 'react-bootstrap';
import DataFormatter from './utilities/dataFormatter';
import Localization from './localization';
import AppStore from '../stores/app.store';

var lang = DataFormatter.getLanguage();

class PageNavbar extends React.Component {

  constructor() {
    super();
    this.navigateToBookshelf = this.navigateToBookshelf.bind(this);
  }

  state = {
      isBookmarked: false
  };

  /*
  This method is triggered when the user wants to navigate to the
  bookshelf by clicking on the readerplus brand icon.
  */
  navigateToBookshelf = function() {
    // Go back to the bookshelf page.
    AppActions.brandNameClicked();
  }

  /*
  This method is triggered when the user clicks on an Element
  within the book header.
  */
  headerItemClicked = function(itemDetails,event)
  { console.log("Header Item has been Clicked");
    DataFormatter.setObjectInStorage('audioLinkClicked', false);
    if(itemDetails == "ACESSIBILITY") {
      DataFormatter.setObjectInStorage("accessibilityClicked", true);
    }
    event.preventDefault();
    AppActions.bookHeaderItemClicked(itemDetails);
  }


hideAccessibilityMenu = function(){
  document.querySelector('.accessibilityContainer').style.visibility = "hidden";
}
  /*
  This method is triggered when the user wants to logout from the app.
  */
    logoutUser = function()
  {
    console.log('navbarjs logoutUser called');
    var logoutText = lang + ".UserMessages.UserLoggedOut";
    var logoutMessage = DataFormatter.getObjectText(Localization, logoutText);
    AppActions.logoutUser({
      action:"logout",
      message:logoutMessage ? logoutMessage : AppConstants.UserMessages.UserLoggedOut
    });
  }



  render() {
    console.log('NavBar render called');
    var loggedInUser, userControls, imageUrl;
    if (this.state.isBookmarked == true) {
        imageUrl = './images/bookmark-selected.png';
    } else {
       	imageUrl = './images/bookmark.png';
    }
    var userInformation = DataFormatter.getObjectInStorage("userInformation");
    if(userInformation) {
      loggedInUser =
      <ButtonGroup>
        <DropdownButton title={userInformation.name} id="bg-nested-dropdown">
          <MenuItem eventKey="1" id='logout' onClick={this.logoutUser}>{DataFormatter.getObjectText(Localization, (lang + ".PageText.Logout"))}</MenuItem>
        </DropdownButton>
       </ButtonGroup>
    }
    // Add condition so that the book access controls are present only in
    // the reader panel page.
    console.log('navbarjs curpagename  -->', location.hash);
    let curpagename = location.hash;
    if(curpagename.indexOf('/readBook') >=0 )
    {
      userControls =
      <Nav>
        <NavItem onClick={this.headerItemClicked.bind(this,AppConstants.BookHeaderOptions.TOC)} eventKey={2} href="#">
          <image src="./images/toc.png" width="27" height="30" />
        </NavItem>
        <NavItem onClick={this.headerItemClicked.bind(this,AppConstants.BookHeaderOptions.HIGHLIGHTS)} eventKey={3} href="#">
          <image src="./images/notes.png" width="27" height="30" />
        </NavItem>
        <NavItem onClick={this.headerItemClicked.bind(this,AppConstants.BookHeaderOptions.BOOKMARK)} eventKey={4} href="#">
          <image src="./images/bookmark.png" width="27" height="30" />
        </NavItem>
        <NavItem onClick={this.headerItemClicked.bind(this,AppConstants.BookHeaderOptions.ACESSIBILITY)} eventKey={10} href="#">
          <image src="./images/ic_action_settings.png" width="27" height="30" />
      </NavItem>
      <ButtonGroup>
        <DropdownButton  title='' className='readingPanelCover' onClick={this.hideAccessibilityMenu.bind(this)} bsStyle="default" noCaret>
        <MenuItem  className='zoom_element' id='zoom_100' onClick={this.headerItemClicked.bind(this,AppConstants.BookHeaderOptions.ZOOM100)} eventKey={1} href="#">100 % </MenuItem>
        <MenuItem  className='zoom_element' id='zoom_125' onClick={this.headerItemClicked.bind(this,AppConstants.BookHeaderOptions.ZOOM125)} eventKey={6} href="#">125 % </MenuItem>
        <MenuItem  className='zoom_element' id='zoom_150' onClick={this.headerItemClicked.bind(this,AppConstants.BookHeaderOptions.ZOOM150)} eventKey={7} href="#">150 % </MenuItem>
        <MenuItem  className='zoom_element' id='zoom_175' onClick={this.headerItemClicked.bind(this,AppConstants.BookHeaderOptions.ZOOM175)} eventKey={8} href="#">175 % </MenuItem>
        <MenuItem  className='zoom_element' id='zoom_200' onClick={this.headerItemClicked.bind(this,AppConstants.BookHeaderOptions.ZOOM200)} eventKey={9} href="#">200 % </MenuItem>
        </DropdownButton>
        </ButtonGroup>
      </Nav>
       ;
    } else { if(curpagename.indexOf('/readPDF') >=0 ) {
      userControls =
      <Nav>
        <NavItem onClick={this.headerItemClicked.bind(this,AppConstants.BookHeaderOptions.TOC)} eventKey={2} href="#">
          <image src="./images/toc.png" width="27" height="30" />
        </NavItem>
        <NavItem onClick={this.headerItemClicked.bind(this,AppConstants.BookHeaderOptions.HIGHLIGHTS)} eventKey={3} href="#">
          <image src="./images/notes.png" width="27" height="30" />
        </NavItem>
        <NavItem onClick={this.headerItemClicked.bind(this,AppConstants.BookHeaderOptions.BOOKMARK)} eventKey={4} href="#">
          <image src="./images/bookmark.png" width="27" height="30" />
        </NavItem>
      <DropdownButton  className='readingPanelCover' bsStyle="default" noCaret>
      <MenuItem  className='zoom_element' id='zoom_100' onClick={this.headerItemClicked.bind(this,AppConstants.BookHeaderOptions.ZOOM100)} eventKey={1} href="#">100 % </MenuItem>
      <MenuItem  className='zoom_element' id='zoom_125' onClick={this.headerItemClicked.bind(this,AppConstants.BookHeaderOptions.ZOOM125)} eventKey={6} href="#">125 % </MenuItem>
      <MenuItem  className='zoom_element' id='zoom_150' onClick={this.headerItemClicked.bind(this,AppConstants.BookHeaderOptions.ZOOM150)} eventKey={7} href="#">150 % </MenuItem>
      <MenuItem  className='zoom_element' id='zoom_175' onClick={this.headerItemClicked.bind(this,AppConstants.BookHeaderOptions.ZOOM175)} eventKey={8} href="#">175 % </MenuItem>
      <MenuItem  className='zoom_element' id='zoom_200' onClick={this.headerItemClicked.bind(this,AppConstants.BookHeaderOptions.ZOOM200)} eventKey={9} href="#">200 % </MenuItem>
      </DropdownButton>
      <NavItem onClick={this.headerItemClicked.bind(this,AppConstants.BookHeaderOptions.AUDIOICON)} eventKey={4} href="#">
          <image className='audioIcon' src="./images/audio_icon.png" width="27" height="30" />
      </NavItem>
      </Nav>;
      }
    }
    return (
      <div>
        <Navbar inverse>
          <Navbar.Header>
            <Navbar.Brand>
              <a href="#">Reader+</a>
            </Navbar.Brand>
          </Navbar.Header>
          {userControls}
          <Nav pullRight>
            {loggedInUser}
          </Nav>
        </Navbar>
      </div>
    );
  }
  /*
  This method is triggered when the navbar component is mounted.
  */
  componentDidMount = function() {
      // Attach a click event for the navbar brand click.
    document.querySelector(".navbar-brand").addEventListener("click",this.navigateToBookshelf.bind(this));
    //listen for desktop menu event for logout
    electron.ipcRenderer.on('logout', (event, message) => {
      console.log('electron.ipcRenderer --> logout');
		 this.logoutUser();
	 });
   electron.ipcRenderer.on('navigateToBookshelf', (event, message) => {
     this.navigateToBookshelf();
    });

  }


  logoutCompleted = () => {
     console.log('navbarjs logoutCompleted called');
 		this.context.router.push('/');
 		var response = AppStore.response;
 		this.updateMessage(response.message,response.action);
     if(window.fontSettings){
       window.fontSettings.color = "";
   		window.fontSettings.backgroundColor = "";
   		window.fontSettings.fontSize = "";
     }
 		var fontfamily   = DataFormatter.getObjectInStorage('fontfamily');
 		var fonttheme = DataFormatter.getObjectInStorage('fonttheme');
 		var defaultColor = DataFormatter.getObjectInStorage("defaultColor");
 		var fontsize = DataFormatter.getObjectInStorage("fontsize");
         var defaultBackgroundColor = DataFormatter.getObjectInStorage("defaultBackgroundColor");
 		if(fontfamily)
 		{
 			localStorage.removeItem('fontfamily');
 		}
 		else if (fonttheme)
 		{
 			localStorage.removeItem('fonttheme');
 		}
 		else{
 			localStorage.removeItem('defaultColor');
 			localStorage.removeItem('defaultBackgroundColor');
 			localStorage.removeItem('fontsize');
 		}
 	}

   updateMessage = function(content,flag){
     console.log('navbarjs updateMessage -->', content, flag);
 		// if(flag=='success'){
 		// 	AppActions.getUser();
 		// }
 		// else if(flag === "logout")
 		// {
 		// 	this.setState({ErrorTxt:content,FontStyle:'greenTxt'});
 		// }
 		// else{
 		// 	this.setState({ErrorTxt: content,FontStyle:'errTxt'});
 		// }
 	}

   brandNameClicked = () => {
 		var response = AppStore.response;
 		try{
 		var isEpubUnmounted = DataFormatter.getObjectInStorage('ePubunmounted');
 	    }catch(e) {}
 		if(!isEpubUnmounted || isEpubUnmounted == undefined){
 		window.location.reload();
 	    } else {
 		DataFormatter.setObjectInStorage('ePubunmounted', false);
 	    }
 		this.context.router.push('/bookshelf');
 	}


    componentDidUpdate = function() {
      if(document.querySelector('.audioIcon')) {
          document.querySelector('.audioIcon').style.visibility = "hidden";
        }
    }

    componentWillMount() {
    	AppStore.on(AppConstants.EventTypes.USER_LOGOUT_COMPLETE, this.logoutCompleted);
  		AppStore.on(AppConstants.EventTypes.BRAND_CLICKED, this.brandNameClicked);
    }
  /*
  Clean up event handlers and other code.
  */
  componentWillUnmount = function() {
    document.querySelector(".navbar-brand").removeEventListener("click",this.navigateToBookshelf.bind(this));
    AppStore.removeListener(AppConstants.EventTypes.USER_LOGOUT_COMPLETE, this.logoutCompleted);
    AppStore.removeListener(AppConstants.EventTypes.BRAND_CLICKED, this.brandNameClicked);

  }
};


PageNavbar.contextTypes= {
  router: React.PropTypes.object.isRequired
}
export default PageNavbar;
