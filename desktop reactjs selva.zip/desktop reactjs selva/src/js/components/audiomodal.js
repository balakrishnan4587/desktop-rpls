import React from 'react';
import {Modal} from 'react-bootstrap';
import {Button} from 'react-bootstrap';
import DataFormatter from './utilities/dataFormatter';
import Localization from './localization';

class AudioModal extends React.Component {

constructor() {
    super();
    this.closePopUp = this.closePopUp.bind(this);
    this.clickLink = this.clickLink.bind(this);
    this.hideAudioComponent = this.hideAudioComponent.bind(this);
    this.handleImage = this.handleImage.bind(this);
    this.imageChange =this.imageChange.bind(this);
    // this.showAudioComponent = this.showAudioComponent.bind(this);
  }

  state = { 
    intervalId: "",
    url: ""
  }

componentDidMount = function() {
    try{
      var audioElements = document.getElementsByTagName('audio');
      audiojs.createAll({}, audioElements);      
    }catch(e){

    }

    // document.querySelector(".pdf-fwr-pc-main").addEventListener('click', this.hideAudioComponent);
  this.handleImage();
}
componentWillUpdate = function() {
  try{
    if(!document.querySelector('.audiojs')) {
       var audioElements = document.getElementsByTagName('audio');
      audiojs.createAll({}, audioElements);  
      }
    if(DataFormatter.getObjectInStorage("audioLinkClicked")) {
      if(document.querySelector('.audioIcon')) {
        document.querySelector('.audioIcon').style.visibility = "visible";
      }
      if(document.querySelector('.audiojs')) {
      var currentLink = document.querySelector('.audiojs').querySelector('.popoutAudio').getElementsByTagName('source')[0].getAttribute('src');  
      }
     
      if(!currentLink) {
        currentLink = this.props.audioLinkUrl;
      }
      for(var i=0; i<(Object.keys(audiojs.instances).length -1); i++) {
      audiojs.instances[Object.keys(audiojs.instances)[i]].pause();  
      }
      audiojs.instances[Object.keys(audiojs.instances)[Object.keys(audiojs.instances).length-1]].load(currentLink);
      audiojs.instances[Object.keys(audiojs.instances)[Object.keys(audiojs.instances).length-1]].play();
      
       if(document.querySelector(".audiojs")) {
        console.log("Came Here6");
      document.querySelector(".audioContainer").style.visibility = "visible";       
      }
    }
     
    }catch(e){
        console.log(e);
    }


}

  componentWillUnmount = function() {
    // document.querySelector(".pdf-fwr-pc-main").removeEventListener('click', this.hideAudioComponent);
  }
  render = function() {
    var url = this.props.audioLinkUrl;
    if(this.props.isAudioModalShown) {
       return (
      <div className='audioParentContainer'>                  
        <div className='audioContainer'>
        <audio className = 'popoutAudio' controls preload = "auto">
          <source src={url} > </source>
          Your browser does not support the audio tag.
        </audio>
        </div>
      </div>
       );  
     }else {
      return null;
     }
   
  }

  handleImage = function() {
    window.clearInterval(this.state.intervalId);
    var id = window.setInterval(this.imageChange, 1000);
    this.setState({
      intervalId: id
    })
  }

  imageChange = function() {
    try{
      var currentIcon = String(document.querySelector('.audioIcon').getAttribute('src').split('/')[2]);
      if(document.querySelector('.audiojs.playing')) {
           if(currentIcon == "audio_icon.png") {
            currentIcon = "audio_icon1.png";
           }else {
            if(currentIcon == "audio_icon1.png") {
              currentIcon = "audio_icon2.png";
            } else {
              if(currentIcon == "audio_icon2.png") {
              currentIcon = "audio_icon3.png";
            } else {
              currentIcon = "audio_icon.png";
             }
            }
           }
         } else{
          currentIcon = "audio_icon.png";
         }
         document.querySelector('.audioIcon').setAttribute('src', "assets/images/" + currentIcon);
      }catch(e) {

         }   
  }

  // showAudioComponent = function() {
  //    try {
  //       document.querySelector(".audioContainer").style.visibility = "";
  //     }catch(e)
  //     {        
  //    } 
  // }

  hideAudioComponent = function() {
      try {
        document.querySelector(".audioContainer").style.visibility = "hidden";
      }catch(e)
      {        
     } 
  }
closePopUp = function() {
	this.props.audioLinkCloseCallback();
}

clickLink = function() {
	document.querySelector('.openPopup').click();
}

};

export default AudioModal;