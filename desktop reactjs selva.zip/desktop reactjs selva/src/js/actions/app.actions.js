import AppConstants from '../constants/app.constants';
import AppDispatcher from '../dispatchers/app.dispatcher';
import RequestHandler from '../components/requestHandler';
import DataFormatter from '../components/utilities/dataFormatter';
import assign from 'react/lib/Object.assign';
import bookShelfProvider from '../providers/bookshelfprovider'

let ActionTypes = AppConstants.ActionTypes;
let reqHandler = new RequestHandler();
let requestParameters = {};
let headerParameters = {};
  ga('create', AppConstants.GA_Id , 'auto');
  ga('send', 'pageview');

function getdeviceId() {
    var CookieDate = new Date;
    CookieDate.setFullYear(CookieDate.getFullYear() + 20);
    document.cookie = 'myCookie=to_be_deleted; expires=' + CookieDate.toGMTString() + ';';
    //  var d = new Date().getTime();
    var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = (CookieDate + Math.random() * 16) % 16 | 0;
        CookieDate = Math.floor(CookieDate / 16);
        return (c == 'x' ? r : (r & 0x7 | 0x8)).toString(16);
    });
    return uuid;
};
let AppActions = {

    getUser: function() {
        headerParameters = {
            'appId': AppConstants.AppID,
            'token': DataFormatter.getKeyFromObject("userInformation", "userToken")
        }
        reqHandler.handleRequest(AppConstants.RequestTypes.get, AppConstants.APIBaseUrl + 'user',
            headerParameters, requestParameters,
            function(err, res) {
                var userInformation = DataFormatter.getObjectInStorage("userInformation")
                assign(userInformation, res.body);
                DataFormatter.setObjectInStorage("userInformation", userInformation);
                var userID = "" , userName = "", role = "" ;
                try {
                    userID = DataFormatter.getKeyFromObject("userInformation", "id");
                    userName = DataFormatter.getKeyFromObject("userInformation", "username");
                    role = DataFormatter.getKeyFromObject("userInformation", "role");
                }catch(e){}
                DataFormatter.sendAWSEvent("login", { "action": "login" , "username" : userName, "status" : "success", "role": role ,  "user_id": userID});
                AppDispatcher.dispatch({
                    type: ActionTypes.GET_USER,
                    data: res.body
                });
            })
    },
    loginValidate: function(e) {
        e.preventDefault();
        AppDispatcher.handleViewAction({
            funcname: 'postvalidation'
        });
    },
    loginSubmit: function(userName, password) {
      headerParameters = {
          'appId': AppConstants.AppID,
          'token': DataFormatter.getKeyFromObject("userInformation", "userToken")
      }

        var userRole = DataFormatter.getKeyFromObject('userInformation', 'role')
        var deviceId = getdeviceId();
        headerParameters = {
            'appId': AppConstants.AppID
        }
        requestParameters = {
            'username': userName,
            'password': password,
            'deviceId': getdeviceId(),
        }
        reqHandler.handleRequest(AppConstants.RequestTypes.post, AppConstants.APIBaseUrl + 'authenticate',
            headerParameters, requestParameters,
            function(err, res) {

                let responseStatus = '';
                if (err) {
                    ga('send', {
                        hitType: 'event',
                        eventCategory: 'Login',
                        eventAction: 'Attempt',
                        eventLabel: JSON.stringify({
                            "status": "Failed",
                            "userId": userName,
                        })
                    });
                     var userID = "" , role = "" ;
                  try {
                        userID = DataFormatter.getKeyFromObject("userInformation", "id");
                        userName = DataFormatter.getKeyFromObject("userInformation", "username");
                        role = DataFormatter.getKeyFromObject("userInformation", "role");
                }catch(e){}
                DataFormatter.createAWSSession();
                DataFormatter.sendAWSEvent("login", { "action": "login" , "username" : userName, "status" : "failed", "role": role ,  "user_id": userID});
                    responseStatus = 'failed';
                } else {

                 var userInformation = {};
                    userInformation.userToken = res.body.token;
                    console.log('token',  res.body.token);
                    DataFormatter.setObjectInStorage("userInformation", userInformation);
                    responseStatus = 'success';
                    ga('send', {
                        hitType: 'event',
                        eventCategory: 'Login',
                        eventAction: 'Attempt',
                        eventLabel: JSON.stringify({
                            "status": "Success",
                            "userId": userName,
                            "role": 'student'
                        })
                    });
                }
                AppDispatcher.dispatch({
                    type: ActionTypes.LOGIN_SUBMIT,
                    data: res.body,
                    status: responseStatus
                });
            })
    },
    loadBookshelf: function() {
        let id, usertoken;
        if (window.localStorage) {
          id = DataFormatter.getKeyFromObject("userInformation", "id");
        } else {
            id = 123;
        }
        console.log('token', usertoken);
        bookShelfProvider.getByUserid(id, (err, bookshelves) => {
          console.log('appactionsjs booksheves got ', bookshelves);
           AppDispatcher.dispatch({
               type: ActionTypes.BOOKSHELF_LOAD,
               data: bookshelves
           });

       });

    },
    logoutUser: function(logoutType) {
        console.log('appactionsjs logoutUser -->', logoutType);
        var user = DataFormatter.getObjectInStorage('userInformation');
        console.log('appactionsjs logoutUser -->   user ', user);

        try {
        ga('send', {
            hitType: 'event',
            eventCategory: 'Logout',
            eventAction: 'Attempt',
            eventLabel: JSON.stringify({
                "status": "Success",
                "userId": user.username,
                "role": user.role
            })
        });
    }catch(e){
        console.log('appactionsjs logoutUser error-->', e);
    }
        console.log('appactionsjs window.localStorage-->', window.localStorage);
        if (window.localStorage) {
            localStorage.removeItem('userInformation');
            localStorage.removeItem('curpagepath');
            localStorage.removeItem('curbookpageno');
            localStorage.removeItem('currentBook');
        }
//Following code is not required
//        console.log(' appactionsjs reqHandler /logout-->');
        // reqHandler.handleRequest(AppConstants.RequestTypes.get, AppConstants.APIBaseUrl + 'logout',
        //     headerParameters, requestParameters,
        //     function(err, res) {
        //       try {
        //         DataFormatter.createAWSSession();
        //         DataFormatter.sendAWSEvent("login", { "action": "logout" , "role": user.role ,  "user_id": user.id});
        //       }catch(e){
        //         console.log('appactionsjs  error in Logging out', e);
        //       }
        //       console.log(' appactionsjs AppDispatcher.dispatch-->');
        //
        //     })
            AppDispatcher.dispatch({
                type: ActionTypes.LOGOUT_USER,
                data: logoutType
            });

    },
    bookClicked: function(bookID) {
      headerParameters = {
          'appId': AppConstants.AppID,
          'token': DataFormatter.getKeyFromObject("userInformation", "userToken")
      }
        reqHandler.handleRequest(AppConstants.RequestTypes.get, AppConstants.APIBaseUrl + 'book/' + bookID,
            headerParameters, requestParameters,
            function(err, res) {
                if (res) {
                    ga('send', {
                        hitType: 'event',
                        eventCategory: 'Book',
                        eventAction: 'open',
                        eventLabel: JSON.stringify({
                            "book title": res.body.metadata.title,
                            "book id": bookID
                        }, )
                    });
                }
                AppDispatcher.dispatch({
                    type: ActionTypes.BOOK_CLICKED,
                    data: res.body
                });
            })
    },
    bookHeaderItemClicked: function(itemClicked) {
        AppDispatcher.dispatch({
            type: ActionTypes.HEADER_ITEM_CLICKED,
            data: itemClicked
        });
    },
    brandNameClicked: function() {
        AppDispatcher.dispatch({
            type: ActionTypes.BRAND_CLICKED,
            data: null
        });
    },
    getBookBookmarks: function(bookId) {
      console.log('appactionsjs getBookBookmarks called 274-->', bookId);
        var userID = DataFormatter.getKeyFromObject("userInformation", "id");
        var usertoken = DataFormatter.getKeyFromObject("userInformation", "userToken");
        headerParameters = {
            'appId': AppConstants.AppID,
            'token': usertoken
        }
        reqHandler.handleRequest(AppConstants.RequestTypes.get, AppConstants.APIBaseUrl + 'highlight/source/' + bookId,
            headerParameters, null,
            function(err, res) {

                // Filter deleted highlights.
                var validBookmarks = res.body.filter(function(bookmark) {
                    return (bookmark.status !== 'deleted' && bookmark.sourceType == 'bookmark')
                });
                var sortedBookmarks = DataFormatter.sortNumbers(validBookmarks, AppConstants.SortType.ASC, "pageIndex");
                AppDispatcher.dispatch({
                    type: ActionTypes.GET_BOOK_BOOKMARKS,
                    data: {
                        sortedBookmarks: sortedBookmarks
                    }
                });
            })
    },
    getBookHighlights: function(bookId, shouldReloadPage) {
        var userID = DataFormatter.getKeyFromObject("userInformation", "id");
        var usertoken = DataFormatter.getKeyFromObject("userInformation", "userToken");
        headerParameters = {
            'appId': AppConstants.AppID,
            'token': usertoken
        }
        reqHandler.handleRequest(AppConstants.RequestTypes.get, AppConstants.APIBaseUrl + 'highlight/source/' + bookId,
            headerParameters, null,
            function(err, res) {
                // Filter deleted highlights.
                var validHighlights = res.body.filter(function(highlight) {
                    return (highlight.status !== 'deleted' && highlight.sourceType == 'highlight')
                });
                var sortedHighlights = DataFormatter.sortNumbers(validHighlights, AppConstants.SortType.ASC, "pageIndex");
                AppDispatcher.dispatch({
                    type: ActionTypes.GET_BOOK_HIGHLIGHTS,
                    data: {
                        sortedHighlights: sortedHighlights,
                        shouldReloadPage: shouldReloadPage
                    }
                });
            })
    },
    manageBookmark: function(bookmark) {
        var userID = DataFormatter.getKeyFromObject("userInformation", "id");
        var usertoken = DataFormatter.getKeyFromObject("userInformation", "userToken");
        var bookObject = DataFormatter.getObjectInStorage('currentBook');

        headerParameters = {
            'appId': AppConstants.AppID,
            'token': usertoken
        }
        requestParameters = {
            'sourceId': bookmark.bookId,
            'sourceType': "bookmark",
            'colour' : "yellow",
            'user': userID,
            'comment': String(bookmark.title),
            'pageId': String(bookmark.pageIndex),
            'pageIndex': String(bookmark.pageNumber),
            'highlightHash': bookmark.bookmarkHash,
            'note' : String(bookmark.title)
        }
        DataFormatter.createAWSSession();
        if (bookmark.isNewBookmark) {
            reqHandler.handleRequest(AppConstants.RequestTypes.post, AppConstants.APIBaseUrl + 'highlight',
                headerParameters, requestParameters,
                function(err, res) {
                    if (res) {
                    // console.log("action:" + "create" + "book_id:" + DataFormatter.getObjectInStorage("bookId") + "reading_mode:"  + "not_available" + "book_title:" + DataFormatter.getObjectInStorage("bookTitle")  + "selected_bookmark_snippet" + String(requestParameters.note) + "user_id:" + userID);
                        DataFormatter.sendAWSEvent("reader", { "action": "create" , "book_id" : DataFormatter.getObjectInStorage("bookId") , "reading_mode" : "not_available" , "book_title" : DataFormatter.getObjectInStorage("bookTitle") , "selected_bookmark_snippet" : String(requestParameters.note) , "user_id": userID});
                        requestParameters.pageIndex = String(requestParameters.pageIndex);
                        requestParameters.comment = String(requestParameters.comment);
                        requestParameters.pageId = String(requestParameters.pageId);
                        requestParameters.note = String(requestParameters.note);
                        reqHandler.handleRequest(AppConstants.RequestTypes.put, AppConstants.APIBaseUrl + 'highlight/' + res.body.id,
                headerParameters, requestParameters,function(){});
                        ga('send', {
                            hitType: 'event',
                            eventCategory: 'Bookmark',
                            eventAction: 'Created',
                            eventLabel: JSON.stringify({
                                "book title": bookObject.metadata.title,
                                "book_id": bookmark.bookId,
                                "page_index": bookmark.pageIndex
                            })
                        });
                    }
                    // Refresh the book panel.
                    var bookId = DataFormatter.getObjectInStorage("productId");
                    console.log('appactionsjs getBookBookmarks Refresh the book panel 369-->', bookId);
                    AppActions.getBookBookmarks(bookId);

                }, "application/x-www-form-urlencoded")
        } else {
          headerParameters = {
              'appId': AppConstants.AppID,
              'token': DataFormatter.getKeyFromObject("userInformation", "userToken")
          }
            requestParameters.status = 'deleted';
            reqHandler.handleRequest(AppConstants.RequestTypes.put, AppConstants.APIBaseUrl + 'highlight/' + bookmark.shouldDeleteId,
                headerParameters, requestParameters,
                function(err, res) {
                    if (res) {
                        console.log("action:" + "create" + "book_id:" + bookId + "reading_mode:"  + "not_available" + "book_title:" + bookTitle  + "selected_bookmark_snippet" + String(requestParameters.note) + "user_id:" + userID);
                        DataFormatter.sendAWSEvent("reader", { "action": "delete" , "book_id" : DataFormatter.getObjectInStorage("bookId") , "reading_mode" : "not_available" , "book_title" : DataFormatter.getObjectInStorage("bookTitle")  , "selected_bookmark_snippet" : String(requestParameters.note) , "user_id": userID});
                        ga('send', {
                            hitType: 'event',
                            eventCategory: 'Bookmark',
                            eventAction: 'Updated/Deleted',
                            eventLabel: JSON.stringify({
                                "book title": bookObject.metadata.title,
                                "book_id": bookmark.bookId,
                                "page_index": bookmark.pageIndex
                            })
                        });
                    }
                    // Refresh the book panel.
                    var bookId = DataFormatter.getObjectInStorage("productId");
                    AppActions.getBookBookmarks(bookId);
      console.log('appactionsjs getBookBookmarks called after deleted 395 -->', bookId);
                }, "application/x-www-form-urlencoded")
        }
    },
    manageHighlight: function(highlightData) {
        var userID = DataFormatter.getKeyFromObject("userInformation", "id");
        var usertoken = DataFormatter.getKeyFromObject("userInformation", "userToken");
        var bookObject = DataFormatter.getObjectInStorage('currentBook');
        var bookTitle = "" , bookId = "";
        try {
        bookTitle = bookObject.metadata.title;
        bookId = bookObject.id;
        if(!bookTitle) {
        var productId = DataFormatter.getObjectInStorage('productId');
        var products = DataFormatter.getObjectInStorage('products');
        for(var i=0 ; i<products.length; i++) {
            if(productId == products[i].id) {
                bookTitle = products[i].title;
            }
        }
        }

        }catch(e)
        {

        }
        headerParameters = {
            'appId': AppConstants.AppID,
            'token': usertoken
        }

        requestParameters = {
                'sourceId': highlightData.bookId,
                'sourceType': "highlight",
                'user': userID,
                'colour': highlightData.colour ? highlightData.colour : AppConstants.DefaultHighlightColor,
                'comment': highlightData.comment ? highlightData.comment : '',
                'highlightHash': highlightData.serializedHighlight,
                'highlightEngine': highlightData.isPDF? AppConstants.HighlightEnginePDF : AppConstants.HighlightEngine ,
                'pageId': String(highlightData.pageInformation.pageId) ? String(highlightData.pageInformation.pageId) : String(highlightData.pageInformation.pageNumber),
                'pageIndex': highlightData.pageInformation.pageNumber
            }
            // handle different cases for create/delete/modify highlight.
        if (highlightData.selection) {
            requestParameters.note = highlightData.selection;
        } else {
            requestParameters.note = highlightData.note;
        }
        // If the highlight is marked for deletion, then set the status here.
        if (highlightData.shouldDeleteHighlight) {
            requestParameters.status = 'deleted';
        }
        DataFormatter.createAWSSession();
        if (highlightData.isNewHighlight) {
            reqHandler.handleRequest(AppConstants.RequestTypes.post, AppConstants.APIBaseUrl + 'highlight',
                headerParameters, requestParameters,
                function(err, res) {
                    if (res) {
                        if(requestParameters.status == 'deleted') {
                            // console.log("action:" + "create" + "book_id:" + DataFormatter.getObjectInStorage("bookId") + "reading_mode:"  + "not_available" + "book_title:" + DataFormatter.getObjectInStorage("bookTitle")  + "selected_bookmark_snippet" + String(requestParameters.note) + "user_id:" + userID);
                         DataFormatter.sendAWSEvent("highlight", { "action": "deleted" , "book_title" : DataFormatter.getObjectInStorage("bookTitle") , "book_id" : DataFormatter.getObjectInStorage("bookId") , "screen_orientation" : "not_available", "reading_mode" : "not_available" ,"page_index" : requestParameters.pageIndex , "highlighted_text_length" : String(requestParameters.note).length , "note_text_length" : String(requestParameters.comment).length , "user_id": userID});
                        } else {
                            // console.log("action:" + "create" + "book_id:" + bookId + "reading_mode:"  + "not_available" + "book_title:" + bookTitle  + "selected_bookmark_snippet" + String(requestParameters.note) + "user_id:" + userID);
                         DataFormatter.sendAWSEvent("highlight", { "action": "created" , "book_title" : DataFormatter.getObjectInStorage("bookTitle") , "book_id" : DataFormatter.getObjectInStorage("bookId") , "screen_orientation" : "not_available", "reading_mode" : "not_available" ,"page_index" : requestParameters.pageIndex , "highlighted_text_length" : String(requestParameters.note).length , "note_text_length" : String(requestParameters.comment).length , "note_source" : "Book" , "user_id": userID});
                        }
                        requestParameters.pageIndex = String(requestParameters.pageIndex);
                        requestParameters.comment = String(requestParameters.comment);
                        requestParameters.pageId = String(requestParameters.pageId);
                        requestParameters.note = String(requestParameters.note);
                        reqHandler.handleRequest(AppConstants.RequestTypes.put, AppConstants.APIBaseUrl + 'highlight/' + res.body.id,
                headerParameters, requestParameters,function(){});
                        ga('send', {
                            hitType: 'event',
                            eventCategory: 'Highlight',
                            eventAction: 'Created',
                            eventLabel: JSON.stringify({
                                "book title": bookObject.metadata.title,
                                "book id": highlightData.bookId,
                                "page_index": highlightData.pageInformation.pageNumber
                            })
                        });
                    }
                    // Refresh the book panel.
                    var bookId = DataFormatter.getObjectInStorage('productId');
                    AppActions.getBookHighlights(bookId);

                }, "application/x-www-form-urlencoded")
        } else {
            reqHandler.handleRequest(AppConstants.RequestTypes.put, AppConstants.APIBaseUrl + 'highlight/' + highlightData.id,
                headerParameters, requestParameters,
                function(err, res) {
                    if (res) {
                        if(requestParameters.status == 'deleted') {
                         DataFormatter.sendAWSEvent("highlight", { "action": "deleted" , "book_title" : DataFormatter.getObjectInStorage("bookTitle") , "book_id" : DataFormatter.getObjectInStorage("bookId") , "screen_orientation" : "not_available", "reading_mode" : "not_available" ,"page_index" : requestParameters.pageIndex , "highlighted_text_length" : String(requestParameters.note).length , "note_text_length" : String(requestParameters.comment).length , "user_id": userID});
                        } else {
                         DataFormatter.sendAWSEvent("highlight", { "action": "updated" , "book_title" : DataFormatter.getObjectInStorage("bookTitle") , "book_id" : DataFormatter.getObjectInStorage("bookId") , "screen_orientation" : "not_available", "reading_mode" : "not_available" ,"page_index" : requestParameters.pageIndex , "highlighted_text_length" : String(requestParameters.note).length , "note_text_length" : String(requestParameters.comment).length ,  "user_id": userID});
                        }
                        ga('send', {
                            hitType: 'event',
                            eventCategory: 'Highlight',
                            eventAction: 'Updated/Deleted',
                            eventLabel: JSON.stringify({
                                "book title": bookObject.metadata.title,
                                "book_id": highlightData.bookId,
                                "page_index": highlightData.pageInformation.pageNumber,
                                "highlight_Id": highlightData.id
                            })
                        });
                    }
                    // Refresh the book panel.
                    var bookId = DataFormatter.getObjectInStorage('productId');
                    AppActions.getBookHighlights(bookId, highlightData.shouldDeleteHighlight);

                }, "application/x-www-form-urlencoded")
        }
    }
};
export default AppActions;
