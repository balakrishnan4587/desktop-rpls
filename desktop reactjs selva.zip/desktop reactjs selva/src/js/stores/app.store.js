import _ from 'lodash';
import AppDispatcher from '../dispatchers/app.dispatcher';
import AppConstants from '../constants/app.constants';
import assign from 'react/lib/Object.assign';
import {EventEmitter} from 'events';

let CHANGE_EVENT = 'CHANGE_EVENT';
let user = {};
let response = {};

let AppStore = assign(EventEmitter.prototype, {});

AppStore.dispatchToken = AppDispatcher.register((action) => {
  switch(action.type) {
    case AppConstants.ActionTypes.INIT_DASHBOARD:
    user = action.data;
    AppStore.emit(AppConstants.EventTypes.INIT_DASHBOARD_COMPLETE);
    break;

    case AppConstants.ActionTypes.LOGIN_VALIDATE:
    AppStore.emit(AppConstants.EventTypes.LOGIN_VALIDATE_COMPLETE);
    break;

    case AppConstants.ActionTypes.LOGIN_SUBMIT:
    AppStore.response = action.status;
    AppStore.emit(AppConstants.EventTypes.LOGIN_SUBMIT_COMPLETE);
    break;

    case AppConstants.ActionTypes.GET_USER:
    AppStore.response = action.status;
    AppStore.emit(AppConstants.EventTypes.GET_USER_COMPLETE);
    break;

    case AppConstants.ActionTypes.BOOKSHELF_LOAD:
    AppStore.response = action.data;
    AppStore.emit(AppConstants.EventTypes.BOOKSHELF_LOAD_COMPLETE);
    break;

    case AppConstants.ActionTypes.APP_ERROR:
    AppStore.response = action.data;
    AppStore.emit(AppConstants.EventTypes.APP_ERROR);
    break;

    case AppConstants.ActionTypes.LOGOUT_USER:
    console.log('appstore LOGOUT_USER called ');
    AppStore.response = action.data;
    AppStore.emit(AppConstants.EventTypes.USER_LOGOUT_COMPLETE);
    break;

    case AppConstants.ActionTypes.BOOK_CLICKED:
    AppStore.response = action.data;
    AppStore.emit(AppConstants.EventTypes.BOOK_CLICKED);
    break;

    case AppConstants.ActionTypes.HEADER_ITEM_CLICKED:
    AppStore.response = action.data;
    AppStore.emit(AppConstants.EventTypes.BOOK_HEADER_ITEM_CLICKED);
    break;

    case AppConstants.ActionTypes.BRAND_CLICKED:
    AppStore.response = action.data;
    AppStore.emit(AppConstants.EventTypes.BRAND_CLICKED);
    break;

    case AppConstants.ActionTypes.GET_BOOK_HIGHLIGHTS:
    AppStore.response = action.data;
    AppStore.emit(AppConstants.EventTypes.BOOK_HIGHLIGHTS_FETCHED);
    break;

    case AppConstants.ActionTypes.GET_BOOK_BOOKMARKS:
    AppStore.bookmarkresponse = action.data;
    AppStore.emit(AppConstants.EventTypes.BOOK_BOOKMARKS_FETCHED);
    break;

    default:
    break;
  }
});

export default AppStore;
