import db from '../db'
import RequestHandler from '../components/requestHandler';
import AppConstants from '../constants/app.constants';
import DataFormatter from '../components/utilities/dataFormatter';
import AppDispatcher from '../dispatchers/app.dispatcher';

class BookShelfProvider  {
  constructor() {
    this.reqHandler = new RequestHandler();
    this.requestParameters = {};
  }

  createTable = () => {

    db.serialize(function() {
      db.run("CREATE TABLE IF NOT EXISTS bookshelf (userid TEXT, books Text)");
    });
  }

 dropTable = () => {
    db.serialize(function() {
      db.run("DROP TABLE IF EXISTS [bookshelf]")
      });
    }

  put = (userid, books) => {
    db.serialize(function() {
      var stmt = db.prepare("INSERT INTO bookshelf (userid, books) VALUES (?, ?)");
      stmt.run(userid, JSON.stringify(books));
      stmt.finalize();
      });
  }

  getByUserid  = (userid, callback) => {
    if(navigator.onLine) {
      let headerParameters = {
        'appId': AppConstants.AppID,
        'token': DataFormatter.getKeyFromObject("userInformation", "userToken")
      }
      console.log("loading from online");
      this.reqHandler.handleRequest(AppConstants.RequestTypes.get, AppConstants.APIBaseUrl + 'user/' + userid + "/product",
          headerParameters, this.requestParameters,
          function(err, res) {
            console.log('appactionsjs bookdata got -->', res.body, err);
            bookShelfProvider.put(userid, res.body);
              AppDispatcher.dispatch({
                  type: AppConstants.ActionTypes.BOOKSHELF_LOAD,
                  data: res.body
              });
          })
    } else {
      console.log("loading from offline");
      db.serialize(function() {
        db.get("SELECT rowid AS id, userid, books FROM bookshelf WHERE userid ='"+userid +"'",
        function(err, row) {
          let books=row.books;
          console.log(row.id + " : " + row.userid + ": " + row.books);
          console.log('bookshelfprovider books from sqlite', books);
          console.log('callback', callback);
          callback(err, JSON.parse(books));
        });
      });
    }
  }
}
let bookShelfProvider = new BookShelfProvider();
export default bookShelfProvider;
