var gulp = require('gulp');
var $ = require('gulp-load-plugins')();
var assets = require("gulp-assets");
var browserify = require('browserify');
var concat = require('gulp-concat');
var less = require('gulp-less');
var min = require('gulp-usemin');
var minifyCSS = require('gulp-minify-css');
var source = require('vinyl-source-stream');
var shell = require('gulp-shell');
var watch = require('gulp-watch');
var nightwatch = require('gulp-nightwatch');
var livereload = require('gulp-livereload');
var notify = require('gulp-notify');
var mocha = require('gulp-mocha');
var uglify = require('gulp-uglify');
const zip = require('gulp-vinyl-zip');
const symdest = require('gulp-symdest')
var babel = require("gulp-babel");
const replace = require('gulp-replace')
var rename = require("gulp-rename");

const electron = require('electron-connect').server.create({
//   useGlobalElectron: true,
  verbose: true
 })
const electronPackager = require('gulp-atom-electron')
const electronVersion = require('electron-prebuilt/package.json').version



gulp.task('seed', function() {
  return require('./test/seed/').start();
});

gulp.task('browserify', function() {
  browserify({
    entries : ['./src/js/main.js'],
    debug : true})
  .transform('babelify', {presets: ['es2015', 'react', 'stage-0']})
  .bundle()
  .on('error',  notify.onError('Error: <%= error.stack %>'))
  .pipe(source('./main.js'))
  .pipe(gulp.dest('dist/js'));
});

gulp.task('less', function () {
  return gulp.src('./src/styles/main.less')
  .pipe(less({
    paths: ['src/styles']
  }))
  .pipe(min({
    cssmin: true
  }))
  .pipe(gulp.dest('./src/assets/css'));
});

gulp.task('cssmin', function (cb) {
  return gulp.src('src/index.html')
    .pipe(assets({
        js: false,
        css: true
    }))
    .pipe(minifyCSS())
    .pipe(concat('main.css'))
    .pipe(gulp.dest('dist/assets/css'));
});

gulp.task('copy', function() {
  gulp.src('src/index.html')
    .pipe(gulp.dest('dist'));

  gulp.src('package.json')
    .pipe(gulp.dest('dist'));

  gulp.src('src/assets/**/*.*')
    .pipe(gulp.dest('dist/assets'));

  gulp.src('src/components/**/*.*')
    .pipe(gulp.dest('dist/components'));
});

gulp.task('deploy', function(cb) {
  gulp.src('index.html')
    .pipe(gulp.dest('deploy'));

  gulp.src('app.js')
    .pipe(gulp.dest('deploy'));


  gulp.src('release_package.json')
    .pipe(rename('package.json'))
    .pipe(gulp.dest('deploy'));

  gulp.src('src/assets/**/*.*')
    .pipe(gulp.dest('deploy/assets'));

    gulp.src('src/assets/images/**/*.*')
      .pipe(gulp.dest('deploy/images'));


  gulp.src('src/components/**/*.*')
    .pipe(gulp.dest('deploy/components'));

  gulp.src('src/js/**/*.*')
     .pipe($.cached('*.js'))
    .pipe(babel({"presets": ["es2015", "react", "stage-0"]}))
    .pipe(gulp.dest('deploy/js'));

  gulp.src('src/styles/**/*.*')
    .pipe(gulp.dest('deploy/styles'));

  cb();
});

gulp.task('server', function() {
  var server = require('./index');
});

//  Also starts the webserver
gulp.task('watch', function() {
  livereload.listen();
  gulp.watch('src/**/*', ['browserify', 'less', 'copy']);
});

gulp.task('e2e', function() {
  gulp.src('')
  .pipe(nightwatch({
    configFile: 'test/e2e/nightwatch.json'
  }));
});

gulp.task('unit', function () {
    require('babel/register');
    return gulp.src('test/unit/*.js', {read: false})
      .pipe(mocha({
         compilers: 'js:babel/register'
      }));
});

/* Minify Main.js files with UglifyJS.*/
gulp.task('compress', function() {
  return gulp.src('dist/js/main.js')
    .pipe(uglify())
    .pipe(gulp.dest('dist/uglify'));
});


/* These are the packaging tasks! */

gulp.task('package-osx',  () => {
  return gulp.src('./deploy/**')
    .pipe(electronPackager({ version: electronVersion, platform: 'darwin' }))
    .pipe(symdest('release/osx'))
})

gulp.task('package-windows', () => {
  return gulp.src('./deploy/**')
    .pipe(electronPackager({ version: electronVersion, platform: 'win32', arch:'x64' }))
    .pipe(zip.dest('./release/windows/windows.zip'))
})

gulp.task('package-linux', (cb) => {
  return gulp.src('./deploy/**')
    .pipe(electronPackager({ version: electronVersion, platform: 'linux', arch:'x64' }))
    .pipe(zip.dest('./release/linux/linux.zip'))
    cb();
})

gulp.task('serve', () => {
  electron.start()
  gulp.watch('app.js', electron.restart)
  gulp.watch(['app.js'], electron.reload)
})

gulp.task('default', ['server', 'browserify', 'copy', 'watch']);
gulp.task('build', ['browserify', 'less', 'cssmin', 'copy']);
gulp.task('test', ['seed', 'e2e', 'unit']);
