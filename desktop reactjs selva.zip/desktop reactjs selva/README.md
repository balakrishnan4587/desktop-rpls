# web-readerplus

## Quick start

install ```gulp```:

```npm install -g gulp```
```npm install -g gulp-cli electron-prebuilt```
Then ```cd``` into directory and run ```npm install```

rebuilding sqllite3
  cd node_modules/sqlite3
  node-gyp rebuild --target=1.2.2 --arch=x64 --target_platform=linux --dist-url=https://atom.io/download/atom-shell --module_name=node_sqlite3 --module_path=../lib/binding/electron-v1.2-linux-x64

To start the web reader app run ```gulp```
Open ```localhost:3000``` you should see the dashboard

To launch the desktop reader app, in a different terminal run ```gulp serve```
This will launch the app



=======
## Known issues

When running on OSX, if the ```gulp`` task returns a ```EMFILE``` error run the following command in the terminal: ```ulimit -n 2560```
refs/heads/develop

=======
## OS specific packaging
  *The following tasks should be done first*
```gulp deploy```
Install dependencies in deploy folder for packing part of electron installer. ```cd deploy```
```npm install```
~Rebuild sqlite for the target platfrom and architecture~
```  cd node_modules/sqlite3```
```  node-gyp rebuild --target=1.2.2 --arch=x64 --target_platform=linux --dist-url=https://atom.io/download/atom-shell --module_name=node_sqlite3 --module_path=../lib/binding/electron-v1.2-linux-x64```

cd project root folder
```npm install```
```gulp deploy```

To create packaging for Linux     ```gulp package-linux```
To create packaging for Mac       ```gulp package-osx```
To create packaging for windows   ```gulp package-windows```
