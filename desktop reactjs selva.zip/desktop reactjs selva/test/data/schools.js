module.exports = [{
    _id: '548e5ce1e24471ed0e3bc92a',
    "name": "Durban Heights Primary School",
    organizationId: '69701c20de134b57a9bc5c7e3938d9e1'
  },
  {
    _id: '548e5ce1e24471ed0e3bc92b',
    name: 'Broadfields Primary School',
    organizationId: '69701c20de134b57a9bc5c7e3938d9e1'
  },{
    _id: '548e5ce1e24471ed0e3bc92c',
    name: 'Test School QA',
    organizationId: '69701c20de134b57a9bc5c7e3938d9e1'
  }
]