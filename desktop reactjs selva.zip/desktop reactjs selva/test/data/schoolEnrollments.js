module.exports = [{
  "_id" : "56126687aaf2207d19715301",
  "user" : "56126687aaf2207d19715300",
  "school" : "548e5ce1e24471ed0e3bc92a",
  "state" : "active",
  "role" : "student"
},{
  "_id" : "56126688aaf2207d19715303",
  "user" : "56126687aaf2207d19715302",
  "school" : "548e5ce1e24471ed0e3bc92a",
  "state" : "active",
  "role" : "student"
},{
  "_id" : "56126688aaf2207d19715305",
  "user" : "56126688aaf2207d19715304",
  "school" : "548e5ce1e24471ed0e3bc92a",
  "state" : "active",
  "role" : "student"
},{
  "_id" : "56126689aaf2207d19715307",
  "user" : "56126688aaf2207d19715306",
  "school" : "548e5ce1e24471ed0e3bc92a",
  "state" : "active",
  "role" : "student"
},{
  "_id" : "56126689aaf2207d19715309",
  "user" : "56126689aaf2207d19715308",
  "school" : "548e5ce1e24471ed0e3bc92a",
  "state" : "active",
  "role" : "teacher"
},{
  "_id" : "5612668aaaf2207d1971530b",
  "user" : "56126689aaf2207d1971530a",
  "school" : "548e5ce1e24471ed0e3bc92a",
  "state" : "active",
  "role" : "teacher"
},{
  "_id" : "5612668aaaf2207d1971530d",
  "user" : "5612668aaaf2207d1971530c",
  "school" : "548e5ce1e24471ed0e3bc92a",
  "state" : "active",
  "role" : "teacher"
},{
  "_id" : "5612668caaf2207d1971536f",
  "user" : "5612668caaf2207d1971536e",
  "school" : "548e5ce1e24471ed0e3bc92a",
  "state" : "active",
  "role" : "admin"
},{
  "_id" : "5612668caaf2207d19715372",
  "user" : "5612668caaf2207d19715371",
  "school" : "548e5ce1e24471ed0e3bc92a",
  "state" : "active",
  "role" : "admin"
}]