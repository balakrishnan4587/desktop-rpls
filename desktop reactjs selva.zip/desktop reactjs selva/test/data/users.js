module.exports = [
  {
      "_id" : "56126686aaf2207d197152eb",
      "userId" : "b347392f3eb39e01451cbac822b83131",
      "firstName" : "GLOS",
      "lastName" : "Administrator ",
      "name" : "GLOS Administrator ",
      "username" : "glos_admin",
      "email" : "hello@any.com",
      "status" : "Active",
      "gender" : "M",
      "loggedIn" : "2015-10-05T12:01:10.437Z",
      "roles" : [
          "admin"
      ]
  },{
      "_id" : "56126687aaf2207d19715300",
      "userId" : "21a0f1ab54d648128689c456b2c206a3",
      "name" : "Manik Kakar",
      "firstName" : "Manik",
      "lastName" : "Kakar",
      "email" : "manik@ny.com0.3032552106305957",
      "gender" : "male",
      "username" : "manik@ny.com0.3032552106305957",
      "loggedIn" : "2015-10-05T12:00:30.173Z",
      "roles" : [
          "student"
      ]
  },{
      "_id" : "56126687aaf2207d19715302",
      "userId" : "cc8a9141f0d94611892df27414c18c51",
      "name" : "test two",
      "firstName" : "test",
      "lastName" : "two",
      "email" : "test@pearson.com0.252693846821785",
      "gender" : "male",
      "username" : "test@pearson.com0.252693846821785",
      "loggedIn" : "2015-10-05T12:00:30.173Z",
      "roles" : [
          "student"
      ]
  },{
      "_id" : "56126688aaf2207d19715304",
      "userId" : "81ae364d7dff43eca8fcb69429637c7b",
      "name" : "Geetha Muthyam",
      "firstName" : "Geetha",
      "lastName" : "Muthyam",
      "email" : "geetha.muthyam@pearson.com0.6087656824383885",
      "gender" : "female",
      "username" : "geetha.muthyam@pearson.com0.6087656824383885",
      "loggedIn" : "2015-10-05T12:00:30.173Z",
      "roles" : [
          "student"
      ]
  },{
      "_id" : "56126688aaf2207d19715306",
      "userId" : "74d62b5117e04ae0bef94c78257b16c7",
      "name" : "Billy Bob",
      "firstName" : "Billy",
      "lastName" : "Bob",
      "email" : "billy.bob@pearson.com0.5340246867854148",
      "gender" : "male",
      "username" : "billy.bob@pearson.com0.5340246867854148",
      "loggedIn" : "2015-10-05T12:00:30.173Z",
      "roles" : [
          "student"
      ]
  },{
      "_id" : "56126689aaf2207d19715308",
      "userId" : "fc2132194d2f4d29a6da9a09e6a5e296",
      "name" : "Jozz Hart",
      "firstName" : "Jozz",
      "lastName" : "Hart",
      "email" : "jozz.hart@pearson.com0.36467891884967685",
      "gender" : "male",
      "username" : "jozz.hart@pearson.com0.36467891884967685",
      "loggedIn" : "2015-10-05T12:00:30.173Z",
      "roles" : [
          "teacher"
      ]
  },{
      "_id" : "56126689aaf2207d1971530a",
      "userId" : "626c1cfe0ce14668a5f588354b9f90ab",
      "name" : "Mehdi Avdi",
      "firstName" : "Mehdi",
      "lastName" : "Avdi",
      "email" : "mehdi.avdi@pearson.com0.5597536899149418",
      "gender" : "male",
      "username" : "mehdi.avdi@pearson.com0.5597536899149418",
      "loggedIn" : "2015-10-05T12:00:30.173Z",
      "roles" : [
          "teacher"
      ]
  },{
      "_id" : "5612668aaaf2207d1971530c",
      "userId" : "43034dd3297445e39696f38d004ca68d",
      "name" : "Jane Smith",
      "firstName" : "Jane",
      "lastName" : "Smith",
      "email" : "janesmith@school0.6185902138240635",
      "gender" : "female",
      "username" : "janesmith@school0.6185902138240635",
      "loggedIn" : "2015-10-05T12:00:30.173Z",
      "roles" : [
          "teacher"
      ]
  },{
      "_id" : "5612668caaf2207d1971536e",
      "userId" : "a1ee9f44043c4c79a1bf1fe0161bbed3",
      "firstName" : "School",
      "lastName" : "Admin",
      "name" : "School Admin",
      "username" : "test_school_admin@pearson.com",
      "email" : "test_school_admin@pearson.com",
      "status" : null,
      "gender" : "M",
      "loggedIn" : "2015-10-05T12:01:16.179Z",
      "roles" : [
          "admin"
      ]
  },{
      "_id" : "5612668caaf2207d19715370",
      "userId" : "1724ad2a63f14795a877456a79aea305",
      "firstName" : "Not",
      "lastName" : "Assigned",
      "name" : "Not Assigned",
      "username" : "admin@not.assigned.com",
      "email" : "admin@not.assigned.com",
      "status" : null,
      "gender" : "M",
      "loggedIn" : "2015-10-05T12:01:16.405Z",
      "roles" : [
          "admin"
      ]
  },{
      "_id" : "5612668caaf2207d19715371",
      "userId" : "15fd31832c114485a2f794dc528c9ce2",
      "firstName" : "Just",
      "lastName" : "Anadmin",
      "name" : "Just Anadmin",
      "username" : "just@an.admin",
      "email" : "just@an.admin",
      "status" : null,
      "gender" : "M",
      "loggedIn" : "2015-10-05T12:01:16.567Z",
      "roles" : [
          "admin"
      ]
  },{
      "_id" : "5612668caaf2207d19715373",
      "userId" : "a5ca08fc9b6044d4b528b6b930445bde",
      "firstName" : "Pearson",
      "lastName" : "Admin",
      "name" : "Pearson Admin",
      "username" : "test_pearson_admin@pearson.com",
      "email" : "test_pearson_admin@pearson.com",
      "status" : null,
      "gender" : "M",
      "loggedIn" : "2015-10-05T12:01:16.743Z",
      "roles" : [
          "pearson-admin"
      ]
  }
]