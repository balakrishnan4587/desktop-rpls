module.exports = {
  'Check Login Page loaded with expected elements': function (client) {
    var data = client.globals;
    client
    .url(data.url)
    .assert.title('Login')
    .assert.attributeEquals('#username','type','text')
    .assert.attributeEquals('#password','type','password')
    .assert.attributeEquals('.btn-lg','type','submit')
    .end();
  },

  'Login with empty credentials': function (client) {
    var data = client.globals;
    client
    .url(data.url)
    .setValue('#username','')
    .setValue('#password','')
    .click('button[type=submit]')
    .waitForElementVisible('#loginStatus', 1000)
    .assert.containsText('#loginStatus','Please check your username or password')
    .end();
  },

  'Login with incorrect credentials': function (client) {
    var data = client.globals;
    client
    .url(data.url)
    .setValue('#username','test')
    .setValue('#password','test')
    .click('button[type=submit]')
    .pause(5000)
    .assert.containsText('#loginStatus','Invalid username and/or password')
    .end();
  },

  'Login with correct credentials should navigate to bookshelf page': function (client) {
    var data = client.globals;
    client
    .url(data.url)
    .setValue('#username',data.bookshelfLogin.username)
    .setValue('#password',data.bookshelfLogin.password)
    .click('button[type=submit]')
    .pause(5000)
    .assert.urlContains('bookshelf','Yes,its naviagated to bookshelf page')
    .end();
  },

  'Check Bookshelf Page loaded with books and other elements': function (client) {
    var data = client.globals;
    client
    .url(data.url)
    .setValue('#username',data.bookshelfLogin.username)
    .setValue('#password',data.bookshelfLogin.password)
    .click('button[type=submit]')
    .pause(5000)
    .assert.elementPresent('.bookshelfItem','Book is available')
    .assert.elementPresent('.bookThumbnail','Thumnail image is available')
    .assert.elementPresent('.bookName','Book title is available')
    .end();
  },
  'Check if the user is able to logout from the application': function (client) {
    var data = client.globals;
    client
    .url(data.url)
    .setValue('#username',data.bookshelfLogin.username)
    .setValue('#password',data.bookshelfLogin.password)
    .click('button[type=submit]')
    .pause(5000)
    .click('.dropdown-toggle')
    .pause(1000)
    .click('li#logout a')
    .waitForElementVisible('#loginStatus', 1000)
    .assert.containsText('#loginStatus','You have been logged out successfully.')
    .end();
  }

};
