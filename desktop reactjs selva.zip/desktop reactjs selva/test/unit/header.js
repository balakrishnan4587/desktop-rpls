import React from 'react/addons';
import sinon from 'sinon';
import Header from '../../src/js/components/navbar';
import AppActions from '../../src/js/actions/app.actions'

let TestUtils = React.addons.TestUtils;
var requestStub = sinon.stub();

describe('Header component', function(){
  before('render and locate element', function() {
    require('react/lib/ExecutionEnvironment').canUseDOM = true;
    this.renderedNavbarComponent = TestUtils.renderIntoDocument(
      <Header/>
  );
  });
  afterEach('setting document',function(){
		requestStub.restore();
	});
  it('Check if logout method is executed',function(done){
    requestStub = sinon.stub(AppActions, "logoutUser", function(){
      sinon.assert.calledOnce(requestStub);
      done();
    });
    AppActions.logoutUser();
  });
});
