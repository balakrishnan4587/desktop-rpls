import React from 'react/addons';
import sinon from 'sinon';
import RequestHandler from '../../src/js/components/requestHandler';
import AppConstants from '../../src/js/constants/app.constants'

var requestStub;
let requestParameters = {
	'username': 'reader3.sa@uat.com',
	'password':'hudson102'
}
let headerParameters= {
	'appId': AppConstants.AppID
}
describe('Global Request handler component', function(){
	this.timeout(6000);
	before('setting document',function(){
		require('react/lib/ExecutionEnvironment').canUseDOM = true;
		let {TestUtils} = React.addons;
		this.RequestHandler = new RequestHandler();
		requestStub = sinon.stub(this.RequestHandler, "requestCompleted");
	});
	beforeEach('setting document',function(){
		require('react/lib/ExecutionEnvironment').canUseDOM = true;
	});
	afterEach('setting document',function(){
		this.RequestHandler.requestCompleted.restore();
	});
	it('Check if request handler instance is created',function(){
		expect(this.RequestHandler).not.to.be.null;
	});
	it('Check if request handler can handle a valid request',function(done){
		requestStub = sinon.stub(this.RequestHandler, "requestCompleted",
		function(err,res)
		{
			expect(err).to.be.null;
			done();
		});
		this.RequestHandler.handleRequest(AppConstants.RequestTypes.post,AppConstants.APIBaseUrl + 'authenticate',
		headerParameters,requestParameters,null);
	});
	it('Check if request handler can propogate an error',function(done){
		requestParameters.password = 'abcd123';
		requestStub = sinon.stub(this.RequestHandler, "requestCompleted",
		function(err,res)
		{
			expect(err).to.not.be.null;
			done();
		});
		this.RequestHandler.handleRequest(AppConstants.RequestTypes.post,AppConstants.APIBaseUrl + 'authenticate',
		headerParameters,requestParameters,null);
	});
});
