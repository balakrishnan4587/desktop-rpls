import React from 'react/addons';
import sinon from 'sinon';
import LoadingOverlay from '../../src/js/components/loadingOverlay';
let assert = require('chai').assert;

describe('Loading Overlay component', function(){
	var scrollProps={},
	requestStub = '';

	before('setting document',function(){
		require('react/lib/ExecutionEnvironment').canUseDOM = true;
		let {TestUtils} = React.addons;
    this.overlayShown = TestUtils.renderIntoDocument(<LoadingOverlay key="overlayShown" isLoading ={true}></LoadingOverlay>);
		this.overlayHidden = TestUtils.renderIntoDocument(<LoadingOverlay key="overlayHidden" isLoading ={false}></LoadingOverlay>);
    this.renderedOverlay = () => React.findDOMNode(this.overlayShown);
		this.renderedOverlayHidden = () => React.findDOMNode(this.overlayHidden);
	});
	beforeEach('setting document',function(){
		require('react/lib/ExecutionEnvironment').canUseDOM = true;
	});

	it('Check if loading overlay is shown',function(){
		let overlayChildrenLength= this.renderedOverlay().children.length;
		expect(overlayChildrenLength).to.be.at.least(1,'Loading Overlay is shown');
  });

	it('Check if loading overlay is hidden',function(){
		let overlayHidden= this.renderedOverlayHidden();
		expect(overlayHidden).to.equal(null,'Loading Overlay is hidden');
  });
});
