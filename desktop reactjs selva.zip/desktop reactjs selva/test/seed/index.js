"use strict";

var mongoose = require('mongoose');
var async = require("async");

mongoose.connect('mongodb://localhost/gloss', {
  "server": { "auto_reconnect": true, "poolSize": 10 },
  "replset": { "readPreference": "nearest", "strategy": "ping", "rs_name": "rs01"}
});


var dataSets = [
  {
    model: 'App',
    data: require('../data/apps')
  },
  {
    model: 'CourseSectionEnrollment',
    data: require('../data/courseSectionEnrollments')
  },
  {
    model: 'CourseSection',
    data: require('../data/courseSections')
  },
  {
    model: 'License',
    data: require('../data/licenses')
  },
  {
    model: 'SchoolEnrollment',
    data: require('../data/schoolEnrollments')
  },
  {
    model: 'MediaItem',
    data: require('../data/mediaItems')
  },
  {
    model: 'Product',
    data: require('../data/products')
  },
  {
    model: 'School',
    data: require('../data/schools')
  },
  {
    model: 'User',
    data: require('../data/users')
  }
];


class Seed {
    constructor() {
      this.App = require('../../node_modules/gls/lib/models/app').model('App');
      this.MediaItem = require('../../node_modules/gls/lib/models/mediaItem').model('MediaItem');
      this.User = require('../../node_modules/gls/lib/models/user').model('User');
      this.Product = require('../../node_modules/gls/lib/models/product').model('Product');
      this.School = require('../../node_modules/gls/lib/models/school').model('School');
      this.CourseSection = require('../../node_modules/gls/lib/models/courseSection').model('CourseSection');
      this.License = require('../../node_modules/gls/lib/models/license').model('License');
      this.CourseSectionEnrollment = require('../../node_modules/gls/lib/models/enrollment/courseSection').model('CourseSectionEnrollment');
      this.SchoolEnrollment = require('../../node_modules/gls/lib/models/enrollment/school.js').model('SchoolEnrollment');
    }

    start() {

      var me = this;

      console.log('starting seeding');

      async.waterfall([
        // Drop database
        function(callback) {
          mongoose.connection.once('open', function () {
            mongoose.connection.db.dropDatabase(function(err) {
              callback(err)
            });
          });
        },
        function(callback) {
          async.each(dataSets, function(dataSet, callback){
            me._saveData(dataSet.model, dataSet.data, function(err){
              callback(err);
            });
          }, function(err){
            callback(err);
          })
        }
      ], function(err){
        if(err) console.log(err);
        process.exit()
      });
    }

    _saveData(model, data, callback) {

      var me = this;

      async.each(data, function(record, callback){
        new me[model](record)
        .save(function (err, res) {
          callback(err);
        });
      }, function(err) {
        callback(err)
      })
    }

}

module.exports = new Seed();
